<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.tools.processPalette" id="UUID_MDPALETTE_ORACLE" name="oracle.palette" md:ref="../../../addons/generic/technologies/others/actionDefinition.md#UUID_MD_ACTION_DEFINITIONS?fileId=UUID_MD_ACTION_DEFINITIONS$type=md?">
  <node defType="com.stambia.tools.processTool" id="_ru67aL2nEem7N_36OB6h3A">
    <attribute defType="com.stambia.tools.processTool.name" id="_ru67ab2nEem7N_36OB6h3A" value="REJECT Oracle"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_ru67ar2nEem7N_36OB6h3A" value="REJECT Oracle"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_ru67a72nEem7N_36OB6h3A" value="Tools"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_ru67bL2nEem7N_36OB6h3A" ref="../../../templates/templates.oracle/Rdbms/Oracle/REJECT%20Oracle.tp.proc#_cvMAIERgEd22W6kpnG-bRg?fileId=_cvMAIERgEd22W6kpnG-bRg$type=proc$name=REJECT%20Oracle?"/>
    <node defType="com.stambia.tools.metadata" id="_ru67bb2nEem7N_36OB6h3A">
      <attribute defType="com.stambia.tools.metadata.name" id="_ru67br2nEem7N_36OB6h3A" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_ru67b72nEem7N_36OB6h3A">
        <valueEntry key="com.stambia.rdbms.datastore" value="ancestor-or-self::product/@code/string()='ORACLE'"/>
      </attribute>
    </node>
  </node>
</md:node>