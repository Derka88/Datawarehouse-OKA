<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:ecore="http://www.eclipse.org/emf/2002/Ecore" xmlns:md="http://www.stambia.com/md" xmlns:xs="http://www.w3.org/2001/XMLSchema" defType="com.stambia.tools.product" id="_D6zIEEFVEeyONM3odq0iPA" md:ref="resource.tech#UUID_TECH_PROCESS_PALETTE?fileId=UUID_TECH_PROCESS_PALETTE$type=tech$name=Process%20Palette?" internalVersion="v2.0.0">
  <node defType="com.stambia.tools.processTool" id="_LgS50EFVEeyONM3odq0iPA" position="2">
    <attribute defType="com.stambia.tools.processTool.name" id="_LgS50UFVEeyONM3odq0iPA" value="Submit Load"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_LgS50kFVEeyONM3odq0iPA" ref="resource.proc#_59vgwGWWEe2sgsuzMlsplA?fileId=_59vgwGWWEe2sgsuzMlsplA$type=proc$name=Submit%20Load?"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_LgS500FVEeyONM3odq0iPA" value="xDM Tools"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_LgS51EFVEeyONM3odq0iPA" value="Submit Load"/>
    <node defType="com.stambia.tools.metadata" id="_haAYEUFVEeyZy9lTn8gdAA">
      <attribute defType="com.stambia.tools.metadata.name" id="_i9lDoEFVEeyZy9lTn8gdAA" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_TqYw8EFWEeyZy9lTn8gdAA">
        <valueEntry key="com.stambia.rdbms.server" value="true()"/>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.tools.processTool" id="_LgTg4EFVEeyONM3odq0iPA" position="1">
    <attribute defType="com.stambia.tools.processTool.name" id="_LgTg4UFVEeyONM3odq0iPA" value="Get LoadID"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_LgTg4kFVEeyONM3odq0iPA" ref="resource.proc#_wydl4F6kEe2mo9lRZZpcnA?fileId=_wydl4F6kEe2mo9lRZZpcnA$type=proc$name=Get%20LoadID?"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_LgTg40FVEeyONM3odq0iPA" value="xDM Tools"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_LgTg5EFVEeyONM3odq0iPA" value="Get LoadID"/>
    <node defType="com.stambia.tools.metadata" id="_jJh08UFVEeyZy9lTn8gdAA">
      <attribute defType="com.stambia.tools.metadata.name" id="_j_KccEFVEeyZy9lTn8gdAA" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_QvBMAEFWEeyZy9lTn8gdAA">
        <valueEntry key="com.stambia.rdbms.server" value="true()"/>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.tools.processTool" id="_LgTg5UFVEeyONM3odq0iPA" position="3">
    <attribute defType="com.stambia.tools.processTool.name" id="_LgTg5kFVEeyONM3odq0iPA" value="Cancel Load"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_LgTg50FVEeyONM3odq0iPA" value="Cancel Load"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_LgTg6EFVEeyONM3odq0iPA" value="xDM Tools"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_LgTg6UFVEeyONM3odq0iPA" ref="resource.proc#_0MRaUF6kEe2mo9lRZZpcnA?fileId=_0MRaUF6kEe2mo9lRZZpcnA$type=proc$name=Cancel%20Load?"/>
    <node defType="com.stambia.tools.metadata" id="_EMgGoUFWEeyZy9lTn8gdAA">
      <attribute defType="com.stambia.tools.metadata.name" id="_FFMCIEFWEeyZy9lTn8gdAA" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_PnaDsEFWEeyZy9lTn8gdAA">
        <valueEntry key="com.stambia.rdbms.server" value="true()"/>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.tools.processTool" id="_gGangk0BEey0SLxXNcrEPA" position="4">
    <attribute defType="com.stambia.tools.processTool.processRef" id="_g_gysE0BEey0SLxXNcrEPA" ref="resource.proc#_2gjxIF6kEe2mo9lRZZpcnA?fileId=_2gjxIF6kEe2mo9lRZZpcnA$type=proc$name=Get%20Load%20Status?"/>
    <attribute defType="com.stambia.tools.processTool.name" id="_inrqYE0BEey0SLxXNcrEPA" value="Get Load Status"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_jDCwsE0BEey0SLxXNcrEPA" value="Get Load Status"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_jst_0E0BEey0SLxXNcrEPA" value="xDM Tools"/>
    <node defType="com.stambia.tools.metadata" id="_jcQh8U0BEey0SLxXNcrEPA">
      <attribute defType="com.stambia.tools.metadata.name" id="_lkjEIE0BEey0SLxXNcrEPA" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_pSEewE0BEey0SLxXNcrEPA">
        <valueEntry key="com.stambia.rdbms.schema" value="true()"/>
      </attribute>
    </node>
  </node>
</md:node>