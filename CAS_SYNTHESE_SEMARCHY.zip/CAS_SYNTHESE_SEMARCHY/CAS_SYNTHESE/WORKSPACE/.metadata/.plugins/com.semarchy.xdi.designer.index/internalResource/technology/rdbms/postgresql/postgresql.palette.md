<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.tools.processPalette" id="UUID_MDPALETTE_POSTGRESQL" name="postgresql.palette" md:ref="../../../addons/generic/technologies/others/actionDefinition.md#UUID_MD_ACTION_DEFINITIONS?fileId=UUID_MD_ACTION_DEFINITIONS$type=md?">
  <node defType="com.stambia.tools.processTool" id="_Be6c-L2oEem7N_36OB6h3A">
    <attribute defType="com.stambia.tools.processTool.name" id="_Be6c-b2oEem7N_36OB6h3A" value="REJECT PostgreSql"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_Be6c-r2oEem7N_36OB6h3A" value="REJECT PostgreSql"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_Be6c-72oEem7N_36OB6h3A" value="Tools"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_Be6c_L2oEem7N_36OB6h3A" ref="../../../templates/templates.postgresql/Rdbms/PostgreSql/REJECT%20PostgreSql.tp.proc#_9JoUFuhYEeGCDfZuhYd9mg?fileId=_9JoUFuhYEeGCDfZuhYd9mg$type=proc$name=REJECT%20PostgreSql?"/>
    <node defType="com.stambia.tools.metadata" id="_Be6c_b2oEem7N_36OB6h3A">
      <attribute defType="com.stambia.tools.metadata.name" id="_Be6c_r2oEem7N_36OB6h3A" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_Be6c_72oEem7N_36OB6h3A">
        <valueEntry key="com.stambia.rdbms.datastore" value="ancestor-or-self::product/@code/string()='POSTGRESSQL'"/>
      </attribute>
    </node>
  </node>
</md:node>