<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.variable.set" id="_1RYE0DLyEeG7UplBQjBrRQ" name="Semarchy Variables" md:ref="platform:/plugin/com.indy.environment/.tech/others/variable.tech#UUID_TECH_VARIABLE?fileId=UUID_TECH_VARIABLE$type=tech$name=Variable?">
  <node defType="com.stambia.variable.variable" id="_2gwCADLyEeG7UplBQjBrRQ" name="SEM_LOAD_ID">
    <attribute defType="com.stambia.variable.variable.defaultValue" id="_7_oFgDLyEeG7UplBQjBrRQ" value="-1"/>
    <attribute defType="com.stambia.variable.variable.type" id="_8wVJsDLyEeG7UplBQjBrRQ" value="Integer"/>
    <attribute defType="com.stambia.variable.variable.nativeXpathExpression" id="_9-8R4DLyEeG7UplBQjBrRQ" value="false"/>
    <attribute defType="com.stambia.variable.variable.refreshConnection" id="_plx_YDL9EeG7UplBQjBrRQ"/>
    <attribute defType="com.stambia.variable.variable.query" id="_tYJdwDL9EeG7UplBQjBrRQ" value=""/>
    <attribute defType="com.stambia.variable.variable.savingConnection" id="_WrV40DUlEeGLZPpFKzDUhw"/>
    <attribute defType="com.stambia.variable.variable.defaultOperation" id="_Tw8HwDUmEeGLZPpFKzDUhw" value=""/>
  </node>
</md:node>