<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.tools.processPalette" id="UUID_MDPALETTE_MYSQL" name="mysql.palette" md:ref="../../../addons/generic/technologies/others/actionDefinition.md#UUID_MD_ACTION_DEFINITIONS?fileId=UUID_MD_ACTION_DEFINITIONS$type=md?">
  <node defType="com.stambia.tools.processTool" id="_UmRk2L2nEem7N_36OB6h3A">
    <attribute defType="com.stambia.tools.processTool.name" id="_UmRk2b2nEem7N_36OB6h3A" value="REJECT MySql"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_UmRk2r2nEem7N_36OB6h3A" value="REJECT MySql"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_UmRk272nEem7N_36OB6h3A" value="Tools"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_UmRk3L2nEem7N_36OB6h3A" ref="../../../templates/templates.mysql/Rdbms/MySql/REJECT%20MySql.tp.proc#_5N2_0dWFEeGtJo6VIje4NQ?fileId=_5N2_0dWFEeGtJo6VIje4NQ$type=proc$name=REJECT%20MySql?"/>
    <node defType="com.stambia.tools.metadata" id="_UmRk3b2nEem7N_36OB6h3A">
      <attribute defType="com.stambia.tools.metadata.name" id="_UmRk3r2nEem7N_36OB6h3A" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_UmRk372nEem7N_36OB6h3A">
        <valueEntry key="com.stambia.rdbms.datastore" value="ancestor-or-self::product/@code/string()='MYSQL'"/>
      </attribute>
    </node>
  </node>
</md:node>