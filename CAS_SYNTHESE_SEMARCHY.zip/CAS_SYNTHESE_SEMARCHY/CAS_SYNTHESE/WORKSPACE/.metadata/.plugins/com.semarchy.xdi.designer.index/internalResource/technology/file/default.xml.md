<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.xml.product" id="UUID_MD_XML_DEFAULT" name="Xml" md:ref="resource.tech#UUID_TECH_XML2?fileId=UUID_TECH_XML2$type=tech$name=xml?" internalVersion="v1.0.0">
  <node defType="com.stambia.xml.datatype" id="_uIGcYJ1QEd6YPY_Z3ZWY1Q" name="string"/>
  <node defType="com.stambia.xml.datatype" id="_wlJGkJ1QEd6YPY_Z3ZWY1Q" name="integer"/>
  <node defType="com.stambia.xml.datatype" id="_GpcEMJ1REd6YPY_Z3ZWY1Q" name="decimal"/>
  <node defType="com.stambia.xml.datatype" id="_Hnr1IJ1REd6YPY_Z3ZWY1Q" name="boolean"/>
  <node defType="com.stambia.xml.datatype" id="_KBlEsJ1REd6YPY_Z3ZWY1Q" name="float"/>
  <node defType="com.stambia.xml.datatype" id="_KOxzMJ1REd6YPY_Z3ZWY1Q" name="double"/>
  <node defType="com.stambia.xml.datatype" id="_Ka6KsJ1REd6YPY_Z3ZWY1Q" name="duration"/>
  <node defType="com.stambia.xml.datatype" id="_Knq0UJ1REd6YPY_Z3ZWY1Q" name="dateTime"/>
  <node defType="com.stambia.xml.datatype" id="_QaypgJ1REd6YPY_Z3ZWY1Q" name="time"/>
  <node defType="com.stambia.xml.datatype" id="_QqnOMJ1REd6YPY_Z3ZWY1Q" name="date"/>
  <node defType="com.stambia.xml.datatype" id="_wT07obpxEd673KEEKWRhGw" name="anySimpleType"/>
  <node defType="com.stambia.xml.datatype" id="_r5LNUb7nEd6gabFu2zOXIA" name="int"/>
  <node defType="com.stambia.xml.datatype" id="_mSQMMZsREd-vZsrgbvQSLA" name="ID"/>
  <node defType="com.stambia.xml.datatype" id="_o8HxcZsREd-vZsrgbvQSLA" name="IDREF"/>
  <node defType="com.stambia.xml.datatype" id="_NjeI0ZsSEd-vZsrgbvQSLA" name="base64Binary"/>
  <node defType="com.stambia.xml.datatype" id="_PAEpsZsSEd-vZsrgbvQSLA" name="hexBinary"/>
  <node defType="com.stambia.xml.datatype" id="_O14CMWn7EeGcfPbLI0bDrQ" name="NCName"/>
  <node defType="com.stambia.xml.datatype" id="_UQ_nEWn7EeGcfPbLI0bDrQ" name="QName"/>
  <node defType="com.stambia.xml.datatype" id="_WADJ4Wn7EeGcfPbLI0bDrQ" name="Name"/>
  <node defType="com.stambia.xml.datatype" id="_2m-7UcqcEeGlWvMQddg1Cw" name="NMTOKEN"/>
  <node defType="com.stambia.xml.datatype" id="_lsQKATu7EeOdYKDCoBDeZg" name="short"/>
  <node defType="com.stambia.xml.datatype" id="_r83WoXOZEeOM-9bqJsVGwQ" name="negativeInteger"/>
  <node defType="com.stambia.xml.datatype" id="_unE6IXOZEeOM-9bqJsVGwQ" name="nonNegativeInteger"/>
  <node defType="com.stambia.xml.datatype" id="_vvqS0XOZEeOM-9bqJsVGwQ" name="nonPositiveInteger"/>
  <node defType="com.stambia.xml.datatype" id="_wsz3kXOZEeOM-9bqJsVGwQ" name="unsignedInt"/>
  <node defType="com.stambia.xml.datatype" id="_3sC6kXOZEeOM-9bqJsVGwQ" name="unsignedShort"/>
  <node defType="com.stambia.xml.datatype" id="_BJaM4XOaEeOM-9bqJsVGwQ" name="anyURI"/>
  <node defType="com.stambia.xml.datatype" id="_IAsNwXOaEeOM-9bqJsVGwQ" name="token"/>
  <node defType="com.stambia.xml.datatype" id="_ckCWAXOaEeOM-9bqJsVGwQ" name="ENTITY"/>
  <node defType="com.stambia.xml.datatype" id="_tZP_oXOaEeOM-9bqJsVGwQ" name="gDay"/>
  <node defType="com.stambia.xml.datatype" id="_wIewkXObEeOM-9bqJsVGwQ" name="gMonth"/>
  <node defType="com.stambia.xml.datatype" id="_w6320XObEeOM-9bqJsVGwQ" name="gMonthDay"/>
  <node defType="com.stambia.xml.datatype" id="_z7YacXObEeOM-9bqJsVGwQ" name="gYear"/>
  <node defType="com.stambia.xml.datatype" id="_1nhMIXObEeOM-9bqJsVGwQ" name="gYearMonth"/>
  <node defType="com.stambia.xml.datatype" id="_fpxCEfP-EeSkpuvNV7ymeQ" name="long"/>
  <node defType="com.stambia.xml.datatype" id="_6RgQ8f1aEeSMSp-l2VF1ew" name="ENTITIES"/>
  <node defType="com.stambia.xml.datatype" id="_7BDekf1aEeSMSp-l2VF1ew" name="IDREFS"/>
  <node defType="com.stambia.xml.datatype" id="_9HGlEf1aEeSMSp-l2VF1ew" name="NMTOKENS"/>
  <node defType="com.stambia.xml.datatype" id="_-W_fof1aEeSMSp-l2VF1ew" name="language"/>
  <node defType="com.stambia.xml.datatype" id="__cOCUf1aEeSMSp-l2VF1ew" name="byte"/>
  <node defType="com.stambia.xml.datatype" id="_A3wzQf1bEeSMSp-l2VF1ew" name="normalizedString"/>
  <node defType="com.stambia.xml.datatype" id="_EQQZEf1bEeSMSp-l2VF1ew" name="positiveInteger"/>
  <node defType="com.stambia.xml.datatype" id="_GSGVAf1bEeSMSp-l2VF1ew" name="unsignedByte"/>
  <node defType="com.stambia.xml.datatype" id="_HYiYof1bEeSMSp-l2VF1ew" name="unsignedLong"/>
  <node defType="com.stambia.xml.propertyField" id="_7A8v0qU4Eei4UYjp6OdKAQ" name="nodeName">
    <attribute defType="com.stambia.xml.propertyField.property" id="_7A8v06U4Eei4UYjp6OdKAQ" value="nodeName"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_OKv0YDLuEeqNIoVw6e-Jcg">
      <values>xml_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_95qCUKU4Eei4UYjp6OdKAQ" name="nodePrefix">
    <attribute defType="com.stambia.xml.propertyField.property" id="_95qCUaU4Eei4UYjp6OdKAQ" value="nodePrefix"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_QXoisDLuEeqNIoVw6e-Jcg">
      <values>xml_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="__KbGoqU4Eei4UYjp6OdKAQ" name="nodeURI">
    <attribute defType="com.stambia.xml.propertyField.property" id="__KbGo6U4Eei4UYjp6OdKAQ" value="nodeURI"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_RWszADLuEeqNIoVw6e-Jcg">
      <values>xml_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_2ZqboKU4Eei4UYjp6OdKAQ" name="nodeLocalName">
    <attribute defType="com.stambia.xml.propertyField.property" id="_5Z3dQKU4Eei4UYjp6OdKAQ" value="nodeLocalName"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_STkq8DLuEeqNIoVw6e-Jcg">
      <values>basic_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_55G-AKU4Eei4UYjp6OdKAQ" name="nodeLocalPosition">
    <attribute defType="com.stambia.xml.propertyField.property" id="_55G-AaU4Eei4UYjp6OdKAQ" value="nodeLocalPosition"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_TpLzADLuEeqNIoVw6e-Jcg">
      <values>basic_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_8prBIqU4Eei4UYjp6OdKAQ" name="nodePath">
    <attribute defType="com.stambia.xml.propertyField.property" id="_8prBI6U4Eei4UYjp6OdKAQ" value="nodePath"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_UoKjwDLuEeqNIoVw6e-Jcg">
      <values>basic_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_AwgToKU5Eei4UYjp6OdKAQ" name="sortKey">
    <attribute defType="com.stambia.xml.propertyField.property" id="_AwgToaU5Eei4UYjp6OdKAQ" value="sortKey"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_VtEWUDLuEeqNIoVw6e-Jcg">
      <values>basic_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_KnUnx6U5Eei4UYjp6OdKAQ" name="fileName">
    <attribute defType="com.stambia.xml.propertyField.property" id="_KnUnyKU5Eei4UYjp6OdKAQ" value="fileName"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_tHGX0DLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_S78wYqU5Eei4UYjp6OdKAQ" name="filePath">
    <attribute defType="com.stambia.xml.propertyField.property" id="_S78wY6U5Eei4UYjp6OdKAQ" value="filePath"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_t99uYDLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_Wo3HAKU5Eei4UYjp6OdKAQ" name="fileParentName">
    <attribute defType="com.stambia.xml.propertyField.property" id="_Wo3HAaU5Eei4UYjp6OdKAQ" value="fileParentName"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_uucJEDLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_UjjnYqU5Eei4UYjp6OdKAQ" name="fileParentPath">
    <attribute defType="com.stambia.xml.propertyField.property" id="_UjjnY6U5Eei4UYjp6OdKAQ" value="fileParentPath"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_vfLpgDLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_bVkGsKU5Eei4UYjp6OdKAQ" name="fileAbsolutePath">
    <attribute defType="com.stambia.xml.propertyField.property" id="_b-5XkKU5Eei4UYjp6OdKAQ" value="fileAbsolutePath"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_wUzp8DLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_ckRVgKU5Eei4UYjp6OdKAQ" name="fileCanonicalPath">
    <attribute defType="com.stambia.xml.propertyField.property" id="_dNZLAKU5Eei4UYjp6OdKAQ" value="fileCanonicalPath"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_xcZkIDLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_eEHXoKU5Eei4UYjp6OdKAQ" name="fileTotalSpace">
    <attribute defType="com.stambia.xml.propertyField.property" id="_evvukKU5Eei4UYjp6OdKAQ" value="fileTotalSpace"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_ybLgkDLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_f0nE4KU5Eei4UYjp6OdKAQ" name="fileSequenceNumber">
    <attribute defType="com.stambia.xml.propertyField.property" id="_gglaEKU5Eei4UYjp6OdKAQ" value="fileSequenceNumber"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_zREmwDLuEeqNIoVw6e-Jcg">
      <values>root_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_IqysMtUAEeu8GYuyTrynhQ" name="nodeUUID">
    <attribute defType="com.stambia.xml.propertyField.property" id="_PagFcNUAEeu8GYuyTrynhQ" value="nodeUUID"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_QGnkkNUAEeu8GYuyTrynhQ">
      <values>basic_element</values>
    </attribute>
  </node>
  <node defType="com.stambia.xml.propertyField" id="_arTFAtWUEeu0n-TrqBvcXg" name="nodeAbsolutePosition">
    <attribute defType="com.stambia.xml.propertyField.property" id="_cLu9ANWUEeu0n-TrqBvcXg" value="nodeAbsolutePosition"/>
    <attribute defType="com.stambia.xml.propertyField.tag" id="_cw0AANWUEeu0n-TrqBvcXg">
      <values>basic_element</values>
    </attribute>
  </node>
</md:node>