<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.tools.processPalette" id="_-UUID_MDPALETTE_MSSQL" name="mssql.palette" md:ref="../../../addons/generic/technologies/others/actionDefinition.md#UUID_MD_ACTION_DEFINITIONS?fileId=UUID_MD_ACTION_DEFINITIONS$type=md?">
  <node defType="com.stambia.tools.processTool" id="_B_G1aL2nEem7N_36OB6h3A">
    <attribute defType="com.stambia.tools.processTool.name" id="_B_G1ab2nEem7N_36OB6h3A" value="REJECT Mssql"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_B_G1ar2nEem7N_36OB6h3A" value="REJECT Mssql"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_B_G1a72nEem7N_36OB6h3A" value="Tools"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_B_G1bL2nEem7N_36OB6h3A" ref="../../../templates/templates.mssql/Rdbms/Mssql/REJECT%20Mssql.tp.proc#_dtYVltawEeiBdf0kDvEMnQ?fileId=_dtYVltawEeiBdf0kDvEMnQ$type=proc$name=REJECT%20Mssql.tp?"/>
    <node defType="com.stambia.tools.metadata" id="_B_G1bb2nEem7N_36OB6h3A">
      <attribute defType="com.stambia.tools.metadata.name" id="_B_G1br2nEem7N_36OB6h3A" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_B_G1b72nEem7N_36OB6h3A">
        <valueEntry key="com.stambia.rdbms.datastore" value="ancestor-or-self::product/@code/string()='MICROSOFT_SQL_SERVER'"/>
      </attribute>
    </node>
  </node>
</md:node>