<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.runtime" id="UUID_MD_RUNTIME_EMBEDDED" name="Built-in Runtime" md:ref="resource.tech#UUID_TECH_RUNTIME?fileId=UUID_TECH_RUNTIME$type=tech$name=Stambia%20Runtime?" internalVersion="v1.0.0">
  <node defType="com.stambia.runtime.engine" id="_oM8dsPa-EeynPv3lXVx42g" name="Built-in Runtime">
    <attribute defType="com.stambia.runtime.engine.host" id="_r5qnEPa-EeynPv3lXVx42g" value="http://localhost"/>
    <attribute defType="com.stambia.runtime.engine.port" id="_sbb3YPa-EeynPv3lXVx42g" value="42200"/>
    <attribute defType="com.stambia.runtime.engine.user" id="_st12APa-EeynPv3lXVx42g" value="admin"/>
    <attribute defType="com.stambia.runtime.engine.password" id="_tWl4EPa-EeynPv3lXVx42g" value="9E5C1C629CBE5B8A29495798045C45E1"/>
  </node>
</md:node>