<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.http.rest.product" id="UUID_MD_HTTPREST" name="product" md:ref="resource.tech#UUID_TECH_HTTPREST_PRODUCT?fileId=UUID_TECH_HTTPREST_PRODUCT$type=tech$name=HttpRestProduct?" internalVersion="v1.0.0">
  <node defType="com.stambia.http.rest.property" id="_89YoEPmAEeqhK9wFQDc1YQ" name="partName">
    <attribute defType="com.stambia.http.rest.property.level" id="_ItkMMLL6EeueAdRoqcNswQ">
      <values>com.stambia.http.rest.part</values>
    </attribute>
  </node>
  <node defType="com.stambia.http.rest.property" id="_nyDUMFXBEeui64EGHiP7zA" name="partFilename">
    <attribute defType="com.stambia.http.rest.property.level" id="_Ey_NALL6EeueAdRoqcNswQ">
      <values>com.stambia.http.rest.part</values>
    </attribute>
  </node>
  <node defType="com.stambia.http.rest.property" id="_4By1oLL9EeutRb_ejsqj5Q" name="rawContent">
    <attribute defType="com.stambia.http.rest.property.level" id="_6lQ38LL9EeutRb_ejsqj5Q">
      <values>com.stambia.http.rest.response</values>
    </attribute>
  </node>
  <node defType="com.stambia.http.rest.property" id="_Lc7RMP90EeudhIo4OZzXKw" name="technicalErrorMessage">
    <attribute defType="com.stambia.http.rest.property.level" id="_erpI0P90EeudhIo4OZzXKw">
      <values>com.stambia.http.rest.responses</values>
    </attribute>
  </node>
  <node defType="com.stambia.http.rest.property" id="_Nt7qgP90EeudhIo4OZzXKw" name="technicalErrorException">
    <attribute defType="com.stambia.http.rest.property.level" id="_eTUIYP90EeudhIo4OZzXKw">
      <values>com.stambia.http.rest.responses</values>
    </attribute>
  </node>
</md:node>