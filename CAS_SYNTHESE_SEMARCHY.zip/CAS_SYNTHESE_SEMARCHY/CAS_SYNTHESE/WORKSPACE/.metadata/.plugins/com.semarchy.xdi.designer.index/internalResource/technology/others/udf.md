<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.function.product" id="UUID_MD_UDF" name="User Defined Functions" md:ref="function.tech#UUID_TECH_FUNCTION?fileId=UUID_TECH_FUNCTION$type=tech$name=function?">
</md:node>