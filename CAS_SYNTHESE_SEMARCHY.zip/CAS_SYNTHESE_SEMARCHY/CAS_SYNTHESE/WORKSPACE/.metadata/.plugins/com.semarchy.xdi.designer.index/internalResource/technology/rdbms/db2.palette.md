<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.tools.processPalette" id="UUID_MDPALETTE_DB2" name="db2.palette" md:ref="../../../../addons/generic/technologies/others/actionDefinition.md#UUID_MD_ACTION_DEFINITIONS?fileId=UUID_MD_ACTION_DEFINITIONS$type=md?">
  <node defType="com.stambia.tools.processTool" id="_i2YC2L2mEem7N_36OB6h3A">
    <attribute defType="com.stambia.tools.processTool.name" id="_i2YC2b2mEem7N_36OB6h3A" value="REJECT DB2-UDB"/>
    <attribute defType="com.stambia.tools.processTool.displayName" id="_i2YC2r2mEem7N_36OB6h3A" value="REJECT DB2-UDB"/>
    <attribute defType="com.stambia.tools.processTool.paletteCategory" id="_i2YC272mEem7N_36OB6h3A" value="Tools"/>
    <attribute defType="com.stambia.tools.processTool.processRef" id="_i2YC3L2mEem7N_36OB6h3A" ref="../../../../templates/templates.db2/Rdbms/DB2-UDB/REJECT%20DB2-UDB.proc#_W7tn4fBOEeKADMdmsIYV5A?fileId=_W7tn4fBOEeKADMdmsIYV5A$type=proc$name=REJECT%20DB2-UDB?"/>
    <node defType="com.stambia.tools.metadata" id="_i2YC3b2mEem7N_36OB6h3A">
      <attribute defType="com.stambia.tools.metadata.name" id="_i2YC3r2mEem7N_36OB6h3A" value="REF"/>
      <attribute defType="com.stambia.tools.metadata.level" id="_i2YC372mEem7N_36OB6h3A">
        <valueEntry key="com.stambia.rdbms.datastore" value="ancestor-or-self::product/@code/string()='IBM_DB2_UDB'"/>
      </attribute>
    </node>
  </node>
</md:node>