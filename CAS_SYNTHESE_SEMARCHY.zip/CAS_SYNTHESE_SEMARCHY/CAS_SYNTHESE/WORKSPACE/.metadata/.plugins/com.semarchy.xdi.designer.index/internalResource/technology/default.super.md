<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.super" id="UUID_MD_SUPER_TYPE" name="super" md:ref="resource.tech#UUID_TECH_SUPER?fileId=UUID_TECH_SUPER$type=tech$name=Super?" internalVersion="v1.0.0">
  <attribute defType="com.stambia.super.connectionDefinitionsRef" id="_ds5WQNULEeeQKt7WzszDPQ" ref="resource.md#UUID_MD_CONNECTION?fileId=UUID_MD_CONNECTION$type=md?"/>
  <node defType="com.indy.super.type" id="_kRfYWfKZEd2mAq8ezCx8sA" name="Array">
    <attribute defType="com.indy.super.type.java" id="_kRfYWvKZEd2mAq8ezCx8sA" value="java.sql.Array"/>
    <attribute defType="com.indy.super.type.enable" id="_fJDiAPKdEd2akLMqLJT-VA" value="false"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYTfKZEd2mAq8ezCx8sA" name="Binary">
    <attribute defType="com.indy.super.type.java" id="_kRfYTvKZEd2mAq8ezCx8sA" value="byte[]"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYV_KZEd2mAq8ezCx8sA" name="Blob">
    <attribute defType="com.indy.super.type.java" id="_kRfYWPKZEd2mAq8ezCx8sA" value="java.sql.Blob"/>
  </node>
  <node defType="com.indy.super.type" id="_kRexNfKZEd2mAq8ezCx8sA" name="Boolean">
    <attribute defType="com.indy.super.type.java" id="_kRfYQPKZEd2mAq8ezCx8sA" value="boolean"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYQfKZEd2mAq8ezCx8sA" name="Byte">
    <attribute defType="com.indy.super.type.java" id="_kRfYQvKZEd2mAq8ezCx8sA" value="java.lang.Byte"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYVfKZEd2mAq8ezCx8sA" name="Clob">
    <attribute defType="com.indy.super.type.java" id="_kRfYVvKZEd2mAq8ezCx8sA" value="java.sql.Clob"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYT_KZEd2mAq8ezCx8sA" name="Date">
    <attribute defType="com.indy.super.type.java" id="_kRfYUPKZEd2mAq8ezCx8sA" value="java.sql.Date"/>
  </node>
  <node defType="com.indy.super.type" id="_kRexM_KZEd2mAq8ezCx8sA" name="Decimal">
    <attribute defType="com.indy.super.type.java" id="_kRexNPKZEd2mAq8ezCx8sA" value="java.math.BigDecimal "/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYS_KZEd2mAq8ezCx8sA" name="Double">
    <attribute defType="com.indy.super.type.java" id="_kRfYTPKZEd2mAq8ezCx8sA" value="double"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYSfKZEd2mAq8ezCx8sA" name="Float">
    <attribute defType="com.indy.super.type.java" id="_kRfYSvKZEd2mAq8ezCx8sA" value="float"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYRfKZEd2mAq8ezCx8sA" name="Integer">
    <attribute defType="com.indy.super.type.java" id="_kRfYRvKZEd2mAq8ezCx8sA" value="int"/>
  </node>
  <node defType="com.indy.super.type" id="_kRf_VPKZEd2mAq8ezCx8sA" name="JavaObject"/>
  <node defType="com.indy.super.type" id="_kRfYR_KZEd2mAq8ezCx8sA" name="LongInteger">
    <attribute defType="com.indy.super.type.java" id="_kRfYSPKZEd2mAq8ezCx8sA" value="long"/>
  </node>
  <node defType="com.indy.super.type" id="_kRf_UPKZEd2mAq8ezCx8sA" name="Ref">
    <attribute defType="com.indy.super.type.java" id="_kRf_UfKZEd2mAq8ezCx8sA" value="java.sql.Ref"/>
    <attribute defType="com.indy.super.type.enable" id="_lCv5QPKdEd2akLMqLJT-VA" value="false"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYQ_KZEd2mAq8ezCx8sA" name="ShortInteger">
    <attribute defType="com.indy.super.type.java" id="_kRfYRPKZEd2mAq8ezCx8sA" value="short"/>
  </node>
  <node defType="com.indy.super.type" id="_kRexMfKZEd2mAq8ezCx8sA" name="String">
    <attribute defType="com.indy.super.type.java" id="_kRexMvKZEd2mAq8ezCx8sA" value="java.lang.String"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYW_KZEd2mAq8ezCx8sA" name="Struct">
    <attribute defType="com.indy.super.type.java" id="_kRfYXPKZEd2mAq8ezCx8sA" value="java.sql.Struct"/>
    <attribute defType="com.indy.super.type.enable" id="_l_6FEPKdEd2akLMqLJT-VA" value="false"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYUfKZEd2mAq8ezCx8sA" name="Time">
    <attribute defType="com.indy.super.type.java" id="_kRfYUvKZEd2mAq8ezCx8sA" value="java.sql.Time"/>
  </node>
  <node defType="com.indy.super.type" id="_kRfYU_KZEd2mAq8ezCx8sA" name="Timestamp">
    <attribute defType="com.indy.super.type.java" id="_kRfYVPKZEd2mAq8ezCx8sA" value="java.sql.Timestamp"/>
  </node>
  <node defType="com.indy.super.type" id="_kRf_UvKZEd2mAq8ezCx8sA" name="URL">
    <attribute defType="com.indy.super.type.java" id="_kRf_U_KZEd2mAq8ezCx8sA" value="java.net.URL"/>
    <attribute defType="com.indy.super.type.enable" id="_lcICkPKdEd2akLMqLJT-VA" value="false"/>
  </node>
</md:node>