<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.file.server" id="_oP4f4JbEEe-yJMimzYo_ug" md:ref="resource.md#UUID_TECH_FILE_MD?fileId=UUID_TECH_FILE_MD$type=md$name=File?" internalVersion="v2.0.0">
  <node defType="com.stambia.file.directory" id="_oT42IJbEEe-yJMimzYo_ug" name="File">
    <attribute defType="com.stambia.file.directory.path" id="_oUViEJbEEe-yJMimzYo_ug" value="${~/PATH_ARTICLE}$"/>
    <node defType="com.stambia.file.file" id="_Z6ggUJbFEe-yJMimzYo_ug" name="Article_20240801">
      <attribute defType="com.stambia.file.file.type" id="_Z65h4JbFEe-yJMimzYo_ug" value="DELIMITED"/>
      <attribute defType="com.stambia.file.file.charsetName" id="_Z65h4ZbFEe-yJMimzYo_ug" value="ISO-8859-1"/>
      <attribute defType="com.stambia.file.file.lineSeparator" id="_Z65h4pbFEe-yJMimzYo_ug" value="0D0A"/>
      <attribute defType="com.stambia.file.file.fieldSeparator" id="_Z65h45bFEe-yJMimzYo_ug" value="3B"/>
      <attribute defType="com.stambia.file.file.stringDelimiter" id="_Z65h5JbFEe-yJMimzYo_ug" value="22"/>
      <attribute defType="com.stambia.file.file.decimalSeparator" id="_Z65h5ZbFEe-yJMimzYo_ug" value="2E"/>
      <attribute defType="com.stambia.file.file.lineToSkip" id="_Z65h55bFEe-yJMimzYo_ug" value="0"/>
      <attribute defType="com.stambia.file.file.lastLineToSkip" id="_Z65h6JbFEe-yJMimzYo_ug" value="0"/>
      <attribute defType="com.stambia.file.file.header" id="_Z65h6ZbFEe-yJMimzYo_ug" value="1"/>
      <attribute defType="com.stambia.file.file.physicalName" id="_aakgcJbFEe-yJMimzYo_ug" value="${~/FILE_NAME}$"/>
      <node defType="com.stambia.file.field" id="_lLUGRJbFEe-yJMimzYo_ug" name="LIB_TAI" position="6">
        <attribute defType="com.stambia.file.field.size" id="_lLUGRZbFEe-yJMimzYo_ug" value="59"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGRpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGR5bFEe-yJMimzYo_ug" value="LIB_TAI"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGVZbFEe-yJMimzYo_ug" name="LIB_GEN" position="10">
        <attribute defType="com.stambia.file.field.size" id="_lLUGVpbFEe-yJMimzYo_ug" value="56"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGV5bFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGWJbFEe-yJMimzYo_ug" value="LIB_GEN"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGQJbFEe-yJMimzYo_ug" name="LIB_COL" position="5">
        <attribute defType="com.stambia.file.field.size" id="_lLUGQZbFEe-yJMimzYo_ug" value="71"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGQpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGQ5bFEe-yJMimzYo_ug" value="LIB_COL"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGWZbFEe-yJMimzYo_ug" name="CIB_TRN_AGE" position="11">
        <attribute defType="com.stambia.file.field.size" id="_lLUGWpbFEe-yJMimzYo_ug" value="61"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGW5bFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGXJbFEe-yJMimzYo_ug" value="CIB_TRN_AGE"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGXZbFEe-yJMimzYo_ug" name="COD_CAT" position="12">
        <attribute defType="com.stambia.file.field.size" id="_lLUGXpbFEe-yJMimzYo_ug" value="53"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGX5bFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGYJbFEe-yJMimzYo_ug" value="COD_CAT"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGUJbFEe-yJMimzYo_ug" name="PRX_VEN" position="9">
        <attribute defType="com.stambia.file.field.size" id="_lLUGUZbFEe-yJMimzYo_ug" value="55"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGUpbFEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGVJbFEe-yJMimzYo_ug" value="PRX_VEN"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGSJbFEe-yJMimzYo_ug" name="FAM" position="7">
        <attribute defType="com.stambia.file.field.size" id="_lLUGSZbFEe-yJMimzYo_ug" value="73"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGSpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGS5bFEe-yJMimzYo_ug" value="FAM"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGMJbFEe-yJMimzYo_ug" name="COD_MRQ" position="1">
        <attribute defType="com.stambia.file.field.size" id="_lLUGMZbFEe-yJMimzYo_ug" value="53"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGMpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGM5bFEe-yJMimzYo_ug" value="COD_MRQ"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGTJbFEe-yJMimzYo_ug" name="SS_FAM" position="8">
        <attribute defType="com.stambia.file.field.size" id="_lLUGTZbFEe-yJMimzYo_ug" value="80"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGTpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGT5bFEe-yJMimzYo_ug" value="SS_FAM"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGNJbFEe-yJMimzYo_ug" name="LIB_MRQ" position="2">
        <attribute defType="com.stambia.file.field.size" id="_lLUGNZbFEe-yJMimzYo_ug" value="76"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGNpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGN5bFEe-yJMimzYo_ug" value="LIB_MRQ"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGPJbFEe-yJMimzYo_ug" name="LIB_PRD" position="4">
        <attribute defType="com.stambia.file.field.size" id="_lLUGPZbFEe-yJMimzYo_ug" value="90"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGPpbFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGP5bFEe-yJMimzYo_ug" value="LIB_PRD"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGYZbFEe-yJMimzYo_ug" name="LIB_CAT" position="13">
        <attribute defType="com.stambia.file.field.size" id="_lLUGYpbFEe-yJMimzYo_ug" value="66"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGY5bFEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGZJbFEe-yJMimzYo_ug" value="LIB_CAT"/>
      </node>
      <node defType="com.stambia.file.field" id="_lLUGOJbFEe-yJMimzYo_ug" name="COD_ART" position="3">
        <attribute defType="com.stambia.file.field.size" id="_lLUGOZbFEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_lLUGOpbFEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_lLUGO5bFEe-yJMimzYo_ug" value="COD_ART"/>
      </node>
    </node>
  </node>
</md:node>