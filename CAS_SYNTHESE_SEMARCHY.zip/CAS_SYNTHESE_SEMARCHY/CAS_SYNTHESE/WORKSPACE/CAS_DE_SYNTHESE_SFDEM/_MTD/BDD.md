<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.rdbms.server" id="_1I9ZsKG9Ee-Mishx4UyKwQ" name="BDD" md:ref="resource.md#UUID_MD_RDBMS_ORACLE?fileId=UUID_MD_RDBMS_ORACLE$type=md$name=Oracle?" internalVersion="v2.0.0">
  <attribute defType="com.stambia.rdbms.server.module" id="_1JDgUKG9Ee-Mishx4UyKwQ" value="Oracle"/>
  <attribute defType="com.stambia.rdbms.server.user" id="_vzdfMKG-Ee-Mishx4UyKwQ" value="CSG2_ORA2"/>
  <attribute defType="com.stambia.rdbms.server.driver" id="_vzeGQKG-Ee-Mishx4UyKwQ" value="oracle.jdbc.OracleDriver"/>
  <attribute defType="com.stambia.rdbms.server.designerAutoCommit" id="_vzeGQaG-Ee-Mishx4UyKwQ" value="true"/>
  <attribute defType="com.stambia.rdbms.server.password" id="_vzetUKG-Ee-Mishx4UyKwQ" value="E7F788CEC6E3C29D5208C7498337A3FA"/>
  <attribute defType="com.stambia.rdbms.server.url" id="_vzetUaG-Ee-Mishx4UyKwQ" value="jdbc:oracle:thin:@195.83.93.26:1521/SIAD_PDB2"/>
  <node defType="com.stambia.rdbms.schema" id="_e0PlAKG-Ee-Mishx4UyKwQ" name="CSG2_ORA2">
    <attribute defType="com.stambia.rdbms.schema.name" id="_e0if8KG-Ee-Mishx4UyKwQ" value="CSG2_ORA2"/>
    <attribute defType="com.stambia.rdbms.schema.rejectMask" id="_e0if8aG-Ee-Mishx4UyKwQ" value="R_[targetName]"/>
    <attribute defType="com.stambia.rdbms.schema.loadMask" id="_e0if8qG-Ee-Mishx4UyKwQ" value="L[number]_[targetName]"/>
    <attribute defType="com.stambia.rdbms.schema.integrationMask" id="_e0jHAKG-Ee-Mishx4UyKwQ" value="I_[targetName]"/>
    <attribute defType="com.stambia.rdbms.schema.dataStoreFilter" id="_A5NCsKHAEe-Mishx4UyKwQ" value=""/>
    <node defType="com.stambia.rdbms.datastore" id="_Ahvk8KHAEe-Mishx4UyKwQ" name="MARQUE">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_Ahvk8aHAEe-Mishx4UyKwQ" value="MARQUE"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_Ahvk8qHAEe-Mishx4UyKwQ" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_Am4joKHAEe-Mishx4UyKwQ" name="COD_MRQ" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_Am4joaHAEe-Mishx4UyKwQ" value="COD_MRQ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Am4joqHAEe-Mishx4UyKwQ" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Am4jo6HAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Am4jpKHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Am4jpaHAEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Am4jpqHAEe-Mishx4UyKwQ" name="LIB_MARQ" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_Am4jp6HAEe-Mishx4UyKwQ" value="LIB_MARQ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Am4jqKHAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Am4jqaHAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Am4jqqHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Am4jq6HAEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_OshIMLJAEe-BObk_rBUyXw" name="DATE_DERN_EXEC" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_OshIMbJAEe-BObk_rBUyXw" value="DATE_DERN_EXEC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_OshIMrJAEe-BObk_rBUyXw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_OshIM7JAEe-BObk_rBUyXw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_OshINLJAEe-BObk_rBUyXw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_OshINbJAEe-BObk_rBUyXw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.pk" id="_Os-bMLJAEe-BObk_rBUyXw" name="PK_MARQUE">
        <node defType="com.stambia.rdbms.colref" id="_Os-bMbJAEe-BObk_rBUyXw" position="1">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_d1tQsLJHEe-7gLO1_RM3Dg" ref="resource.md#_Am4joKHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
        </node>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="__yvw8KG_Ee-Mishx4UyKwQ" name="ARTICLE">
      <attribute defType="com.stambia.rdbms.datastore.name" id="__yvw8aG_Ee-Mishx4UyKwQ" value="ARTICLE"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="__yvw8qG_Ee-Mishx4UyKwQ" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="__4cwUKG_Ee-Mishx4UyKwQ" name="COD_ART" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="__4cwUaG_Ee-Mishx4UyKwQ" value="COD_ART"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4cwUqG_Ee-Mishx4UyKwQ" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4cwU6G_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4cwVKG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4cwVaG_Ee-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4cwVqG_Ee-Mishx4UyKwQ" name="LIB_PRD" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="__4cwV6G_Ee-Mishx4UyKwQ" value="LIB_PRD"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4cwWKG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4cwWaG_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4cwWqG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4cwW6G_Ee-Mishx4UyKwQ" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4dXYKG_Ee-Mishx4UyKwQ" name="LIB_COL" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="__4dXYaG_Ee-Mishx4UyKwQ" value="LIB_COL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4dXYqG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4dXY6G_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4dXZKG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4dXZaG_Ee-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4dXZqG_Ee-Mishx4UyKwQ" name="LIB_TAI" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="__4dXZ6G_Ee-Mishx4UyKwQ" value="LIB_TAI"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4dXaKG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4dXaaG_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4dXaqG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4dXa6G_Ee-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4dXbKG_Ee-Mishx4UyKwQ" name="FAM" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="__4dXbaG_Ee-Mishx4UyKwQ" value="FAM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4dXbqG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4dXb6G_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4dXcKG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4dXcaG_Ee-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4dXcqG_Ee-Mishx4UyKwQ" name="SS_FAM" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="__4dXc6G_Ee-Mishx4UyKwQ" value="SS_FAM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4dXdKG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4dXdaG_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4dXdqG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4dXd6G_Ee-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4d-cKG_Ee-Mishx4UyKwQ" name="PRX_VEN" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="__4d-caG_Ee-Mishx4UyKwQ" value="PRX_VEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4d-cqG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4d-c6G_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4d-dKG_Ee-Mishx4UyKwQ" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4d-daG_Ee-Mishx4UyKwQ" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4d-dqG_Ee-Mishx4UyKwQ" name="LIB_GEN" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="__4d-d6G_Ee-Mishx4UyKwQ" value="LIB_GEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4d-eKG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4d-eaG_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4d-eqG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4d-e6G_Ee-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4d-fKG_Ee-Mishx4UyKwQ" name="CIB_TRN_AGE" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="__4d-faG_Ee-Mishx4UyKwQ" value="CIB_TRN_AGE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4d-fqG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4d-f6G_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4d-gKG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4d-gaG_Ee-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="__4d-gqG_Ee-Mishx4UyKwQ" name="LIB_CAT" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="__4d-g6G_Ee-Mishx4UyKwQ" value="LIB_CAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="__4d-hKG_Ee-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="__4d-haG_Ee-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="__4d-hqG_Ee-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="__4d-h6G_Ee-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_-RNo0LI-Ee-BObk_rBUyXw" name="DATE_DERN_EXEC" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_-RNo0bI-Ee-BObk_rBUyXw" value="DATE_DERN_EXEC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_-RNo0rI-Ee-BObk_rBUyXw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_-RNo07I-Ee-BObk_rBUyXw" value="6"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_-RNo1LI-Ee-BObk_rBUyXw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_-RNo1bI-Ee-BObk_rBUyXw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_-RNo1rI-Ee-BObk_rBUyXw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.pk" id="_j75FcLI_Ee-BObk_rBUyXw" name="PK_ARTICLE">
        <node defType="com.stambia.rdbms.colref" id="_j75FcbI_Ee-BObk_rBUyXw" position="1">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_wyuUULJHEe-7gLO1_RM3Dg" ref="resource.md#__4cwUKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
        </node>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_AypHsKHAEe-Mishx4UyKwQ" name="CALENDRIER">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_AypHsaHAEe-Mishx4UyKwQ" value="CALENDRIER"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_AypHsqHAEe-Mishx4UyKwQ" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_A39skKHAEe-Mishx4UyKwQ" name="COD_CAL" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_A39skaHAEe-Mishx4UyKwQ" value="COD_CAL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A39skqHAEe-Mishx4UyKwQ" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A39sk6HAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A39slKHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_A39slaHAEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_A4G2gKHAEe-Mishx4UyKwQ" name="ANNEE" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_A4G2gaHAEe-Mishx4UyKwQ" value="ANNEE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A4G2gqHAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A4G2g6HAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A4G2hKHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_A4G2haHAEe-Mishx4UyKwQ" value="4"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_A4G2hqHAEe-Mishx4UyKwQ" name="MOIS" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_A4G2h6HAEe-Mishx4UyKwQ" value="MOIS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A4G2iKHAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A4G2iaHAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A4G2iqHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_A4G2i6HAEe-Mishx4UyKwQ" value="2"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_A4G2jKHAEe-Mishx4UyKwQ" name="NUM_JOUR" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_A4G2jaHAEe-Mishx4UyKwQ" value="NUM_JOUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A4G2jqHAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A4G2j6HAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A4G2kKHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_A4G2kaHAEe-Mishx4UyKwQ" value="2"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_A4G2kqHAEe-Mishx4UyKwQ" name="NOM_JOUR" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_A4G2k6HAEe-Mishx4UyKwQ" value="NOM_JOUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A4G2lKHAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A4G2laHAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A4G2lqHAEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_A4G2l6HAEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_A4G2mKHAEe-Mishx4UyKwQ" name="TRIM" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_A4G2maHAEe-Mishx4UyKwQ" value="TRIM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A4G2mqHAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A4G2m6HAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A4G2nKHAEe-Mishx4UyKwQ" value="NUMBER"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_A4G2naHAEe-Mishx4UyKwQ" name="SEMESTRE" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_A4G2nqHAEe-Mishx4UyKwQ" value="SEMESTRE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_A4G2n6HAEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_A4G2oKHAEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_A4G2oaHAEe-Mishx4UyKwQ" value="NUMBER"/>
      </node>
      <node defType="com.stambia.rdbms.pk" id="_HsciQLJBEe-7gLO1_RM3Dg" name="PK_CALENDRIER">
        <node defType="com.stambia.rdbms.colref" id="_HsciQbJBEe-7gLO1_RM3Dg" position="1">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_Ba0kcLJHEe-7gLO1_RM3Dg" ref="resource.md#_A39skKHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL?"/>
        </node>
      </node>
      <node defType="com.stambia.rdbms.column" id="_HsSKMLJBEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_HsSKMbJBEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_HsSKMrJBEe-7gLO1_RM3Dg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_HsSKM7JBEe-7gLO1_RM3Dg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_HsSKNLJBEe-7gLO1_RM3Dg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_HsSKNbJBEe-7gLO1_RM3Dg" value="255"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_iMSXgKHBEe-Mishx4UyKwQ" name="SAS_ARTICLE">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_iMSXgaHBEe-Mishx4UyKwQ" value="SAS_ARTICLE"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_iMSXgqHBEe-Mishx4UyKwQ" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_iPn_YKHBEe-Mishx4UyKwQ" name="COD_ART" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPn_YaHBEe-Mishx4UyKwQ" value="COD_ART"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPn_YqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPn_Y6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPn_ZKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPn_ZaHBEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPn_ZqHBEe-Mishx4UyKwQ" name="LIB_PRD" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPn_Z6HBEe-Mishx4UyKwQ" value="LIB_PRD"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPn_aKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPn_aaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPn_aqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPn_a6HBEe-Mishx4UyKwQ" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPn_bKHBEe-Mishx4UyKwQ" name="LIB_COL" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPn_baHBEe-Mishx4UyKwQ" value="LIB_COL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPn_bqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPn_b6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPn_cKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPn_caHBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPn_cqHBEe-Mishx4UyKwQ" name="LIB_TAI" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPn_c6HBEe-Mishx4UyKwQ" value="LIB_TAI"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPn_dKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPn_daHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPn_dqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPn_d6HBEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPn_eKHBEe-Mishx4UyKwQ" name="FAM" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPn_eaHBEe-Mishx4UyKwQ" value="FAM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPn_eqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPn_e6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPn_fKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPn_faHBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPn_fqHBEe-Mishx4UyKwQ" name="SS_FAM" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPn_f6HBEe-Mishx4UyKwQ" value="SS_FAM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPn_gKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPn_gaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPn_gqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPn_g6HBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPomcKHBEe-Mishx4UyKwQ" name="PRX_VEN" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPomcaHBEe-Mishx4UyKwQ" value="PRX_VEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPomcqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPomc6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPomdKHBEe-Mishx4UyKwQ" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPomdaHBEe-Mishx4UyKwQ" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPomdqHBEe-Mishx4UyKwQ" name="LIB_GEN" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPomd6HBEe-Mishx4UyKwQ" value="LIB_GEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPomeKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPomeaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPomeqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPome6HBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPomfKHBEe-Mishx4UyKwQ" name="CIB_TRN_AGE" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPomfaHBEe-Mishx4UyKwQ" value="CIB_TRN_AGE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPomfqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPomf6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPomgKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPomgaHBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iPomgqHBEe-Mishx4UyKwQ" name="LIB_CAT" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_iPomg6HBEe-Mishx4UyKwQ" value="LIB_CAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iPomhKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iPomhaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iPomhqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iPomh6HBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.check" id="_TchNcacREe-NbvGIo9uaQg" name="COD_ART_CHIFFRE">
        <attribute defType="com.stambia.rdbms.check.sql" id="_UPe7cKcREe-NbvGIo9uaQg" value="REGEXP_LIKE(COD_ART, '^[0-9]+$')"/>
        <attribute defType="com.stambia.rdbms.check.severity" id="_XuR9kKcREe-NbvGIo9uaQg" value="200"/>
      </node>
      <node defType="com.stambia.rdbms.check" id="_zUTaMacYEe-ti-Zc6dspJw" name="PRX_VEN_CHIFFRE">
        <attribute defType="com.stambia.rdbms.check.sql" id="_4iA1MKcYEe-ti-Zc6dspJw" value="REGEXP_LIKE(PRX_VEN, '^[0-9,]+$')"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_iWZVwKHBEe-Mishx4UyKwQ" name="SAS_MARQUE">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_iWZVwaHBEe-Mishx4UyKwQ" value="SAS_MARQUE"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_iWZVwqHBEe-Mishx4UyKwQ" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_iZtIcKHBEe-Mishx4UyKwQ" name="COD_MRQ" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_iZtIcaHBEe-Mishx4UyKwQ" value="COD_MRQ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iZtIcqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iZtIc6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iZtIdKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iZtIdaHBEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iZtIdqHBEe-Mishx4UyKwQ" name="LIB_MARQ" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_iZtId6HBEe-Mishx4UyKwQ" value="LIB_MARQ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iZtIeKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iZtIeaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iZtIeqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iZtIe6HBEe-Mishx4UyKwQ" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.check" id="_6sc-saWzEe-Qv6cAKrauhg" name="COD_MRQ_CONDITION">
        <attribute defType="com.stambia.rdbms.check.sql" id="__MZ70KWzEe-Qv6cAKrauhg" value="REGEXP_LIKE(COD_MRQ, '^[a-zA-Z0-9]+$')"/>
        <attribute defType="com.stambia.rdbms.check.severity" id="_BB_kcKW0Ee-Qv6cAKrauhg" value="200"/>
      </node>
      <node defType="com.stambia.rdbms.check" id="_hud6AacaEe-ti-Zc6dspJw" name="LIB_NULL">
        <attribute defType="com.stambia.rdbms.check.sql" id="_kb37cKcaEe-ti-Zc6dspJw" value="LIB_MARQ is not null"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_iPuGAKHBEe-Mishx4UyKwQ" name="SAS_CALENDRIER">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_iPuGAaHBEe-Mishx4UyKwQ" value="SAS_CALENDRIER"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_iPuGAqHBEe-Mishx4UyKwQ" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_iTBRoKHBEe-Mishx4UyKwQ" name="COD_CAL" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTBRoaHBEe-Mishx4UyKwQ" value="COD_CAL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTBRoqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTBRo6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTBRpKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTBRpaHBEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iTB4sKHBEe-Mishx4UyKwQ" name="ANNEE" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTB4saHBEe-Mishx4UyKwQ" value="ANNEE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTB4sqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTB4s6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTB4tKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTB4taHBEe-Mishx4UyKwQ" value="4"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iTB4tqHBEe-Mishx4UyKwQ" name="MOIS" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTB4t6HBEe-Mishx4UyKwQ" value="MOIS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTB4uKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTB4uaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTB4uqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTB4u6HBEe-Mishx4UyKwQ" value="2"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iTB4vKHBEe-Mishx4UyKwQ" name="NUM_JOUR" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTB4vaHBEe-Mishx4UyKwQ" value="NUM_JOUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTB4vqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTB4v6HBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTB4wKHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTB4waHBEe-Mishx4UyKwQ" value="2"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iTB4wqHBEe-Mishx4UyKwQ" name="NOM_JOUR" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTB4w6HBEe-Mishx4UyKwQ" value="NOM_JOUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTB4xKHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTB4xaHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTB4xqHBEe-Mishx4UyKwQ" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTB4x6HBEe-Mishx4UyKwQ" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iTB4yKHBEe-Mishx4UyKwQ" name="TRIM" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTB4yaHBEe-Mishx4UyKwQ" value="TRIM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTB4yqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_iTB4y6HBEe-Mishx4UyKwQ" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTB4zKHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTB4zaHBEe-Mishx4UyKwQ" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTB4zqHBEe-Mishx4UyKwQ" value="22"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_iTCfwKHBEe-Mishx4UyKwQ" name="SEMESTRE" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_iTCfwaHBEe-Mishx4UyKwQ" value="SEMESTRE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_iTCfwqHBEe-Mishx4UyKwQ" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_iTCfw6HBEe-Mishx4UyKwQ" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_iTCfxKHBEe-Mishx4UyKwQ" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_iTCfxaHBEe-Mishx4UyKwQ" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_iTCfxqHBEe-Mishx4UyKwQ" value="22"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_RLOBwKS3Ee-RkIWF5HwjUw" name="SAS_MAGASIN">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_RLOBwaS3Ee-RkIWF5HwjUw" value="SAS_MAGASIN"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_RLOBwqS3Ee-RkIWF5HwjUw" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_RUvxMKS3Ee-RkIWF5HwjUw" name="COD_MAG" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUvxMaS3Ee-RkIWF5HwjUw" value="COD_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUvxMqS3Ee-RkIWF5HwjUw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUvxM6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUvxNKS3Ee-RkIWF5HwjUw" value="NUMBER"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUwYQKS3Ee-RkIWF5HwjUw" name="LIB_MAG" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUwYQaS3Ee-RkIWF5HwjUw" value="LIB_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUwYQqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUwYQ6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUwYRKS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUwYRaS3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUwYRqS3Ee-RkIWF5HwjUw" name="ADR1" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUwYR6S3Ee-RkIWF5HwjUw" value="ADR1"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUwYSKS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUwYSaS3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUwYSqS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUwYS6S3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUw_UKS3Ee-RkIWF5HwjUw" name="ADR2" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUw_UaS3Ee-RkIWF5HwjUw" value="ADR2"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUw_UqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUw_U6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUw_VKS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUw_VaS3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUw_VqS3Ee-RkIWF5HwjUw" name="ADR3" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUw_V6S3Ee-RkIWF5HwjUw" value="ADR3"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUw_WKS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUw_WaS3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUw_WqS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUw_W6S3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUxmYKS3Ee-RkIWF5HwjUw" name="VIL_MAG" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUxmYaS3Ee-RkIWF5HwjUw" value="VIL_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUxmYqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUxmY6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUxmZKS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUxmZaS3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUyNcKS3Ee-RkIWF5HwjUw" name="DEP_MAG" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUyNcaS3Ee-RkIWF5HwjUw" value="DEP_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUyNcqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUyNc6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUyNdKS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUyNdaS3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUy0gKS3Ee-RkIWF5HwjUw" name="REG_MAG" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUy0gaS3Ee-RkIWF5HwjUw" value="REG_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUy0gqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUy0g6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUy0hKS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUy0haS3Ee-RkIWF5HwjUw" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RUy0hqS3Ee-RkIWF5HwjUw" name="LIB_PAY" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_RUy0h6S3Ee-RkIWF5HwjUw" value="LIB_PAY"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RUy0iKS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RUy0iaS3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RUy0iqS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RUy0i6S3Ee-RkIWF5HwjUw" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU0CoKS3Ee-RkIWF5HwjUw" name="LNG" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU0CoaS3Ee-RkIWF5HwjUw" value="LNG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU0CoqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU0Co6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU0CpKS3Ee-RkIWF5HwjUw" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU0CpaS3Ee-RkIWF5HwjUw" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU0psKS3Ee-RkIWF5HwjUw" name="LAT" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU0psaS3Ee-RkIWF5HwjUw" value="LAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU0psqS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU0ps6S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU0ptKS3Ee-RkIWF5HwjUw" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU0ptaS3Ee-RkIWF5HwjUw" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU130KS3Ee-RkIWF5HwjUw" name="TEL" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU130aS3Ee-RkIWF5HwjUw" value="TEL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU130qS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU1306S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU131KS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU131aS3Ee-RkIWF5HwjUw" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU131qS3Ee-RkIWF5HwjUw" name="EMAIL" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU1316S3Ee-RkIWF5HwjUw" value="EMAIL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU132KS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU132aS3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU132qS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU1326S3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU2e4KS3Ee-RkIWF5HwjUw" name="DAT_OUV" position="14">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU2e4aS3Ee-RkIWF5HwjUw" value="DAT_OUV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU2e4qS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU2e46S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU2e5KS3Ee-RkIWF5HwjUw" value="DATE"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU2e5aS3Ee-RkIWF5HwjUw" value="7"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU2e5qS3Ee-RkIWF5HwjUw" name="DAT_FRM" position="15">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU2e56S3Ee-RkIWF5HwjUw" value="DAT_FRM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU2e6KS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU2e6aS3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU2e6qS3Ee-RkIWF5HwjUw" value="DATE"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU2e66S3Ee-RkIWF5HwjUw" value="7"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU3F8KS3Ee-RkIWF5HwjUw" name="SCHEDULE" position="16">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU3F8aS3Ee-RkIWF5HwjUw" value="SCHEDULE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU3F8qS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU3F86S3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU3F9KS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU3F9aS3Ee-RkIWF5HwjUw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_RU3F9qS3Ee-RkIWF5HwjUw" name="LIB_ENS" position="17">
        <attribute defType="com.stambia.rdbms.column.name" id="_RU3F96S3Ee-RkIWF5HwjUw" value="LIB_ENS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_RU3F-KS3Ee-RkIWF5HwjUw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_RU3F-aS3Ee-RkIWF5HwjUw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_RU3F-qS3Ee-RkIWF5HwjUw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_RU3F-6S3Ee-RkIWF5HwjUw" value="255"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_IESP0KUiEe-NmbL77s4UWw" name="IND_SESSION_FILE_OP_LST">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_IESP0aUiEe-NmbL77s4UWw" value="IND_SESSION_FILE_OP_LST"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_IESP0qUiEe-NmbL77s4UWw" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_Q6D9sKUiEe-NmbL77s4UWw" name="SESS_ID" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6D9saUiEe-NmbL77s4UWw" value="SESS_ID"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6D9sqUiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6D9s6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6D9tKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6D9taUiEe-NmbL77s4UWw" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6FL0KUiEe-NmbL77s4UWw" name="SESS_NAME" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6FL0aUiEe-NmbL77s4UWw" value="SESS_NAME"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6FL0qUiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6FL06UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6FL1KUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6FL1aUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6GZ8KUiEe-NmbL77s4UWw" name="ACT_ID" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6GZ8aUiEe-NmbL77s4UWw" value="ACT_ID"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6GZ8qUiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6GZ86UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6GZ9KUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6GZ9aUiEe-NmbL77s4UWw" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6HBAKUiEe-NmbL77s4UWw" name="ACT_NAME" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6HBAaUiEe-NmbL77s4UWw" value="ACT_NAME"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6HBAqUiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6HBA6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6HBBKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6HBBaUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6IPIKUiEe-NmbL77s4UWw" name="ACT_ITER" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6IPIaUiEe-NmbL77s4UWw" value="ACT_ITER"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6IPIqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6IPI6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6IPJKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6IPJaUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6IPJqUiEe-NmbL77s4UWw" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6JdQKUiEe-NmbL77s4UWw" name="FILE_ID" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6JdQaUiEe-NmbL77s4UWw" value="FILE_ID"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6JdQqUiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6JdQ6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6JdRKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6JdRaUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6JdRqUiEe-NmbL77s4UWw" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6KEUKUiEe-NmbL77s4UWw" name="FILE_OPERATION" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6KrYKUiEe-NmbL77s4UWw" value="FILE_OPERATION"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6KrYaUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6KrYqUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6KrY6UiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6KrZKUiEe-NmbL77s4UWw" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6L5gKUiEe-NmbL77s4UWw" name="FILE_NAME" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6L5gaUiEe-NmbL77s4UWw" value="FILE_NAME"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6L5gqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6L5g6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6L5hKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6L5haUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6MgkKUiEe-NmbL77s4UWw" name="FILE_DIR" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6MgkaUiEe-NmbL77s4UWw" value="FILE_DIR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6MgkqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6Mgk6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6NHoKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6NHoaUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6NusKUiEe-NmbL77s4UWw" name="FILE_FROM_DIR" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6NusaUiEe-NmbL77s4UWw" value="FILE_FROM_DIR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6NusqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6Nus6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6NutKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6NutaUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6OVwKUiEe-NmbL77s4UWw" name="FILE_FROM_FILE" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6OVwaUiEe-NmbL77s4UWw" value="FILE_FROM_FILE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6OVwqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6OVw6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6OVxKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6OVxaUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6OVxqUiEe-NmbL77s4UWw" name="FILE_TO_DIR" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6OVx6UiEe-NmbL77s4UWw" value="FILE_TO_DIR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6OVyKUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6OVyaUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6OVyqUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6OVy6UiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6O80KUiEe-NmbL77s4UWw" name="FILE_TO_FILE" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6O80aUiEe-NmbL77s4UWw" value="FILE_TO_FILE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6O80qUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6O806UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6O81KUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6O81aUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6Pj4KUiEe-NmbL77s4UWw" name="FILE_OPERATION_DATE" position="14">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6Pj4aUiEe-NmbL77s4UWw" value="FILE_OPERATION_DATE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6Pj4qUiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6Pj46UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6Pj5KUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6Pj5aUiEe-NmbL77s4UWw" value="25"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6Pj5qUiEe-NmbL77s4UWw" name="STATUS" position="15">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6Pj56UiEe-NmbL77s4UWw" value="STATUS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6Pj6KUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6Pj6aUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6Pj6qUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6Pj66UiEe-NmbL77s4UWw" value="35"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6QK8KUiEe-NmbL77s4UWw" name="STATUS_COMMENT" position="16">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6QK8aUiEe-NmbL77s4UWw" value="STATUS_COMMENT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6QK8qUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6QK86UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6QK9KUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6QK9aUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6QyAKUiEe-NmbL77s4UWw" name="STATUS_DATE" position="17">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6QyAaUiEe-NmbL77s4UWw" value="STATUS_DATE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6QyAqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6QyA6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6QyBKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6QyBaUiEe-NmbL77s4UWw" value="25"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6RZEKUiEe-NmbL77s4UWw" name="USER_COMMENT" position="18">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6RZEaUiEe-NmbL77s4UWw" value="USER_COMMENT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6RZEqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6RZE6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6RZFKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6RZFaUiEe-NmbL77s4UWw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6SAIKUiEe-NmbL77s4UWw" name="USER_FLAG" position="19">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6SAIaUiEe-NmbL77s4UWw" value="USER_FLAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6SAIqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6SAI6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6SAJKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6SAJaUiEe-NmbL77s4UWw" value="35"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6SnMKUiEe-NmbL77s4UWw" name="USER_DATE" position="20">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6SnMaUiEe-NmbL77s4UWw" value="USER_DATE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6SnMqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6SnM6UiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6SnNKUiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6SnNaUiEe-NmbL77s4UWw" value="25"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6TOQKUiEe-NmbL77s4UWw" name="FILE_IS_HIDDEN" position="21">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6TOQaUiEe-NmbL77s4UWw" value="FILE_IS_HIDDEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6TOQqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6TOQ6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6TORKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6T1UKUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6T1UaUiEe-NmbL77s4UWw" value="1"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6UcYKUiEe-NmbL77s4UWw" name="FILE_LAST_MODIFIED" position="22">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6UcYaUiEe-NmbL77s4UWw" value="FILE_LAST_MODIFIED"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6UcYqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6UcY6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6UcZKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6UcZaUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6UcZqUiEe-NmbL77s4UWw" value="20"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6UcZ6UiEe-NmbL77s4UWw" name="FILE_LAST_MODIFIED_DATE" position="23">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6UcaKUiEe-NmbL77s4UWw" value="FILE_LAST_MODIFIED_DATE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6UcaaUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6UcaqUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6Uca6UiEe-NmbL77s4UWw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6UcbKUiEe-NmbL77s4UWw" value="25"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6VDcKUiEe-NmbL77s4UWw" name="FILE_CAN_READ" position="24">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6VDcaUiEe-NmbL77s4UWw" value="FILE_CAN_READ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6VDcqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6VDc6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6VDdKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6VDdaUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6VDdqUiEe-NmbL77s4UWw" value="1"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6VqgKUiEe-NmbL77s4UWw" name="FILE_CAN_WRITE" position="25">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6VqgaUiEe-NmbL77s4UWw" value="FILE_CAN_WRITE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6VqgqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6Vqg6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6VqhKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6VqhaUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6VqhqUiEe-NmbL77s4UWw" value="1"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6W4oKUiEe-NmbL77s4UWw" name="FILE_CAN_EXECUTE" position="26">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6W4oaUiEe-NmbL77s4UWw" value="FILE_CAN_EXECUTE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6W4oqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6W4o6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6W4pKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6W4paUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6W4pqUiEe-NmbL77s4UWw" value="1"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6YGwKUiEe-NmbL77s4UWw" name="FILE_IS_DIRECTORY" position="27">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6YGwaUiEe-NmbL77s4UWw" value="FILE_IS_DIRECTORY"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6YGwqUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6YGw6UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6YGxKUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6YGxaUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6YGxqUiEe-NmbL77s4UWw" value="1"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Q6Yt0KUiEe-NmbL77s4UWw" name="FILE_LENGTH" position="28">
        <attribute defType="com.stambia.rdbms.column.name" id="_Q6Yt0aUiEe-NmbL77s4UWw" value="FILE_LENGTH"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Q6Yt0qUiEe-NmbL77s4UWw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Q6Yt06UiEe-NmbL77s4UWw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Q6Yt1KUiEe-NmbL77s4UWw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Q6Yt1aUiEe-NmbL77s4UWw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Q6Yt1qUiEe-NmbL77s4UWw" value="20"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_gry1sKcSEe-NbvGIo9uaQg" name="ARTICLES">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_grzcwKcSEe-NbvGIo9uaQg" value="ARTICLES"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_gr0D0KcSEe-NbvGIo9uaQg" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_hGWDsKcSEe-NbvGIo9uaQg" name="COD_MRQ" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGWDsacSEe-NbvGIo9uaQg" value="COD_MRQ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGWDsqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGWDs6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGWDtKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGWDtacSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGX44KcSEe-NbvGIo9uaQg" name="LIB_MRQ" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGX44acSEe-NbvGIo9uaQg" value="LIB_MRQ"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGX44qcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGX446cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGX45KcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGX45acSEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGYf8KcSEe-NbvGIo9uaQg" name="COD_ART" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGYf8acSEe-NbvGIo9uaQg" value="COD_ART"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGYf8qcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGYf86cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGYf9KcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGYf9acSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGZuEKcSEe-NbvGIo9uaQg" name="LIB_PRD" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGZuEacSEe-NbvGIo9uaQg" value="LIB_PRD"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGZuEqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGZuE6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGZuFKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGZuFacSEe-NbvGIo9uaQg" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGa8MKcSEe-NbvGIo9uaQg" name="LIB_COL" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGa8MacSEe-NbvGIo9uaQg" value="LIB_COL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGa8MqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGa8M6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGa8NKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGa8NacSEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGbjQKcSEe-NbvGIo9uaQg" name="LIB_TAI" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGbjQacSEe-NbvGIo9uaQg" value="LIB_TAI"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGbjQqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGbjQ6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGbjRKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGcKUKcSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGcxYKcSEe-NbvGIo9uaQg" name="FAM" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGcxYacSEe-NbvGIo9uaQg" value="FAM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGcxYqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGcxY6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGcxZKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGcxZacSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGd_gKcSEe-NbvGIo9uaQg" name="SS_FAM" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGd_gacSEe-NbvGIo9uaQg" value="SS_FAM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGd_gqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGd_g6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGd_hKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGd_hacSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGfNoKcSEe-NbvGIo9uaQg" name="PRX_VEN" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGfNoacSEe-NbvGIo9uaQg" value="PRX_VEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGfNoqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_hGfNo6cSEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGfNpKcSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGfNpacSEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGfNpqcSEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGf0sKcSEe-NbvGIo9uaQg" name="LIB_GEN" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGf0sacSEe-NbvGIo9uaQg" value="LIB_GEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGf0sqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGf0s6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGf0tKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGf0tacSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGgbwKcSEe-NbvGIo9uaQg" name="CIB_TRN_AGE" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGgbwacSEe-NbvGIo9uaQg" value="CIB_TRN_AGE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGgbwqcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGgbw6cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGgbxKcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGgbxacSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGhp4KcSEe-NbvGIo9uaQg" name="COD_CAT" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGhp4acSEe-NbvGIo9uaQg" value="COD_CAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGhp4qcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGhp46cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGhp5KcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGhp5acSEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_hGiQ8KcSEe-NbvGIo9uaQg" name="LIB_CAT" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_hGiQ8acSEe-NbvGIo9uaQg" value="LIB_CAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_hGiQ8qcSEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_hGiQ86cSEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_hGiQ9KcSEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_hGiQ9acSEe-NbvGIo9uaQg" value="100"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_B-yZAKcWEe-NbvGIo9uaQg" name="TICKETS">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_B-zAEKcWEe-NbvGIo9uaQg" value="TICKETS"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_B-zAEacWEe-NbvGIo9uaQg" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_Cj4qIKcWEe-NbvGIo9uaQg" name="COD_ENS" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj4qIacWEe-NbvGIo9uaQg" value="COD_ENS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj4qIqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj5RMKcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj5RMacWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj5RMqcWEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj54QKcWEe-NbvGIo9uaQg" name="LIB_ENS" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj54QacWEe-NbvGIo9uaQg" value="LIB_ENS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj54QqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj54Q6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj54RKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj54RacWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj6fUKcWEe-NbvGIo9uaQg" name="LIB_MAG" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj6fUacWEe-NbvGIo9uaQg" value="LIB_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj6fUqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj6fU6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj6fVKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj6fVacWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj7GYKcWEe-NbvGIo9uaQg" name="COD_ART" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj7GYacWEe-NbvGIo9uaQg" value="COD_ART"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj7GYqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj7GY6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj7GZKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj7GZacWEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj7tcKcWEe-NbvGIo9uaQg" name="DAT_HEU_TIC" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj7tcacWEe-NbvGIo9uaQg" value="DAT_HEU_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj7tcqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj7tc6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj7tdKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj7tdacWEe-NbvGIo9uaQg" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj7tdqcWEe-NbvGIo9uaQg" name="NUM_TIC" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj7td6cWEe-NbvGIo9uaQg" value="NUM_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj7teKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj7teacWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj8UgKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj8UgacWEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj8UgqcWEe-NbvGIo9uaQg" name="NUM_TIC_LIG" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj8Ug6cWEe-NbvGIo9uaQg" value="NUM_TIC_LIG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj8UhKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj8UhacWEe-NbvGIo9uaQg" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj8UhqcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj8Uh6cWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj8UiKcWEe-NbvGIo9uaQg" value="22"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj8UiacWEe-NbvGIo9uaQg" name="COD_CAI" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj8UiqcWEe-NbvGIo9uaQg" value="COD_CAI"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj8Ui6cWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj8UjKcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj8UjacWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj8UjqcWEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj87kKcWEe-NbvGIo9uaQg" name="COD_VEN" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj87kacWEe-NbvGIo9uaQg" value="COD_VEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj87kqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj87k6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj87lKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj87lacWEe-NbvGIo9uaQg" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj87lqcWEe-NbvGIo9uaQg" name="QTE" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj87l6cWEe-NbvGIo9uaQg" value="QTE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj87mKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj87macWEe-NbvGIo9uaQg" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj87mqcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj87m6cWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj87nKcWEe-NbvGIo9uaQg" value="22"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj87nacWEe-NbvGIo9uaQg" name="MNT_BRU" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj9ioKcWEe-NbvGIo9uaQg" value="MNT_BRU"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj9ioacWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj9ioqcWEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj9io6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj9ipKcWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj9ipacWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj9ipqcWEe-NbvGIo9uaQg" name="MNT_TTC" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj9ip6cWEe-NbvGIo9uaQg" value="MNT_TTC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj9iqKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj9iqacWEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj9iqqcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj9iq6cWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj9irKcWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj9iracWEe-NbvGIo9uaQg" name="COD_DEV" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj9irqcWEe-NbvGIo9uaQg" value="COD_DEV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj-JsKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj-JsacWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj-JsqcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj-Js6cWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj-JtKcWEe-NbvGIo9uaQg" name="TX_TVA" position="14">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj-JtacWEe-NbvGIo9uaQg" value="TX_TVA"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj-JtqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj-Jt6cWEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj-JuKcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj-JuacWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj-JuqcWEe-NbvGIo9uaQg" value="5"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj-Ju6cWEe-NbvGIo9uaQg" name="REM_LIN" position="15">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj-JvKcWEe-NbvGIo9uaQg" value="REM_LIN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj-JvacWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj-JvqcWEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj-Jv6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj-JwKcWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj-JwacWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj-JwqcWEe-NbvGIo9uaQg" name="REM_TIC" position="16">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj-Jw6cWEe-NbvGIo9uaQg" value="REM_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj-JxKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj-JxacWEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj-wwKcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj-wwacWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj-wwqcWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj-ww6cWEe-NbvGIo9uaQg" name="TX_DEV" position="17">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj-wxKcWEe-NbvGIo9uaQg" value="TX_DEV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj-wxacWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_Cj-wxqcWEe-NbvGIo9uaQg" value="2"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj-wx6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj-wyKcWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj-wyacWEe-NbvGIo9uaQg" value="5"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj-wyqcWEe-NbvGIo9uaQg" name="COD_PAY" position="18">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj-wy6cWEe-NbvGIo9uaQg" value="COD_PAY"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj-wzKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj-wzacWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj-wzqcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj-wz6cWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj_X0KcWEe-NbvGIo9uaQg" name="LIB_PAY" position="19">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj_X0acWEe-NbvGIo9uaQg" value="LIB_PAY"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj_X0qcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj_X06cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj_X1KcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj_X1acWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj_X1qcWEe-NbvGIo9uaQg" name="ADR1" position="20">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj_X16cWEe-NbvGIo9uaQg" value="ADR1"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj_X2KcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj_X2acWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj_X2qcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj_X26cWEe-NbvGIo9uaQg" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Cj_-4KcWEe-NbvGIo9uaQg" name="ADR2" position="21">
        <attribute defType="com.stambia.rdbms.column.name" id="_Cj_-4acWEe-NbvGIo9uaQg" value="ADR2"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Cj_-4qcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Cj_-46cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Cj_-5KcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Cj_-5acWEe-NbvGIo9uaQg" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkAl8KcWEe-NbvGIo9uaQg" name="ADR3" position="22">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkAl8acWEe-NbvGIo9uaQg" value="ADR3"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkAl8qcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkAl86cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkAl9KcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkAl9acWEe-NbvGIo9uaQg" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkAl9qcWEe-NbvGIo9uaQg" name="VIL_MAG" position="23">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkAl96cWEe-NbvGIo9uaQg" value="VIL_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkAl-KcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkAl-acWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkAl-qcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkAl-6cWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkBNAKcWEe-NbvGIo9uaQg" name="COD_POS" position="24">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkBNAacWEe-NbvGIo9uaQg" value="COD_POS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkBNAqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkBNA6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkBNBKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkBNBacWEe-NbvGIo9uaQg" value="20"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkB0EKcWEe-NbvGIo9uaQg" name="DEP_MAG" position="25">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkB0EacWEe-NbvGIo9uaQg" value="DEP_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkB0EqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkB0E6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkB0FKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkB0FacWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkB0FqcWEe-NbvGIo9uaQg" name="REG_MAG" position="26">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkB0F6cWEe-NbvGIo9uaQg" value="REG_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkB0GKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkB0GacWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkB0GqcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkB0G6cWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkCbIKcWEe-NbvGIo9uaQg" name="TEL" position="27">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkCbIacWEe-NbvGIo9uaQg" value="TEL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkCbIqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkCbI6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkCbJKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkCbJacWEe-NbvGIo9uaQg" value="20"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkDCMKcWEe-NbvGIo9uaQg" name="EMAIL" position="28">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkDCMacWEe-NbvGIo9uaQg" value="EMAIL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkDCMqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkDCM6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkDCNKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkDCNacWEe-NbvGIo9uaQg" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkDCNqcWEe-NbvGIo9uaQg" name="LNG" position="29">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkDCN6cWEe-NbvGIo9uaQg" value="LNG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkDCOKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_CkDCOacWEe-NbvGIo9uaQg" value="6"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkDCOqcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkDCO6cWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkDCPKcWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkDpQKcWEe-NbvGIo9uaQg" name="LAT" position="30">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkDpQacWEe-NbvGIo9uaQg" value="LAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkDpQqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_CkDpQ6cWEe-NbvGIo9uaQg" value="6"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkDpRKcWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkDpRacWEe-NbvGIo9uaQg" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkDpRqcWEe-NbvGIo9uaQg" value="10"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkDpR6cWEe-NbvGIo9uaQg" name="DAT_OUV" position="31">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkDpSKcWEe-NbvGIo9uaQg" value="DAT_OUV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkEQUKcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkEQUacWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkEQUqcWEe-NbvGIo9uaQg" value="DATE"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkEQU6cWEe-NbvGIo9uaQg" value="7"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkEQVKcWEe-NbvGIo9uaQg" name="DAT_FRM" position="32">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkEQVacWEe-NbvGIo9uaQg" value="DAT_FRM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkEQVqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkEQV6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkEQWKcWEe-NbvGIo9uaQg" value="DATE"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkEQWacWEe-NbvGIo9uaQg" value="7"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_CkE3YKcWEe-NbvGIo9uaQg" name="SCHEDULE" position="33">
        <attribute defType="com.stambia.rdbms.column.name" id="_CkE3YacWEe-NbvGIo9uaQg" value="SCHEDULE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_CkE3YqcWEe-NbvGIo9uaQg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_CkE3Y6cWEe-NbvGIo9uaQg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_CkE3ZKcWEe-NbvGIo9uaQg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_CkE3ZacWEe-NbvGIo9uaQg" value="255"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_qXNxIKcdEe-ti-Zc6dspJw" name="MAGASIN">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_qXO_QKcdEe-ti-Zc6dspJw" value="MAGASIN"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_qXPmUKcdEe-ti-Zc6dspJw" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_q4aZsKcdEe-ti-Zc6dspJw" name="COD_MAG" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4aZsacdEe-ti-Zc6dspJw" value="COD_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4aZsqcdEe-ti-Zc6dspJw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.digits" id="_q4aZs6cdEe-ti-Zc6dspJw" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4aZtKcdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4aZtacdEe-ti-Zc6dspJw" value="NUMBER"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4aZtqcdEe-ti-Zc6dspJw" value="22"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4bAwKcdEe-ti-Zc6dspJw" name="LIB_MAG" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4bAwacdEe-ti-Zc6dspJw" value="LIB_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4bAwqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4bAw6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4bAxKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4bAxacdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4bn0KcdEe-ti-Zc6dspJw" name="ADR1" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4bn0acdEe-ti-Zc6dspJw" value="ADR1"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4cO4KcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4cO4acdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4cO4qcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4cO46cdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4c18KcdEe-ti-Zc6dspJw" name="ADR2" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4c18acdEe-ti-Zc6dspJw" value="ADR2"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4c18qcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4c186cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4c19KcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4c19acdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4ddAKcdEe-ti-Zc6dspJw" name="ADR3" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4ddAacdEe-ti-Zc6dspJw" value="ADR3"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4ddAqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4ddA6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4ddBKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4ddBacdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4eEEKcdEe-ti-Zc6dspJw" name="VIL_MAG" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4eEEacdEe-ti-Zc6dspJw" value="VIL_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4eEEqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4eEE6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4eEFKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4eEFacdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4erIKcdEe-ti-Zc6dspJw" name="DEP_MAG" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4erIacdEe-ti-Zc6dspJw" value="DEP_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4erIqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4erI6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4fSMKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4fSMacdEe-ti-Zc6dspJw" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4f5QKcdEe-ti-Zc6dspJw" name="REG_MAG" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4f5QacdEe-ti-Zc6dspJw" value="REG_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4f5QqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4f5Q6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4f5RKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4f5RacdEe-ti-Zc6dspJw" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4ggUKcdEe-ti-Zc6dspJw" name="LIB_PAY" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4ggUacdEe-ti-Zc6dspJw" value="LIB_PAY"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4ggUqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4ggU6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4ggVKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4ggVacdEe-ti-Zc6dspJw" value="100"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4hHYKcdEe-ti-Zc6dspJw" name="LNG" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4hHYacdEe-ti-Zc6dspJw" value="LNG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4hHYqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4hHY6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4hHZKcdEe-ti-Zc6dspJw" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4hHZacdEe-ti-Zc6dspJw" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4hucKcdEe-ti-Zc6dspJw" name="LAT" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4hucacdEe-ti-Zc6dspJw" value="LAT"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4hucqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4huc6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4hudKcdEe-ti-Zc6dspJw" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4hudacdEe-ti-Zc6dspJw" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4iVgKcdEe-ti-Zc6dspJw" name="TEL" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4iVgacdEe-ti-Zc6dspJw" value="TEL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4iVgqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4iVg6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4iVhKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4iVhacdEe-ti-Zc6dspJw" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4i8kKcdEe-ti-Zc6dspJw" name="EMAIL" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4i8kacdEe-ti-Zc6dspJw" value="EMAIL"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4i8kqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4i8k6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4i8lKcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4i8lacdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4jjoKcdEe-ti-Zc6dspJw" name="DAT_OUV" position="14">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4jjoacdEe-ti-Zc6dspJw" value="DAT_OUV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4jjoqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4jjo6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4jjpKcdEe-ti-Zc6dspJw" value="DATE"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4jjpacdEe-ti-Zc6dspJw" value="7"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4kKsKcdEe-ti-Zc6dspJw" name="DATE_FRM" position="15">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4kKsacdEe-ti-Zc6dspJw" value="DATE_FRM"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4kKsqcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4kKs6cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4kKtKcdEe-ti-Zc6dspJw" value="DATE"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4kKtacdEe-ti-Zc6dspJw" value="7"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4kKtqcdEe-ti-Zc6dspJw" name="SCHEDULE" position="16">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4kxwKcdEe-ti-Zc6dspJw" value="SCHEDULE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4kxwacdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4kxwqcdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4kxw6cdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4kxxKcdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_q4l_4KcdEe-ti-Zc6dspJw" name="LIB_ENS" position="17">
        <attribute defType="com.stambia.rdbms.column.name" id="_q4l_4acdEe-ti-Zc6dspJw" value="LIB_ENS"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_q4l_4qcdEe-ti-Zc6dspJw" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_q4l_46cdEe-ti-Zc6dspJw" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_q4l_5KcdEe-ti-Zc6dspJw" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_q4l_5acdEe-ti-Zc6dspJw" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.pk" id="_q4vJ0KcdEe-ti-Zc6dspJw" name="PK_MAG">
        <node defType="com.stambia.rdbms.colref" id="_q4vJ0acdEe-ti-Zc6dspJw" position="1">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_wytisLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4aZsKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
        </node>
      </node>
      <node defType="com.stambia.rdbms.column" id="_P9rjSLJCEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC" position="18">
        <attribute defType="com.stambia.rdbms.column.name" id="_P9rjSbJCEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_P9rjSrJCEe-7gLO1_RM3Dg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_P9rjS7JCEe-7gLO1_RM3Dg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_P9rjTLJCEe-7gLO1_RM3Dg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_P9rjTbJCEe-7gLO1_RM3Dg" value="255"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_20HWsK5wEe-mg8uIL6AcVA" name="SAS_TICKETDECAISSE">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_20HWsa5wEe-mg8uIL6AcVA" value="SAS_TICKETDECAISSE"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_20HWsq5wEe-mg8uIL6AcVA" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_3CdUsK5wEe-mg8uIL6AcVA" name="CODMAGNUMCAINUMTIC" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_3CdUsa5wEe-mg8uIL6AcVA" value="CODMAGNUMCAINUMTIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_3CdUsq5wEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_3CdUs65wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_3CdUtK5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_3CdUta5wEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_3CfJ4K5wEe-mg8uIL6AcVA" name="COD_DEV" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_3CfJ4a5wEe-mg8uIL6AcVA" value="COD_DEV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_3CfJ4q5wEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_3CfJ465wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_3CfJ5K5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_3CfJ5a5wEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_3Cfw8K5wEe-mg8uIL6AcVA" name="COD_VEN" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_3Cfw8a5wEe-mg8uIL6AcVA" value="COD_VEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_3Cfw8q5wEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_3Cfw865wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_3Cfw9K5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_3Cfw9a5wEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_3CgYAK5wEe-mg8uIL6AcVA" name="DATE_HEURE_TIC" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_3CgYAa5wEe-mg8uIL6AcVA" value="DATE_HEURE_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_3CgYAq5wEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_3CgYA65wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_3CgYBK5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_3CgYBa5wEe-mg8uIL6AcVA" value="50"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_1CfoEK5wEe-mg8uIL6AcVA" name="TICKETDECAISSE">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_1CgPIK5wEe-mg8uIL6AcVA" value="TICKETDECAISSE"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_1Cg2MK5wEe-mg8uIL6AcVA" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_2gAu8K5wEe-mg8uIL6AcVA" name="CODMAGNUMCAINUMTIC" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_2gAu8a5wEe-mg8uIL6AcVA" value="CODMAGNUMCAINUMTIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_2gAu8q5wEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_2gAu865wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_2gBWAK5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_2gBWAa5wEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_2gCkIK5wEe-mg8uIL6AcVA" name="COD_DEV" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_2gCkIa5wEe-mg8uIL6AcVA" value="COD_DEV"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_2gCkIq5wEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_2gCkI65wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_2gCkJK5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_2gCkJa5wEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_2gDLMK5wEe-mg8uIL6AcVA" name="COD_VEN" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_2gDLMa5wEe-mg8uIL6AcVA" value="COD_VEN"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_2gDLMq5wEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_2gDLM65wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_2gDLNK5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_2gDLNa5wEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_2gEZUK5wEe-mg8uIL6AcVA" name="DATE_HEURE_TIC" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_2gEZUa5wEe-mg8uIL6AcVA" value="DATE_HEURE_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_2gEZUq5wEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_2gEZU65wEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_2gEZVK5wEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_2gEZVa5wEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.pk" id="_2z4tMK5wEe-mg8uIL6AcVA" name="PK_TICKETDECAISSE">
        <node defType="com.stambia.rdbms.colref" id="_2z5UQK5wEe-mg8uIL6AcVA" position="1">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_dks1sLJGEe-7gLO1_RM3Dg" ref="resource.md#_2gAu8K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
        </node>
      </node>
      <node defType="com.stambia.rdbms.column" id="_4eYKsLJCEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_4eYKsbJCEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_4eYKsrJCEe-7gLO1_RM3Dg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_4eYKs7JCEe-7gLO1_RM3Dg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_4eYKtLJCEe-7gLO1_RM3Dg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_4eYKtbJCEe-7gLO1_RM3Dg" value="255"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_BdukQK5yEe-mg8uIL6AcVA" name="LIGNETICKET">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_BdvLUK5yEe-mg8uIL6AcVA" value="LIGNETICKET"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_BdvLUa5yEe-mg8uIL6AcVA" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_BrqSkK5yEe-mg8uIL6AcVA" name="CODMAGNUMCAISSENUMTICNUMTICLIG" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrqSka5yEe-mg8uIL6AcVA" value="CODMAGNUMCAISSENUMTICNUMTICLIG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrqSkq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrqSk65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrqSlK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrqSla5yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrqSlq5yEe-mg8uIL6AcVA" name="CODMAGNUMCAISSENUMTIC" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrqSl65yEe-mg8uIL6AcVA" value="CODMAGNUMCAISSENUMTIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrqSmK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrqSma5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrqSmq5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrqSm65yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brq5oK5yEe-mg8uIL6AcVA" name="COD_MAG" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brq5oa5yEe-mg8uIL6AcVA" value="COD_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brq5oq5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brq5o65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brq5pK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brq5pa5yEe-mg8uIL6AcVA" value="2555"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brq5pq5yEe-mg8uIL6AcVA" name="NUM_CAISSE" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brq5p65yEe-mg8uIL6AcVA" value="NUM_CAISSE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brq5qK5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brq5qa5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brq5qq5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brq5q65yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brq5rK5yEe-mg8uIL6AcVA" name="NUM_TIC" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brq5ra5yEe-mg8uIL6AcVA" value="NUM_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brq5rq5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brq5r65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brq5sK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brq5sa5yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrrgsK5yEe-mg8uIL6AcVA" name="NUM_TIC_LIG" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brrgsa5yEe-mg8uIL6AcVA" value="NUM_TIC_LIG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brrgsq5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brrgs65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrrgtK5yEe-mg8uIL6AcVA" value="NUMBER"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brrgta5yEe-mg8uIL6AcVA" name="QTE" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brrgtq5yEe-mg8uIL6AcVA" value="QTE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brrgt65yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrrguK5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brrgua5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brrguq5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brrgu65yEe-mg8uIL6AcVA" name="MNT_BRU" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrrgvK5yEe-mg8uIL6AcVA" value="MNT_BRU"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brrgva5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brrgvq5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brrgv65yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrrgwK5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrsHwK5yEe-mg8uIL6AcVA" name="MNT_TTC" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrsHwa5yEe-mg8uIL6AcVA" value="MNT_TTC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrsHwq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrsHw65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrsHxK5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrsHxa5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrsHxq5yEe-mg8uIL6AcVA" name="MNT_BRU_EUR" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrsHx65yEe-mg8uIL6AcVA" value="MNT_BRU_EUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrsHyK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrsHya5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrsHyq5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrsHy65yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrsHzK5yEe-mg8uIL6AcVA" name="MNT_TTC_EUR" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrsHza5yEe-mg8uIL6AcVA" value="MNT_TTC_EUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrsHzq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrsHz65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrsH0K5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrsH0a5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrsH0q5yEe-mg8uIL6AcVA" name="REM_TIC" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrsH065yEe-mg8uIL6AcVA" value="REM_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrsH1K5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrsH1a5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrsH1q5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrsH165yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brsu0K5yEe-mg8uIL6AcVA" name="COD_MAG_FK" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brsu0a5yEe-mg8uIL6AcVA" value="COD_MAG_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brsu0q5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brsu065yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brsu1K5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brsu1a5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brsu1q5yEe-mg8uIL6AcVA" name="COD_ART_FK" position="14">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brsu165yEe-mg8uIL6AcVA" value="COD_ART_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brsu2K5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brsu2a5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brsu2q5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brsu265yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrtV4K5yEe-mg8uIL6AcVA" name="COD_MRQ_FK" position="15">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrtV4a5yEe-mg8uIL6AcVA" value="COD_MRQ_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrtV4q5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrtV465yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrtV5K5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrtV5a5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrtV5q5yEe-mg8uIL6AcVA" name="COD_CAL_FK" position="16">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrtV565yEe-mg8uIL6AcVA" value="COD_CAL_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brt88K5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brt88a5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brt88q5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brt8865yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Brt89K5yEe-mg8uIL6AcVA" name="COD_ENS_FK" position="17">
        <attribute defType="com.stambia.rdbms.column.name" id="_Brt89a5yEe-mg8uIL6AcVA" value="COD_ENS_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Brt89q5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Brt8965yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Brt8-K5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Brt8-a5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BrukAK5yEe-mg8uIL6AcVA" name="NUM_TIC_FK" position="18">
        <attribute defType="com.stambia.rdbms.column.name" id="_BrukAa5yEe-mg8uIL6AcVA" value="NUM_TIC_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BrukAq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BrukA65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BrukBK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BrukBa5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.pk" id="_Br3t8K5yEe-mg8uIL6AcVA" name="PK_LIGNETICKET">
        <node defType="com.stambia.rdbms.colref" id="_Br3t8a5yEe-mg8uIL6AcVA" position="1">
          <attribute defType="com.stambia.rdbms.colref.ref" id="__IvCgLJFEe-7gLO1_RM3Dg" ref="resource.md#_Brq5oK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
        </node>
        <node defType="com.stambia.rdbms.colref" id="_Br4VAK5yEe-mg8uIL6AcVA" position="2">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_At_wILJGEe-7gLO1_RM3Dg" ref="resource.md#_Brq5pq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_CAISSE?"/>
        </node>
        <node defType="com.stambia.rdbms.colref" id="_Br4VAq5yEe-mg8uIL6AcVA" position="3">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_CJ7ioLJGEe-7gLO1_RM3Dg" ref="resource.md#_Brq5rK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
        </node>
        <node defType="com.stambia.rdbms.colref" id="_Br4VBK5yEe-mg8uIL6AcVA" position="4">
          <attribute defType="com.stambia.rdbms.colref.ref" id="_D-78cLJGEe-7gLO1_RM3Dg" ref="resource.md#_BrrgsK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
        </node>
      </node>
      <node defType="com.stambia.rdbms.column" id="_UixpkLJDEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC" position="19">
        <attribute defType="com.stambia.rdbms.column.name" id="_UixpkbJDEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_UixpkrJDEe-7gLO1_RM3Dg" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Uixpk7JDEe-7gLO1_RM3Dg" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_UixplLJDEe-7gLO1_RM3Dg" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_UixplbJDEe-7gLO1_RM3Dg" value="255"/>
      </node>
    </node>
    <node defType="com.stambia.rdbms.datastore" id="_BExRsK5yEe-mg8uIL6AcVA" name="SAS_LIGNETICKET">
      <attribute defType="com.stambia.rdbms.datastore.name" id="_BExRsa5yEe-mg8uIL6AcVA" value="SAS_LIGNETICKET"/>
      <attribute defType="com.stambia.rdbms.datastore.type" id="_BExRsq5yEe-mg8uIL6AcVA" value="TABLE"/>
      <node defType="com.stambia.rdbms.column" id="_BdYmAK5yEe-mg8uIL6AcVA" name="CODMAGNUMCAISSENUMTICNUMTICLIG" position="1">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdYmAa5yEe-mg8uIL6AcVA" value="CODMAGNUMCAISSENUMTICNUMTICLIG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdYmAq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdYmA65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdYmBK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdYmBa5yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdZNEK5yEe-mg8uIL6AcVA" name="CODMAGNUMCAISSENUMTIC" position="2">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdZNEa5yEe-mg8uIL6AcVA" value="CODMAGNUMCAISSENUMTIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdZNEq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdZNE65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdZNFK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdZNFa5yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdZ0IK5yEe-mg8uIL6AcVA" name="COD_MAG" position="3">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdZ0Ia5yEe-mg8uIL6AcVA" value="COD_MAG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdZ0Iq5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdZ0I65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdZ0JK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdZ0Ja5yEe-mg8uIL6AcVA" value="2555"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdabMK5yEe-mg8uIL6AcVA" name="NUM_CAISSE" position="4">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdabMa5yEe-mg8uIL6AcVA" value="NUM_CAISSE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdabMq5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdabM65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdabNK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdabNa5yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdabNq5yEe-mg8uIL6AcVA" name="NUM_TIC" position="5">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdabN65yEe-mg8uIL6AcVA" value="NUM_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdabOK5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdabOa5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdabOq5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdabO65yEe-mg8uIL6AcVA" value="255"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdbCQK5yEe-mg8uIL6AcVA" name="NUM_TIC_LIG" position="6">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdbCQa5yEe-mg8uIL6AcVA" value="NUM_TIC_LIG"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdbCQq5yEe-mg8uIL6AcVA" value="0"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdbCQ65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdbCRK5yEe-mg8uIL6AcVA" value="NUMBER"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdbCRa5yEe-mg8uIL6AcVA" name="QTE" position="7">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdbCRq5yEe-mg8uIL6AcVA" value="QTE"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdbCR65yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdbCSK5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdbCSa5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdbCSq5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdbpUK5yEe-mg8uIL6AcVA" name="MNT_BRU" position="8">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdbpUa5yEe-mg8uIL6AcVA" value="MNT_BRU"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdbpUq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdbpU65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdbpVK5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdbpVa5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdbpVq5yEe-mg8uIL6AcVA" name="MNT_TTC" position="9">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdbpV65yEe-mg8uIL6AcVA" value="MNT_TTC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdbpWK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdbpWa5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdbpWq5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdbpW65yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdbpXK5yEe-mg8uIL6AcVA" name="MNT_BRU_EUR" position="10">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdbpXa5yEe-mg8uIL6AcVA" value="MNT_BRU_EUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdbpXq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdbpX65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdbpYK5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdbpYa5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdcQYK5yEe-mg8uIL6AcVA" name="MNT_TTC_EUR" position="11">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdcQYa5yEe-mg8uIL6AcVA" value="MNT_TTC_EUR"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdcQYq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdcQY65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdcQZK5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdcQZa5yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdcQZq5yEe-mg8uIL6AcVA" name="REM_TIC" position="12">
        <attribute defType="com.stambia.rdbms.column.name" id="_BdcQZ65yEe-mg8uIL6AcVA" value="REM_TIC"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdcQaK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_BdcQaa5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdcQaq5yEe-mg8uIL6AcVA" value="FLOAT"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdcQa65yEe-mg8uIL6AcVA" value="126"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Bdc3cK5yEe-mg8uIL6AcVA" name="COD_MAG_FK" position="13">
        <attribute defType="com.stambia.rdbms.column.name" id="_Bdc3ca5yEe-mg8uIL6AcVA" value="COD_MAG_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Bdc3cq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Bdc3c65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Bdc3dK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Bdc3da5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Bdc3dq5yEe-mg8uIL6AcVA" name="COD_ART_FK" position="14">
        <attribute defType="com.stambia.rdbms.column.name" id="_Bdc3d65yEe-mg8uIL6AcVA" value="COD_ART_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Bdc3eK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Bdc3ea5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Bdc3eq5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Bdc3e65yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BddegK5yEe-mg8uIL6AcVA" name="COD_MRQ_FK" position="15">
        <attribute defType="com.stambia.rdbms.column.name" id="_Bddega5yEe-mg8uIL6AcVA" value="COD_MRQ_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Bddegq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Bddeg65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BddehK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Bddeha5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Bddehq5yEe-mg8uIL6AcVA" name="COD_CAL_FK" position="16">
        <attribute defType="com.stambia.rdbms.column.name" id="_Bddeh65yEe-mg8uIL6AcVA" value="COD_CAL_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BddeiK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Bddeia5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_Bddeiq5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Bddei65yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_BdesoK5yEe-mg8uIL6AcVA" name="COD_ENS_FK" position="17">
        <attribute defType="com.stambia.rdbms.column.name" id="_Bdesoa5yEe-mg8uIL6AcVA" value="COD_ENS_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_Bdesoq5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Bdeso65yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdespK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_Bdespa5yEe-mg8uIL6AcVA" value="50"/>
      </node>
      <node defType="com.stambia.rdbms.column" id="_Bdespq5yEe-mg8uIL6AcVA" name="NUM_TIC_FK" position="18">
        <attribute defType="com.stambia.rdbms.column.name" id="_Bdesp65yEe-mg8uIL6AcVA" value="NUM_TIC_FK"/>
        <attribute defType="com.stambia.rdbms.column.nullable" id="_BdesqK5yEe-mg8uIL6AcVA" value="1"/>
        <attribute defType="com.stambia.rdbms.column.charByte" id="_Bdesqa5yEe-mg8uIL6AcVA" value="BYTE"/>
        <attribute defType="com.stambia.rdbms.column.type" id="_BdfTsK5yEe-mg8uIL6AcVA" value="VARCHAR2"/>
        <attribute defType="com.stambia.rdbms.column.size" id="_BdfTsa5yEe-mg8uIL6AcVA" value="50"/>
      </node>
    </node>
  </node>
</md:node>