<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.file.server" id="_OMrx0JbGEe-yJMimzYo_ug" md:ref="resource.md#UUID_TECH_FILE_MD?fileId=UUID_TECH_FILE_MD$type=md$name=File?" internalVersion="v2.0.0">
  <node defType="com.stambia.file.directory" id="_OOJKYJbGEe-yJMimzYo_ug" name="File">
    <attribute defType="com.stambia.file.directory.path" id="_OOPRAJbGEe-yJMimzYo_ug" value="${~/PATH_TICKET}$"/>
    <node defType="com.stambia.file.file" id="_OOP4EJbGEe-yJMimzYo_ug" name="Ticket_20240801">
      <attribute defType="com.stambia.file.file.type" id="_OOehkJbGEe-yJMimzYo_ug" value="DELIMITED"/>
      <attribute defType="com.stambia.file.file.charsetName" id="_OOfvsJbGEe-yJMimzYo_ug" value="ISO-8859-15"/>
      <attribute defType="com.stambia.file.file.lineSeparator" id="_OOfvsZbGEe-yJMimzYo_ug" value="0A"/>
      <attribute defType="com.stambia.file.file.fieldSeparator" id="_OOgWwJbGEe-yJMimzYo_ug" value="7C"/>
      <attribute defType="com.stambia.file.file.decimalSeparator" id="_OOgWwpbGEe-yJMimzYo_ug" value="2E"/>
      <attribute defType="com.stambia.file.file.lineToSkip" id="_OOg90JbGEe-yJMimzYo_ug" value="0"/>
      <attribute defType="com.stambia.file.file.lastLineToSkip" id="_OOg90ZbGEe-yJMimzYo_ug" value="0"/>
      <attribute defType="com.stambia.file.file.header" id="_OOhk4JbGEe-yJMimzYo_ug" value="1"/>
      <attribute defType="com.stambia.file.file.physicalName" id="_QJbLUJbGEe-yJMimzYo_ug" value="${~/FILE_NAME}$"/>
      <node defType="com.stambia.file.field" id="_ZbZGb5bGEe-yJMimzYo_ug" name="DAT_OUV" position="31">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGcJbGEe-yJMimzYo_ug" value="60"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGcZbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGcpbGEe-yJMimzYo_ug" value="DAT_OUV"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGKpbGEe-yJMimzYo_ug" name="REM_LIN" position="15">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGK5bGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGLJbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGLZbGEe-yJMimzYo_ug" value="5"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGLpbGEe-yJMimzYo_ug" value="REM_LIN"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGGJbGEe-yJMimzYo_ug" name="MNT_BRU" position="11">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGGZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGGpbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGG5bGEe-yJMimzYo_ug" value="5"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGHJbGEe-yJMimzYo_ug" value="MNT_BRU"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZF9JbGEe-yJMimzYo_ug" name="LIB_ENS" position="2">
        <attribute defType="com.stambia.file.field.size" id="_ZbZF9ZbGEe-yJMimzYo_ug" value="56"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZF9pbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZF95bGEe-yJMimzYo_ug" value="LIB_ENS"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGUZbGEe-yJMimzYo_ug" name="COD_POS" position="24">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGUpbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGU5bGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGVJbGEe-yJMimzYo_ug" value="COD_POS"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGc5bGEe-yJMimzYo_ug" name="DAT_FRM" position="32">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGdJbGEe-yJMimzYo_ug" value="50"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGdZbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGdpbGEe-yJMimzYo_ug" value="DAT_FRM"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGXZbGEe-yJMimzYo_ug" name="TEL" position="27">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGXpbGEe-yJMimzYo_ug" value="67"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGX5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGYJbGEe-yJMimzYo_ug" value="TEL"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGDJbGEe-yJMimzYo_ug" name="COD_CAI" position="8">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGDZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGDpbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGD5bGEe-yJMimzYo_ug" value="COD_CAI"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGEJbGEe-yJMimzYo_ug" name="COD_VEN" position="9">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGEZbGEe-yJMimzYo_ug" value="56"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGEpbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGE5bGEe-yJMimzYo_ug" value="COD_VEN"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGOZbGEe-yJMimzYo_ug" name="COD_PAY" position="18">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGOpbGEe-yJMimzYo_ug" value="52"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGO5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGPJbGEe-yJMimzYo_ug" value="COD_PAY"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGAJbGEe-yJMimzYo_ug" name="DAT_HEU_TIC" position="5">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGAZbGEe-yJMimzYo_ug" value="69"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGApbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGA5bGEe-yJMimzYo_ug" value="DAT_HEU_TIC"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGPZbGEe-yJMimzYo_ug" name="LIB_PAY" position="19">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGPpbGEe-yJMimzYo_ug" value="58"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGP5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGQJbGEe-yJMimzYo_ug" value="LIB_PAY"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZF8JbGEe-yJMimzYo_ug" name="COD_ENS" position="1">
        <attribute defType="com.stambia.file.field.size" id="_ZbZF8ZbGEe-yJMimzYo_ug" value="53"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZF8pbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZF85bGEe-yJMimzYo_ug" value="COD_ENS"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGJpbGEe-yJMimzYo_ug" name="TX_TVA" position="14">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGJ5bGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGKJbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGKZbGEe-yJMimzYo_ug" value="TX_TVA"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGIpbGEe-yJMimzYo_ug" name="COD_DEV" position="13">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGI5bGEe-yJMimzYo_ug" value="53"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGJJbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGJZbGEe-yJMimzYo_ug" value="COD_DEV"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGFJbGEe-yJMimzYo_ug" name="QTE" position="10">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGFZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGFpbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGF5bGEe-yJMimzYo_ug" value="QTE"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGTZbGEe-yJMimzYo_ug" name="VIL_MAG" position="23">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGTpbGEe-yJMimzYo_ug" value="72"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGT5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGUJbGEe-yJMimzYo_ug" value="VIL_MAG"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGVZbGEe-yJMimzYo_ug" name="DEP_MAG" position="25">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGVpbGEe-yJMimzYo_ug" value="67"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGV5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGWJbGEe-yJMimzYo_ug" value="DEP_MAG"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGRZbGEe-yJMimzYo_ug" name="ADR2" position="21">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGRpbGEe-yJMimzYo_ug" value="75"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGR5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGSJbGEe-yJMimzYo_ug" value="ADR2"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGSZbGEe-yJMimzYo_ug" name="ADR3" position="22">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGSpbGEe-yJMimzYo_ug" value="96"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGS5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGTJbGEe-yJMimzYo_ug" value="ADR3"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZF_JbGEe-yJMimzYo_ug" name="COD_ART" position="4">
        <attribute defType="com.stambia.file.field.size" id="_ZbZF_ZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZF_pbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZF_5bGEe-yJMimzYo_ug" value="COD_ART"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGCJbGEe-yJMimzYo_ug" name="NUM_TIC_LIG" position="7">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGCZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGCpbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGC5bGEe-yJMimzYo_ug" value="NUM_TIC_LIG"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGL5bGEe-yJMimzYo_ug" name="REM_TIC" position="16">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGMJbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGMZbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGMpbGEe-yJMimzYo_ug" value="5"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGM5bGEe-yJMimzYo_ug" value="REM_TIC"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGWZbGEe-yJMimzYo_ug" name="REG_MAG" position="26">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGWpbGEe-yJMimzYo_ug" value="76"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGW5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGXJbGEe-yJMimzYo_ug" value="REG_MAG"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGZZbGEe-yJMimzYo_ug" name="LNG" position="29">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGZpbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGZ5bGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGaJbGEe-yJMimzYo_ug" value="7"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGaZbGEe-yJMimzYo_ug" value="LNG"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGd5bGEe-yJMimzYo_ug" name="SCHEDULE" position="33">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGeJbGEe-yJMimzYo_ug" value="210"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGeZbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGepbGEe-yJMimzYo_ug" value="SCHEDULE"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGQZbGEe-yJMimzYo_ug" name="ADR1" position="20">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGQpbGEe-yJMimzYo_ug" value="82"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGQ5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGRJbGEe-yJMimzYo_ug" value="ADR1"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGapbGEe-yJMimzYo_ug" name="LAT" position="30">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGa5bGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGbJbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGbZbGEe-yJMimzYo_ug" value="6"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGbpbGEe-yJMimzYo_ug" value="LAT"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZF-JbGEe-yJMimzYo_ug" name="LIB_MAG" position="3">
        <attribute defType="com.stambia.file.field.size" id="_ZbZF-ZbGEe-yJMimzYo_ug" value="75"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZF-pbGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZF-5bGEe-yJMimzYo_ug" value="LIB_MAG"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGBJbGEe-yJMimzYo_ug" name="NUM_TIC" position="6">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGBZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGBpbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGB5bGEe-yJMimzYo_ug" value="NUM_TIC"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGHZbGEe-yJMimzYo_ug" name="MNT_TTC" position="12">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGHpbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGH5bGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGIJbGEe-yJMimzYo_ug" value="5"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGIZbGEe-yJMimzYo_ug" value="MNT_TTC"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGYZbGEe-yJMimzYo_ug" name="EMAIL" position="28">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGYpbGEe-yJMimzYo_ug" value="65"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGY5bGEe-yJMimzYo_ug" value="String"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGZJbGEe-yJMimzYo_ug" value="EMAIL"/>
      </node>
      <node defType="com.stambia.file.field" id="_ZbZGNJbGEe-yJMimzYo_ug" name="TX_DEV" position="17">
        <attribute defType="com.stambia.file.field.size" id="_ZbZGNZbGEe-yJMimzYo_ug" value="12"/>
        <attribute defType="com.stambia.file.field.type" id="_ZbZGNpbGEe-yJMimzYo_ug" value="Numeric"/>
        <attribute defType="com.stambia.file.field.decimal" id="_ZbZGN5bGEe-yJMimzYo_ug" value="5"/>
        <attribute defType="com.stambia.file.field.physicalName" id="_ZbZGOJbGEe-yJMimzYo_ug" value="TX_DEV"/>
      </node>
    </node>
  </node>
</md:node>