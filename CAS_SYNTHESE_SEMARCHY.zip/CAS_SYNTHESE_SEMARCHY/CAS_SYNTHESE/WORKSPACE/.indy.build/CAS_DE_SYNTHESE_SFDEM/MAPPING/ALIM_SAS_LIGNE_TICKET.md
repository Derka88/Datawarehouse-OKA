<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_rL-c0KdHEe--zpA73GUozQ-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_hgPqIbAVEe-mg8uIL6AcVA">
    <attribute defType="com.stambia.flow.altId.origin" id="_hgPqIrAVEe-mg8uIL6AcVA" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_hgPqI7AVEe-mg8uIL6AcVA" value="_rL-c0KdHEe--zpA73GUozQ"/>
  </node>
  <node defType="com.stambia.flow.step" id="25f580bb-6a10-32eb-9384-c9938d40a8a0" name="I1_SAS_LIGNETICKET">
    <attribute defType="com.stambia.flow.step.number" id="_hhPvsbAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_hhPvsrAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_hhPvs7AVEe-mg8uIL6AcVA" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_hhPvtLAVEe-mg8uIL6AcVA" name="ARTICLES">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvtbAVEe-mg8uIL6AcVA" value="$MD_17"/>
    </node>
    <node defType="com.stambia.flow.source" id="_hhPvtrAVEe-mg8uIL6AcVA" name="SAS_MAGASIN">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvt7AVEe-mg8uIL6AcVA" value="$MD_18"/>
    </node>
    <node defType="com.stambia.flow.source" id="_hhPvuLAVEe-mg8uIL6AcVA" name="SAS_MARQUE">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvubAVEe-mg8uIL6AcVA" value="$MD_19"/>
    </node>
    <node defType="com.stambia.flow.source" id="_hhPvurAVEe-mg8uIL6AcVA" name="SAS_CALENDRIER">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvu7AVEe-mg8uIL6AcVA" value="$MD_20"/>
    </node>
    <node defType="com.stambia.flow.source" id="_hhPvvLAVEe-mg8uIL6AcVA" name="TICKETS">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvvbAVEe-mg8uIL6AcVA" value="$MD_21"/>
    </node>
    <node defType="com.stambia.flow.source" id="_hhPvvrAVEe-mg8uIL6AcVA" name="SAS_TICKETDECAISSE">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvv7AVEe-mg8uIL6AcVA" value="$MD_22"/>
    </node>
    <node defType="com.stambia.flow.source" id="_hhPvwLAVEe-mg8uIL6AcVA" name="SAS_ARTICLE">
      <attribute defType="com.stambia.flow.source.target" id="_hhPvwbAVEe-mg8uIL6AcVA" value="$MD_23"/>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPvwrAVEe-mg8uIL6AcVA" name="COD_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPvw7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPvxLAVEe-mg8uIL6AcVA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPvxbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPvxrAVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPvx7AVEe-mg8uIL6AcVA">
        <values>$MD_38</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPvyLAVEe-mg8uIL6AcVA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPvybAVEe-mg8uIL6AcVA" ref="resource.md#_BdZ0IK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPvyrAVEe-mg8uIL6AcVA" value="'SAS_MAGASIN.%{MD_38}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPvy7AVEe-mg8uIL6AcVA" value="COD_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPvzLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPvzbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPvzrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPvz7AVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN.%{MD_38}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPv0LAVEe-mg8uIL6AcVA" name="NUM_CAISSE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPv0bAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPv0rAVEe-mg8uIL6AcVA" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPv07AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPv1LAVEe-mg8uIL6AcVA">
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPv1bAVEe-mg8uIL6AcVA">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPv1rAVEe-mg8uIL6AcVA" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPv17AVEe-mg8uIL6AcVA" ref="resource.md#_BdabMK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_CAISSE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPv2LAVEe-mg8uIL6AcVA" value="'INSTR(SAS_TICKETDECAISSE.%{MD_26}%, ''_'', 1, 2) - INSTR(SAS_TICKETDECAISSE.%{MD_26}%, ''_'') - 1'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPv2bAVEe-mg8uIL6AcVA" value="NUM_CAISSE"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPv2rAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPv27AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPv3LAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPv3bAVEe-mg8uIL6AcVA">
        <values>SAS_TICKETDECAISSE.%{MD_26}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPv3rAVEe-mg8uIL6AcVA" name="NUM_TIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPv37AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPv4LAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPv4bAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPv4rAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPv47AVEe-mg8uIL6AcVA">
        <values>$MD_29</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPv5LAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPv5bAVEe-mg8uIL6AcVA" ref="resource.md#_BdabNq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPv5rAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_29}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPv57AVEe-mg8uIL6AcVA" value="NUM_TIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPv6LAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPv6bAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPv6rAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPv67AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_29}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPv7LAVEe-mg8uIL6AcVA" name="NUM_TIC_LIG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPv7bAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPv7rAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPv77AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPv8LAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPv8bAVEe-mg8uIL6AcVA">
        <values>$MD_39</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPv8rAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPv87AVEe-mg8uIL6AcVA" ref="resource.md#_BdbCQK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPv9LAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_39}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPv9bAVEe-mg8uIL6AcVA" value="NUM_TIC_LIG"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPv9rAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPv97AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPv-LAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPv-bAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_39}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPv-rAVEe-mg8uIL6AcVA" name="QTE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPv-7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPv_LAVEe-mg8uIL6AcVA" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPv_bAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPv_rAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPv_7AVEe-mg8uIL6AcVA">
        <values>$MD_30</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwALAVEe-mg8uIL6AcVA" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwAbAVEe-mg8uIL6AcVA" ref="resource.md#_BdbCRa5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwArAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_30}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwA7AVEe-mg8uIL6AcVA" value="QTE"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwBLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwBbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwBrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwB7AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_30}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwCLAVEe-mg8uIL6AcVA" name="MNT_BRU">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwCbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwCrAVEe-mg8uIL6AcVA" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwC7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwDLAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwDbAVEe-mg8uIL6AcVA">
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwDrAVEe-mg8uIL6AcVA" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwD7AVEe-mg8uIL6AcVA" ref="resource.md#_BdbpUK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwELAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_24}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwEbAVEe-mg8uIL6AcVA" value="MNT_BRU"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwErAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwE7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwFLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwFbAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_24}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwFrAVEe-mg8uIL6AcVA" name="MNT_TTC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwF7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwGLAVEe-mg8uIL6AcVA" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwGbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwGrAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwG7AVEe-mg8uIL6AcVA">
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwHLAVEe-mg8uIL6AcVA" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwHbAVEe-mg8uIL6AcVA" ref="resource.md#_BdbpVq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwHrAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_33}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwH7AVEe-mg8uIL6AcVA" value="MNT_TTC"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwILAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwIbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwIrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwI7AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_33}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwJLAVEe-mg8uIL6AcVA" name="MNT_BRU_EUR">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwJbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwJrAVEe-mg8uIL6AcVA" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwJ7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwKLAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwKbAVEe-mg8uIL6AcVA">
        <values>$MD_25</values>
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwKrAVEe-mg8uIL6AcVA" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwK7AVEe-mg8uIL6AcVA" ref="resource.md#_BdbpXK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU_EUR?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwLLAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_24}% / TICKETS.%{MD_25}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwLbAVEe-mg8uIL6AcVA" value="MNT_BRU_EUR"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwLrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwL7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwMLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwMbAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_24}%</values>
        <values>TICKETS.%{MD_25}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwMrAVEe-mg8uIL6AcVA" name="MNT_TTC_EUR">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwM7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwNLAVEe-mg8uIL6AcVA" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwNbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwNrAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwN7AVEe-mg8uIL6AcVA">
        <values>$MD_25</values>
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwOLAVEe-mg8uIL6AcVA" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwObAVEe-mg8uIL6AcVA" ref="resource.md#_BdcQYK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC_EUR?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwOrAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_33}% / TICKETS.%{MD_25}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwO7AVEe-mg8uIL6AcVA" value="MNT_TTC_EUR"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwPLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwPbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwPrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwP7AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_33}%</values>
        <values>TICKETS.%{MD_25}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwQLAVEe-mg8uIL6AcVA" name="REM_TIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwQbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwQrAVEe-mg8uIL6AcVA" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwQ7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwRLAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwRbAVEe-mg8uIL6AcVA">
        <values>$MD_35</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwRrAVEe-mg8uIL6AcVA" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwR7AVEe-mg8uIL6AcVA" ref="resource.md#_BdcQZq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwSLAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_35}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwSbAVEe-mg8uIL6AcVA" value="REM_TIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwSrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwS7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwTLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwTbAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_35}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwTrAVEe-mg8uIL6AcVA" name="COD_MAG_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwT7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwULAVEe-mg8uIL6AcVA" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwUbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwUrAVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwU7AVEe-mg8uIL6AcVA">
        <values>$MD_38</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwVLAVEe-mg8uIL6AcVA" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwVbAVEe-mg8uIL6AcVA" ref="resource.md#_Bdc3cK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwVrAVEe-mg8uIL6AcVA" value="'SAS_MAGASIN.%{MD_38}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwV7AVEe-mg8uIL6AcVA" value="COD_MAG_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwWLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwWbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwWrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwW7AVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN.%{MD_38}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwXLAVEe-mg8uIL6AcVA" name="COD_ART_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwXbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwXrAVEe-mg8uIL6AcVA" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwX7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwYLAVEe-mg8uIL6AcVA">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwYbAVEe-mg8uIL6AcVA">
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwYrAVEe-mg8uIL6AcVA" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwY7AVEe-mg8uIL6AcVA" ref="resource.md#_Bdc3dq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwZLAVEe-mg8uIL6AcVA" value="'SAS_ARTICLE.%{MD_31}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwZbAVEe-mg8uIL6AcVA" value="COD_ART_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwZrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwZ7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwaLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwabAVEe-mg8uIL6AcVA">
        <values>SAS_ARTICLE.%{MD_31}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwarAVEe-mg8uIL6AcVA" name="COD_MRQ_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwa7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwbLAVEe-mg8uIL6AcVA" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwbbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwbrAVEe-mg8uIL6AcVA">
        <values>SAS_MARQUE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwb7AVEe-mg8uIL6AcVA">
        <values>$MD_34</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwcLAVEe-mg8uIL6AcVA" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwcbAVEe-mg8uIL6AcVA" ref="resource.md#_BddegK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwcrAVEe-mg8uIL6AcVA" value="'SAS_MARQUE.%{MD_34}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwc7AVEe-mg8uIL6AcVA" value="COD_MRQ_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwdLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwdbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwdrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwd7AVEe-mg8uIL6AcVA">
        <values>SAS_MARQUE.%{MD_34}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPweLAVEe-mg8uIL6AcVA" name="COD_CAL_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwebAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwerAVEe-mg8uIL6AcVA" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwe7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwfLAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwfbAVEe-mg8uIL6AcVA">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwfrAVEe-mg8uIL6AcVA" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwf7AVEe-mg8uIL6AcVA" ref="resource.md#_Bddehq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwgLAVEe-mg8uIL6AcVA" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_27}%, ''DD-MM-YYYY HH24:MI:SS''), ''YYYYMMDD'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwgbAVEe-mg8uIL6AcVA" value="COD_CAL_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwgrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwg7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwhLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwhbAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_27}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwhrAVEe-mg8uIL6AcVA" name="COD_ENS_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwh7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwiLAVEe-mg8uIL6AcVA" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwibAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwirAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwi7AVEe-mg8uIL6AcVA">
        <values>$MD_36</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwjLAVEe-mg8uIL6AcVA" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwjbAVEe-mg8uIL6AcVA" ref="resource.md#_BdesoK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwjrAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_36}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwj7AVEe-mg8uIL6AcVA" value="COD_ENS_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwkLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwkbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwkrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwk7AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_36}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hhPwlLAVEe-mg8uIL6AcVA" name="NUM_TIC_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hhPwlbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hhPwlrAVEe-mg8uIL6AcVA" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.location" id="_hhPwl7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hhPwmLAVEe-mg8uIL6AcVA">
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hhPwmbAVEe-mg8uIL6AcVA">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hhPwmrAVEe-mg8uIL6AcVA" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hhPwm7AVEe-mg8uIL6AcVA" ref="resource.md#_Bdespq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hhPwnLAVEe-mg8uIL6AcVA" value="'SUBSTR(SAS_TICKETDECAISSE.%{MD_26}%, INSTR(SAS_TICKETDECAISSE.%{MD_26}%, ''_'', 1, 2) + 1)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hhPwnbAVEe-mg8uIL6AcVA" value="NUM_TIC_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_hhPwnrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hhPwn7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hhPwoLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hhPwobAVEe-mg8uIL6AcVA">
        <values>SAS_TICKETDECAISSE.%{MD_26}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_IJzx8Kf0Ee-gyuxKNABDpQ">
      <attribute defType="com.stambia.flow.join.expr" id="_hhPwo7AVEe-mg8uIL6AcVA" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_27}%, ''DD-MM-YYYY HH24:MI:SS''), ''YYYYMMDD'') = SAS_CALENDRIER.%{MD_28}%'"/>
      <attribute defType="com.stambia.flow.join.left" id="_hhPwpLAVEe-mg8uIL6AcVA" value="TICKETS"/>
      <attribute defType="com.stambia.flow.join.right" id="_hhPwpbAVEe-mg8uIL6AcVA" value="SAS_CALENDRIER"/>
      <attribute defType="com.stambia.flow.join.order" id="_hhPwprAVEe-mg8uIL6AcVA" value="110"/>
      <attribute defType="com.stambia.flow.join.type" id="_hhPwp7AVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_hhPwqLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_hhPwqbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
        <values>SAS_CALENDRIER</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_hhPwqrAVEe-mg8uIL6AcVA">
        <values>$MD_27</values>
        <values>$MD_28</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_hhPwq7AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_27}%</values>
        <values>SAS_CALENDRIER.%{MD_28}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_IExdwKfwEe-gyuxKNABDpQ">
      <attribute defType="com.stambia.flow.join.expr" id="_hhPwrbAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_37}% = SAS_ARTICLE.%{MD_31}%'"/>
      <attribute defType="com.stambia.flow.join.left" id="_hhPwrrAVEe-mg8uIL6AcVA" value="ARTICLES"/>
      <attribute defType="com.stambia.flow.join.right" id="_hhPwr7AVEe-mg8uIL6AcVA" value="SAS_ARTICLE"/>
      <attribute defType="com.stambia.flow.join.order" id="_hhPwsLAVEe-mg8uIL6AcVA" value="70"/>
      <attribute defType="com.stambia.flow.join.type" id="_hhPwsbAVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_hhPwsrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_hhPws7AVEe-mg8uIL6AcVA">
        <values>SAS_ARTICLE</values>
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_hhPwtLAVEe-mg8uIL6AcVA">
        <values>$MD_31</values>
        <values>$MD_37</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_hhPwtbAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_37}%</values>
        <values>SAS_ARTICLE.%{MD_31}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_pH3OwKfxEe-gyuxKNABDpQ">
      <attribute defType="com.stambia.flow.join.expr" id="_hhPwt7AVEe-mg8uIL6AcVA" value="'SUBSTR(SAS_TICKETDECAISSE.%{MD_26}%, INSTR(SAS_TICKETDECAISSE.%{MD_26}%, ''_'', 1, 2) + 1)= TICKETS.%{MD_29}%&#xA;'"/>
      <attribute defType="com.stambia.flow.join.left" id="_hhPwuLAVEe-mg8uIL6AcVA" value="SAS_TICKETDECAISSE"/>
      <attribute defType="com.stambia.flow.join.right" id="_hhPwubAVEe-mg8uIL6AcVA" value="TICKETS"/>
      <attribute defType="com.stambia.flow.join.order" id="_hhPwurAVEe-mg8uIL6AcVA" value="90"/>
      <attribute defType="com.stambia.flow.join.type" id="_hhPwu7AVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_hhPwvLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_hhPwvbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_hhPwvrAVEe-mg8uIL6AcVA">
        <values>$MD_29</values>
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_hhPwv7AVEe-mg8uIL6AcVA">
        <values>SAS_TICKETDECAISSE.%{MD_26}%</values>
        <values>TICKETS.%{MD_29}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_kXFMIKdIEe--zpA73GUozQ">
      <attribute defType="com.stambia.flow.join.expr" id="_hhPwwbAVEe-mg8uIL6AcVA" value="'SAS_MAGASIN.%{MD_40}% = TICKETS.%{MD_41}%'"/>
      <attribute defType="com.stambia.flow.join.left" id="_hhPwwrAVEe-mg8uIL6AcVA" value="SAS_MAGASIN"/>
      <attribute defType="com.stambia.flow.join.right" id="_hhPww7AVEe-mg8uIL6AcVA" value="TICKETS"/>
      <attribute defType="com.stambia.flow.join.order" id="_hhPwxLAVEe-mg8uIL6AcVA" value="10"/>
      <attribute defType="com.stambia.flow.join.type" id="_hhPwxbAVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_hhPwxrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_hhPwx7AVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN</values>
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_hhPwyLAVEe-mg8uIL6AcVA">
        <values>$MD_40</values>
        <values>$MD_41</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_hhPwybAVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN.%{MD_40}%</values>
        <values>TICKETS.%{MD_41}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_K8eVAKd_Ee-ki7obfdU69A">
      <attribute defType="com.stambia.flow.join.expr" id="_hhPwy7AVEe-mg8uIL6AcVA" value="'SAS_ARTICLE.%{MD_31}% = TICKETS.%{MD_32}%'"/>
      <attribute defType="com.stambia.flow.join.left" id="_hhPwzLAVEe-mg8uIL6AcVA" value="SAS_ARTICLE"/>
      <attribute defType="com.stambia.flow.join.right" id="_hhPwzbAVEe-mg8uIL6AcVA" value="TICKETS"/>
      <attribute defType="com.stambia.flow.join.order" id="_hhPwzrAVEe-mg8uIL6AcVA" value="30"/>
      <attribute defType="com.stambia.flow.join.type" id="_hhPwz7AVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_hhPw0LAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_hhPw0bAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_hhPw0rAVEe-mg8uIL6AcVA">
        <values>$MD_32</values>
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_hhPw07AVEe-mg8uIL6AcVA">
        <values>SAS_ARTICLE.%{MD_31}%</values>
        <values>TICKETS.%{MD_32}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_HRveUKfwEe-gyuxKNABDpQ">
      <attribute defType="com.stambia.flow.join.expr" id="_hhPw1bAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_42}% = SAS_MARQUE.%{MD_34}%'"/>
      <attribute defType="com.stambia.flow.join.left" id="_hhPw1rAVEe-mg8uIL6AcVA" value="ARTICLES"/>
      <attribute defType="com.stambia.flow.join.right" id="_hhPw17AVEe-mg8uIL6AcVA" value="SAS_MARQUE"/>
      <attribute defType="com.stambia.flow.join.order" id="_hhPw2LAVEe-mg8uIL6AcVA" value="50"/>
      <attribute defType="com.stambia.flow.join.type" id="_hhPw2bAVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_hhPw2rAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_hhPw27AVEe-mg8uIL6AcVA">
        <values>SAS_MARQUE</values>
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_hhPw3LAVEe-mg8uIL6AcVA">
        <values>$MD_34</values>
        <values>$MD_42</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_hhPw3bAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_42}%</values>
        <values>SAS_MARQUE.%{MD_34}%</values>
      </attribute>
    </node>
  </node>
  <metaDataLink name="MD_17" target="resource.md#_gry1sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ARTICLES?"/>
  <metaDataLink name="MD_33" target="resource.md#_Cj9ipqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
  <metaDataLink name="MD_32" target="resource.md#_Cj7GYKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_12" target="resource.md#_Bdc3dq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_FK?"/>
  <metaDataLink name="MD_31" target="resource.md#_iPn_YKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_6" target="resource.md#_BdbpUK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
  <metaDataLink name="MD_30" target="resource.md#_Cj87lqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
  <metaDataLink name="MD_2" target="resource.md#_BdabMK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_CAISSE?"/>
  <metaDataLink name="MD_26" target="resource.md#_3CdUsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
  <metaDataLink name="MD_35" target="resource.md#_Cj-JwqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
  <metaDataLink name="MD_21" target="resource.md#_B-yZAKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TICKETS?"/>
  <metaDataLink name="MD_16" target="resource.md#_Bdespq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_FK?"/>
  <metaDataLink name="MD_40" target="resource.md#_RUwYQKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_11" target="resource.md#_Bdc3cK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_FK?"/>
  <metaDataLink name="MD_9" target="resource.md#_BdcQYK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC_EUR?"/>
  <metaDataLink name="MD_7" target="resource.md#_BdbpVq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
  <metaDataLink name="MD_34" target="resource.md#_iZtIcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_42" target="resource.md#_hGWDsKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_25" target="resource.md#_Cj-ww6cWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TX_DEV?"/>
  <metaDataLink name="MD_20" target="resource.md#_iPuGAKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_CALENDRIER?"/>
  <metaDataLink name="MD_24" target="resource.md#_Cj87nacWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
  <metaDataLink name="MD_41" target="resource.md#_Cj6fUKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_10" target="resource.md#_BdcQZq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
  <metaDataLink name="MD_29" target="resource.md#_Cj7tdqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
  <metaDataLink name="MD_37" target="resource.md#_hGYf8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_5" target="resource.md#_BdbCRa5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
  <metaDataLink name="MD_39" target="resource.md#_Cj8UgqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
  <metaDataLink name="MD_18" target="resource.md#_RLOBwKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MAGASIN?"/>
  <metaDataLink name="MD_3" target="resource.md#_BdabNq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
  <metaDataLink name="MD_4" target="resource.md#_BdbCQK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
  <metaDataLink name="MD_23" target="resource.md#_iMSXgKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_ARTICLE?"/>
  <metaDataLink name="MD_38" target="resource.md#_RUvxMKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
  <metaDataLink name="MD_13" target="resource.md#_BddegK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_FK?"/>
  <metaDataLink name="MD_15" target="resource.md#_BdesoK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS_FK?"/>
  <metaDataLink name="MD_27" target="resource.md#_Cj7tcKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_HEU_TIC?"/>
  <metaDataLink name="MD_0" target="resource.md#_BExRsK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_LIGNETICKET?"/>
  <metaDataLink name="MD_19" target="resource.md#_iWZVwKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MARQUE?"/>
  <metaDataLink name="MD_14" target="resource.md#_Bddehq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL_FK?"/>
  <metaDataLink name="MD_22" target="resource.md#_20HWsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_TICKETDECAISSE?"/>
  <metaDataLink name="MD_28" target="resource.md#_iTBRoKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL?"/>
  <metaDataLink name="MD_36" target="resource.md#_Cj4qIKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS?"/>
  <metaDataLink name="MD_8" target="resource.md#_BdbpXK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU_EUR?"/>
  <metaDataLink name="MD_1" target="resource.md#_BdZ0IK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
</md:node>