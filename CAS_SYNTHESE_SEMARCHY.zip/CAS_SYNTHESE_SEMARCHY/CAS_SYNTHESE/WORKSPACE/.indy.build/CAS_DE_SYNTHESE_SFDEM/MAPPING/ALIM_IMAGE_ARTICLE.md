<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_ngSBQKcSEe-NbvGIo9uaQg-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_BQqH4ac7Ee-MsNEJBkvyXQ">
    <attribute defType="com.stambia.flow.altId.origin" id="_BQqH4qc7Ee-MsNEJBkvyXQ" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_BQqH46c7Ee-MsNEJBkvyXQ" value="_ngSBQKcSEe-NbvGIo9uaQg"/>
  </node>
  <node defType="com.stambia.flow.step" id="43928e9b-c91b-309d-9e3f-f6bbe02a5da6" name="I1_ARTICLES">
    <attribute defType="com.stambia.flow.step.number" id="_BQtLMac7Ee-MsNEJBkvyXQ" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_BQtLMqc7Ee-MsNEJBkvyXQ" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_BQtLM6c7Ee-MsNEJBkvyXQ" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_BQtLNKc7Ee-MsNEJBkvyXQ" name="L1_ARTICLES">
      <attribute defType="com.stambia.flow.source.stepName" id="_BQtLNac7Ee-MsNEJBkvyXQ" value="L1_ARTICLES"/>
      <attribute defType="com.stambia.flow.source.number" id="_BQtLNqc7Ee-MsNEJBkvyXQ" value="1"/>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtLN6c7Ee-MsNEJBkvyXQ" name="L1_COD_MRQ">
      <attribute defType="com.stambia.flow.field.base" id="_BQtLOKc7Ee-MsNEJBkvyXQ" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtLOac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtLOqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtLO6c7Ee-MsNEJBkvyXQ" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtLPKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGWDsKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtLPac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L1_COD_MRQ'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtLPqc7Ee-MsNEJBkvyXQ" value="L1_COD_MRQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtLP6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyQKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyQac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyQqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L1_COD_MRQ</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyQ6c7Ee-MsNEJBkvyXQ" name="L2_LIB_MRQ">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyRKc7Ee-MsNEJBkvyXQ" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyRac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyRqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyR6c7Ee-MsNEJBkvyXQ" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtySKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGX44KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MRQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtySac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L2_LIB_MRQ'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtySqc7Ee-MsNEJBkvyXQ" value="L2_LIB_MRQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyS6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyTKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyTac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyTqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L2_LIB_MRQ</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyT6c7Ee-MsNEJBkvyXQ" name="L3_COD_ART">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyUKc7Ee-MsNEJBkvyXQ" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyUac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyUqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyU6c7Ee-MsNEJBkvyXQ" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtyVKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGYf8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtyVac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L3_COD_ART'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtyVqc7Ee-MsNEJBkvyXQ" value="L3_COD_ART"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyV6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyWKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyWac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyWqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L3_COD_ART</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyW6c7Ee-MsNEJBkvyXQ" name="L4_LIB_PRD">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyXKc7Ee-MsNEJBkvyXQ" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyXac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyXqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyX6c7Ee-MsNEJBkvyXQ" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtyYKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGZuEKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtyYac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L4_LIB_PRD'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtyYqc7Ee-MsNEJBkvyXQ" value="L4_LIB_PRD"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyY6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyZKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyZac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyZqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L4_LIB_PRD</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyZ6c7Ee-MsNEJBkvyXQ" name="L5_LIB_COL">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyaKc7Ee-MsNEJBkvyXQ" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyaac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyaqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtya6c7Ee-MsNEJBkvyXQ" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtybKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGa8MKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtybac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L5_LIB_COL'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtybqc7Ee-MsNEJBkvyXQ" value="L5_LIB_COL"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyb6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtycKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtycac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtycqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L5_LIB_COL</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyc6c7Ee-MsNEJBkvyXQ" name="L6_LIB_TAI">
      <attribute defType="com.stambia.flow.field.base" id="_BQtydKc7Ee-MsNEJBkvyXQ" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtydac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtydqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyd6c7Ee-MsNEJBkvyXQ" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtyeKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGbjQKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtyeac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L6_LIB_TAI'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtyeqc7Ee-MsNEJBkvyXQ" value="L6_LIB_TAI"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtye6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyfKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyfac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyfqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L6_LIB_TAI</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyf6c7Ee-MsNEJBkvyXQ" name="L7_FAM">
      <attribute defType="com.stambia.flow.field.base" id="_BQtygKc7Ee-MsNEJBkvyXQ" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtygac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtygqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyg6c7Ee-MsNEJBkvyXQ" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtyhKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGcxYKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtyhac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L7_FAM'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtyhqc7Ee-MsNEJBkvyXQ" value="L7_FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyh6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyiKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyiac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyiqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L7_FAM</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyi6c7Ee-MsNEJBkvyXQ" name="L8_SS_FAM">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyjKc7Ee-MsNEJBkvyXQ" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyjac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyjqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyj6c7Ee-MsNEJBkvyXQ" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtykKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGd_gKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtykac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L8_SS_FAM'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtykqc7Ee-MsNEJBkvyXQ" value="L8_SS_FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyk6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtylKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtylac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtylqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L8_SS_FAM</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyl6c7Ee-MsNEJBkvyXQ" name="L9_PRX_VEN">
      <attribute defType="com.stambia.flow.field.base" id="_BQtymKc7Ee-MsNEJBkvyXQ" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtymac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtymqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtym6c7Ee-MsNEJBkvyXQ" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtynKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGfNoKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtynac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L9_PRX_VEN'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtynqc7Ee-MsNEJBkvyXQ" value="L9_PRX_VEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyn6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyoKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyoac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyoqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L9_PRX_VEN</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyo6c7Ee-MsNEJBkvyXQ" name="L10_LIB_GEN">
      <attribute defType="com.stambia.flow.field.base" id="_BQtypKc7Ee-MsNEJBkvyXQ" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtypac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtypqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyp6c7Ee-MsNEJBkvyXQ" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtyqKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGf0sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtyqac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L10_LIB_GEN'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtyqqc7Ee-MsNEJBkvyXQ" value="L10_LIB_GEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyq6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyrKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyrac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyrqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L10_LIB_GEN</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyr6c7Ee-MsNEJBkvyXQ" name="L11_CIB_TRN_AGE">
      <attribute defType="com.stambia.flow.field.base" id="_BQtysKc7Ee-MsNEJBkvyXQ" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtysac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtysqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtys6c7Ee-MsNEJBkvyXQ" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtytKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGgbwKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtytac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L11_CIB_TRN_AGE'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtytqc7Ee-MsNEJBkvyXQ" value="L11_CIB_TRN_AGE"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyt6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyuKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyuac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyuqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L11_CIB_TRN_AGE</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyu6c7Ee-MsNEJBkvyXQ" name="L12_COD_CAT">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyvKc7Ee-MsNEJBkvyXQ" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyvac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyvqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyv6c7Ee-MsNEJBkvyXQ" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtywKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGhp4KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtywac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L12_COD_CAT'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtywqc7Ee-MsNEJBkvyXQ" value="L12_COD_CAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyw6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQtyxKc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQtyxac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtyxqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L12_COD_CAT</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtyx6c7Ee-MsNEJBkvyXQ" name="L13_LIB_CAT">
      <attribute defType="com.stambia.flow.field.base" id="_BQtyyKc7Ee-MsNEJBkvyXQ" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtyyac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtyyqc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtyy6c7Ee-MsNEJBkvyXQ" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtyzKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGiQ8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtyzac7Ee-MsNEJBkvyXQ" value="'L1_ARTICLES.L13_LIB_CAT'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtyzqc7Ee-MsNEJBkvyXQ" value="L13_LIB_CAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtyz6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_BQty0Kc7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_BQty0ac7Ee-MsNEJBkvyXQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQty0qc7Ee-MsNEJBkvyXQ">
        <values>L1_ARTICLES.L13_LIB_CAT</values>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="8ed9a290-ad6b-3c19-9ad6-df8b93abac9c" name="L1_ARTICLES">
    <attribute defType="com.stambia.flow.step.number" id="_BQty1Kc7Ee-MsNEJBkvyXQ" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_BQty1ac7Ee-MsNEJBkvyXQ">
      <values>I1_ARTICLES</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_BQty1qc7Ee-MsNEJBkvyXQ" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_BQty16c7Ee-MsNEJBkvyXQ" value="Load"/>
    <node defType="com.stambia.flow.source" id="_BQty2Kc7Ee-MsNEJBkvyXQ" name="Article_20240801">
      <attribute defType="com.stambia.flow.source.target" id="_BQty2ac7Ee-MsNEJBkvyXQ" value="$MD_14"/>
    </node>
    <node defType="com.stambia.flow.field" id="_BQty2qc7Ee-MsNEJBkvyXQ" name="L1_COD_MRQ">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQty26c7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQty3Kc7Ee-MsNEJBkvyXQ" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQty3ac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQty3qc7Ee-MsNEJBkvyXQ" value="1"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQty36c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQty4Kc7Ee-MsNEJBkvyXQ">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQty4ac7Ee-MsNEJBkvyXQ" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQty4qc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGWDsKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQty46c7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_23}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQty5Kc7Ee-MsNEJBkvyXQ" value="L1_COD_MRQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQty5ac7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQty5qc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_23}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQty56c7Ee-MsNEJBkvyXQ" name="L2_LIB_MRQ">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQty6Kc7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQty6ac7Ee-MsNEJBkvyXQ" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQty6qc7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQty66c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQty7Kc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQty7ac7Ee-MsNEJBkvyXQ">
        <values>$MD_20</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQty7qc7Ee-MsNEJBkvyXQ" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQty76c7Ee-MsNEJBkvyXQ" ref="resource.md#_hGX44KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MRQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQty8Kc7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_20}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQty8ac7Ee-MsNEJBkvyXQ" value="L2_LIB_MRQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQty8qc7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQty86c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_20}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQty9Kc7Ee-MsNEJBkvyXQ" name="L3_COD_ART">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQty9ac7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQty9qc7Ee-MsNEJBkvyXQ" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQty96c7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQty-Kc7Ee-MsNEJBkvyXQ" value="3"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQty-ac7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQty-qc7Ee-MsNEJBkvyXQ">
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQty-6c7Ee-MsNEJBkvyXQ" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQty_Kc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGYf8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQty_ac7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_22}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQty_qc7Ee-MsNEJBkvyXQ" value="L3_COD_ART"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQty_6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzAKc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzAac7Ee-MsNEJBkvyXQ" name="L4_LIB_PRD">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzAqc7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzA6c7Ee-MsNEJBkvyXQ" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzBKc7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzBac7Ee-MsNEJBkvyXQ" value="4"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzBqc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzB6c7Ee-MsNEJBkvyXQ">
        <values>$MD_17</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzCKc7Ee-MsNEJBkvyXQ" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzCac7Ee-MsNEJBkvyXQ" ref="resource.md#_hGZuEKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzCqc7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_17}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzC6c7Ee-MsNEJBkvyXQ" value="L4_LIB_PRD"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzDKc7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzDac7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_17}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzDqc7Ee-MsNEJBkvyXQ" name="L5_LIB_COL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzD6c7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzEKc7Ee-MsNEJBkvyXQ" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzEac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzEqc7Ee-MsNEJBkvyXQ" value="5"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzE6c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzFKc7Ee-MsNEJBkvyXQ">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzFac7Ee-MsNEJBkvyXQ" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzFqc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGa8MKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzF6c7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_26}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzGKc7Ee-MsNEJBkvyXQ" value="L5_LIB_COL"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzGac7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzGqc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_26}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzG6c7Ee-MsNEJBkvyXQ" name="L6_LIB_TAI">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzHKc7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzHac7Ee-MsNEJBkvyXQ" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzHqc7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzH6c7Ee-MsNEJBkvyXQ" value="6"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzIKc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzIac7Ee-MsNEJBkvyXQ">
        <values>$MD_25</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzIqc7Ee-MsNEJBkvyXQ" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzI6c7Ee-MsNEJBkvyXQ" ref="resource.md#_hGbjQKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzJKc7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_25}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzJac7Ee-MsNEJBkvyXQ" value="L6_LIB_TAI"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzJqc7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzJ6c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_25}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzKKc7Ee-MsNEJBkvyXQ" name="L7_FAM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzKac7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzKqc7Ee-MsNEJBkvyXQ" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzK6c7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzLKc7Ee-MsNEJBkvyXQ" value="7"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzLac7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzLqc7Ee-MsNEJBkvyXQ">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzL6c7Ee-MsNEJBkvyXQ" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzMKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGcxYKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzMac7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_18}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzMqc7Ee-MsNEJBkvyXQ" value="L7_FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzM6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzNKc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_18}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzNac7Ee-MsNEJBkvyXQ" name="L8_SS_FAM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzNqc7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzN6c7Ee-MsNEJBkvyXQ" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzOKc7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzOac7Ee-MsNEJBkvyXQ" value="8"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzOqc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzO6c7Ee-MsNEJBkvyXQ">
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzPKc7Ee-MsNEJBkvyXQ" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzPac7Ee-MsNEJBkvyXQ" ref="resource.md#_hGd_gKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzPqc7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_16}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzP6c7Ee-MsNEJBkvyXQ" value="L8_SS_FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzQKc7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzQac7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_16}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzQqc7Ee-MsNEJBkvyXQ" name="L9_PRX_VEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzQ6c7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzRKc7Ee-MsNEJBkvyXQ" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzRac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzRqc7Ee-MsNEJBkvyXQ" value="9"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzR6c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzSKc7Ee-MsNEJBkvyXQ">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzSac7Ee-MsNEJBkvyXQ" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzSqc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGfNoKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzS6c7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_27}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzTKc7Ee-MsNEJBkvyXQ" value="L9_PRX_VEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzTac7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzTqc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_27}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzT6c7Ee-MsNEJBkvyXQ" name="L10_LIB_GEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzUKc7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzUac7Ee-MsNEJBkvyXQ" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzUqc7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzU6c7Ee-MsNEJBkvyXQ" value="10"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzVKc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzVac7Ee-MsNEJBkvyXQ">
        <values>$MD_15</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzVqc7Ee-MsNEJBkvyXQ" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzV6c7Ee-MsNEJBkvyXQ" ref="resource.md#_hGf0sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzWKc7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_15}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzWac7Ee-MsNEJBkvyXQ" value="L10_LIB_GEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzWqc7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzW6c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_15}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzXKc7Ee-MsNEJBkvyXQ" name="L11_CIB_TRN_AGE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzXac7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzXqc7Ee-MsNEJBkvyXQ" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzX6c7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzYKc7Ee-MsNEJBkvyXQ" value="11"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzYac7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzYqc7Ee-MsNEJBkvyXQ">
        <values>$MD_19</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzY6c7Ee-MsNEJBkvyXQ" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzZKc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGgbwKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzZac7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_19}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzZqc7Ee-MsNEJBkvyXQ" value="L11_CIB_TRN_AGE"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzZ6c7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzaKc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_19}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzaac7Ee-MsNEJBkvyXQ" name="L12_COD_CAT">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzaqc7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtza6c7Ee-MsNEJBkvyXQ" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzbKc7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzbac7Ee-MsNEJBkvyXQ" value="12"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtzbqc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzb6c7Ee-MsNEJBkvyXQ">
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzcKc7Ee-MsNEJBkvyXQ" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzcac7Ee-MsNEJBkvyXQ" ref="resource.md#_hGhp4KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzcqc7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_24}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzc6c7Ee-MsNEJBkvyXQ" value="L12_COD_CAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzdKc7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzdac7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_24}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_BQtzdqc7Ee-MsNEJBkvyXQ" name="L13_LIB_CAT">
      <attribute defType="com.stambia.flow.field.aggregate" id="_BQtzd6c7Ee-MsNEJBkvyXQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_BQtzeKc7Ee-MsNEJBkvyXQ" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_BQtzeac7Ee-MsNEJBkvyXQ" value="SRC"/>
      <attribute defType="com.stambia.flow.field.number" id="_BQtzeqc7Ee-MsNEJBkvyXQ" value="13"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_BQtze6c7Ee-MsNEJBkvyXQ">
        <values>Article_20240801</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_BQtzfKc7Ee-MsNEJBkvyXQ">
        <values>$MD_21</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_BQtzfac7Ee-MsNEJBkvyXQ" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_BQtzfqc7Ee-MsNEJBkvyXQ" ref="resource.md#_hGiQ8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_BQtzf6c7Ee-MsNEJBkvyXQ" value="'Article_20240801.%{MD_21}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_BQtzgKc7Ee-MsNEJBkvyXQ" value="L13_LIB_CAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_BQtzgac7Ee-MsNEJBkvyXQ" value="2"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_BQtzgqc7Ee-MsNEJBkvyXQ">
        <values>Article_20240801.%{MD_21}%</values>
      </attribute>
    </node>
  </node>
  <metaDataLink name="MD_25" target="resource.md#_lLUGRJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_TAI?"/>
  <metaDataLink name="MD_26" target="resource.md#_lLUGQJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_COL?"/>
  <metaDataLink name="MD_0" target="resource.md#_gry1sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ARTICLES?"/>
  <metaDataLink name="MD_15" target="resource.md#_lLUGVZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_GEN?"/>
  <metaDataLink name="MD_4" target="resource.md#_hGZuEKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
  <metaDataLink name="MD_5" target="resource.md#_hGa8MKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
  <metaDataLink name="MD_9" target="resource.md#_hGfNoKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
  <metaDataLink name="MD_13" target="resource.md#_hGiQ8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
  <metaDataLink name="MD_7" target="resource.md#_hGcxYKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
  <metaDataLink name="MD_23" target="resource.md#_lLUGMJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_6" target="resource.md#_hGbjQKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
  <metaDataLink name="MD_16" target="resource.md#_lLUGTJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=SS_FAM?"/>
  <metaDataLink name="MD_8" target="resource.md#_hGd_gKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
  <metaDataLink name="MD_24" target="resource.md#_lLUGXZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_CAT?"/>
  <metaDataLink name="MD_18" target="resource.md#_lLUGSJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=FAM?"/>
  <metaDataLink name="MD_1" target="resource.md#_hGWDsKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_21" target="resource.md#_lLUGYZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_CAT?"/>
  <metaDataLink name="MD_11" target="resource.md#_hGgbwKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
  <metaDataLink name="MD_2" target="resource.md#_hGX44KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MRQ?"/>
  <metaDataLink name="MD_10" target="resource.md#_hGf0sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
  <metaDataLink name="MD_20" target="resource.md#_lLUGNJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_MRQ?"/>
  <metaDataLink name="MD_12" target="resource.md#_hGhp4KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAT?"/>
  <metaDataLink name="MD_27" target="resource.md#_lLUGUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=PRX_VEN?"/>
  <metaDataLink name="MD_14" target="resource.md#_Z6ggUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=Article_20240801?"/>
  <metaDataLink name="MD_17" target="resource.md#_lLUGPJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_PRD?"/>
  <metaDataLink name="MD_22" target="resource.md#_lLUGOJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_19" target="resource.md#_lLUGWZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=CIB_TRN_AGE?"/>
  <metaDataLink name="MD_3" target="resource.md#_hGYf8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
</md:node>