<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_yxluIKHHEe-Mishx4UyKwQ-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_gcJI0bAVEe-mg8uIL6AcVA">
    <attribute defType="com.stambia.flow.altId.origin" id="_gcJI0rAVEe-mg8uIL6AcVA" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_gcJI07AVEe-mg8uIL6AcVA" value="_yxluIKHHEe-Mishx4UyKwQ"/>
  </node>
  <node defType="com.stambia.flow.step" id="9e7d75de-48dc-302e-8043-5f9aeb93e709" name="I1_SAS_TICKETDECAISSE">
    <attribute defType="com.stambia.flow.step.number" id="_gdJ1cbAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_gdJ1crAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_gdJ1c7AVEe-mg8uIL6AcVA" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_gdJ1dLAVEe-mg8uIL6AcVA" name="SAS_MAGASIN">
      <attribute defType="com.stambia.flow.source.target" id="_gdKcgLAVEe-mg8uIL6AcVA" value="$MD_5"/>
    </node>
    <node defType="com.stambia.flow.source" id="_gdKcgbAVEe-mg8uIL6AcVA" name="TICKETS">
      <attribute defType="com.stambia.flow.source.target" id="_gdKcgrAVEe-mg8uIL6AcVA" value="$MD_6"/>
    </node>
    <node defType="com.stambia.flow.field" id="_gdKcg7AVEe-mg8uIL6AcVA" name="CODMAGNUMCAINUMTIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_gdKchLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_gdKchbAVEe-mg8uIL6AcVA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_gdKchrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_gdKch7AVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN</values>
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_gdKciLAVEe-mg8uIL6AcVA">
        <values>$MD_8</values>
        <values>$MD_7</values>
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_gdKcibAVEe-mg8uIL6AcVA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_gdKcirAVEe-mg8uIL6AcVA" ref="resource.md#_3CdUsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_gdKci7AVEe-mg8uIL6AcVA" value="'SAS_MAGASIN.%{MD_8}% || ''_'' ||TICKETS.%{MD_7}% || ''_'' ||TICKETS.%{MD_9}% '"/>
      <attribute defType="com.stambia.flow.field.workname" id="_gdKcjLAVEe-mg8uIL6AcVA" value="CODMAGNUMCAINUMTIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_gdKcjbAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_gdKcjrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_gdKcj7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_gdKckLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_gdKckbAVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN.%{MD_8}%</values>
        <values>TICKETS.%{MD_7}%</values>
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_gdKckrAVEe-mg8uIL6AcVA" name="COD_DEV">
      <attribute defType="com.stambia.flow.field.aggregate" id="_gdKck7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_gdKclLAVEe-mg8uIL6AcVA" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_gdKclbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_gdKclrAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_gdKcl7AVEe-mg8uIL6AcVA">
        <values>$MD_10</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_gdKcmLAVEe-mg8uIL6AcVA" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_gdKcmbAVEe-mg8uIL6AcVA" ref="resource.md#_3CfJ4K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_gdKcmrAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_10}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_gdKcm7AVEe-mg8uIL6AcVA" value="COD_DEV"/>
      <attribute defType="com.stambia.flow.field.version" id="_gdKcnLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_gdKcnbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_gdKcnrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_gdKcn7AVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_10}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_gdKcoLAVEe-mg8uIL6AcVA" name="COD_VEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_gdKcobAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_gdKcorAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_gdKco7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_gdKcpLAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_gdKcpbAVEe-mg8uIL6AcVA">
        <values>$MD_13</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_gdKcprAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_gdKcp7AVEe-mg8uIL6AcVA" ref="resource.md#_3Cfw8K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_gdKcqLAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_13}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_gdKcqbAVEe-mg8uIL6AcVA" value="COD_VEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_gdKcqrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_gdKcq7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_gdKcrLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_gdKcrbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_gdKcrrAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_13}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_gdKcr7AVEe-mg8uIL6AcVA" name="DATE_HEURE_TIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_gdKcsLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_gdKcsbAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_gdKcsrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_gdKcs7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_gdKctLAVEe-mg8uIL6AcVA">
        <values>$MD_14</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_gdKctbAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_gdKctrAVEe-mg8uIL6AcVA" ref="resource.md#_3CgYAK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_HEURE_TIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_gdKct7AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_14}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_gdKcuLAVEe-mg8uIL6AcVA" value="DATE_HEURE_TIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_gdKcubAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_gdKcurAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_gdKcu7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_gdKcvLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_14}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.join" id="_FWvyUKchEe-ti-Zc6dspJw">
      <attribute defType="com.stambia.flow.join.expr" id="_gdKcvrAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_12}% = SAS_MAGASIN.%{MD_11}%'"/>
      <attribute defType="com.stambia.flow.join.left" id="_gdKcv7AVEe-mg8uIL6AcVA" value="TICKETS"/>
      <attribute defType="com.stambia.flow.join.right" id="_gdKcwLAVEe-mg8uIL6AcVA" value="SAS_MAGASIN"/>
      <attribute defType="com.stambia.flow.join.order" id="_gdKcwbAVEe-mg8uIL6AcVA" value="10"/>
      <attribute defType="com.stambia.flow.join.type" id="_gdKcwrAVEe-mg8uIL6AcVA" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.version" id="_gdKcw7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_gdKcxLAVEe-mg8uIL6AcVA">
        <values>SAS_MAGASIN</values>
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.source" id="_gdKcxbAVEe-mg8uIL6AcVA">
        <values>$MD_11</values>
        <values>$MD_12</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_gdKcxrAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_12}%</values>
        <values>SAS_MAGASIN.%{MD_11}%</values>
      </attribute>
    </node>
  </node>
  <metaDataLink name="MD_12" target="resource.md#_Cj6fUKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_9" target="resource.md#_Cj7tdqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
  <metaDataLink name="MD_4" target="resource.md#_3CgYAK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_HEURE_TIC?"/>
  <metaDataLink name="MD_3" target="resource.md#_3Cfw8K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
  <metaDataLink name="MD_5" target="resource.md#_RLOBwKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MAGASIN?"/>
  <metaDataLink name="MD_13" target="resource.md#_Cj87kKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
  <metaDataLink name="MD_1" target="resource.md#_3CdUsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
  <metaDataLink name="MD_8" target="resource.md#_RUvxMKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
  <metaDataLink name="MD_6" target="resource.md#_B-yZAKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TICKETS?"/>
  <metaDataLink name="MD_11" target="resource.md#_RUwYQKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_14" target="resource.md#_Cj7tcKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_HEU_TIC?"/>
  <metaDataLink name="MD_2" target="resource.md#_3CfJ4K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
  <metaDataLink name="MD_0" target="resource.md#_20HWsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_TICKETDECAISSE?"/>
  <metaDataLink name="MD_7" target="resource.md#_Cj8UiacWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAI?"/>
  <metaDataLink name="MD_10" target="resource.md#_Cj9iracWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
</md:node>