<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.semarchy.xdi.harvest.model" id="_GnjFkKHAEe-Mishx4UyKwQ-xdg" md:ref="resource.tech#UUID_TECH_XDI_HARVESTED?fileId=UUID_TECH_XDI_HARVESTED?" internalVersion="v2.0.0">
  <node defType="com.semarchy.xdi.harvest.mapping" id="_oFfKNqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelId" id="_oFfKN6HCEe-Mishx4UyKwQ" value="_GnjFkKHAEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelName" id="_oFfKOKHCEe-Mishx4UyKwQ" value="ALIM_SAS_MARQUE"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_oFfKSaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_oFfKSqHCEe-Mishx4UyKwQ" value="_1I9ZsKG9Ee-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_oFfKS6HCEe-Mishx4UyKwQ" value="BDD"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_oFfKkqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_oFfKk6HCEe-Mishx4UyKwQ" value="_oP4f4JbEEe-yJMimzYo_ug"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_oFfKlKHCEe-Mishx4UyKwQ" value="ARTICLE"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceset" id="_oFfKm6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelName" id="_oFfKnKHCEe-Mishx4UyKwQ" value="Source SAS_MARQUE"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelId" id="_oFfKnaHCEe-Mishx4UyKwQ" value="ss-_k2es4KHBEe-Mishx4UyKwQ"/>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_oFfKpKHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_oFfKpaHCEe-Mishx4UyKwQ" value="Source Article_20240801.COD_MRQ"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_oFfKpqHCEe-Mishx4UyKwQ" value="ssf-_Myb6gaHAEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_oFfKqqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_oFfKq6HCEe-Mishx4UyKwQ" value="Source Article_20240801.LIB_MRQ"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_oFfKrKHCEe-Mishx4UyKwQ" value="ssf-_Myb6gqHAEe-Mishx4UyKwQ"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_oFfKOaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_oFfKOqHCEe-Mishx4UyKwQ" value="_k2es4KHBEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_oFfKO6HCEe-Mishx4UyKwQ" value="SAS_MARQUE"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKPKHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKPaHCEe-Mishx4UyKwQ" ref="resource.md#_iZtIcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKPqHCEe-Mishx4UyKwQ" value="_k2hwMaHBEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKP6HCEe-Mishx4UyKwQ" value="SAS_MARQUE.COD_MRQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKQKHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKQaHCEe-Mishx4UyKwQ" ref="resource.md#_iZtIdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MARQ?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKQqHCEe-Mishx4UyKwQ" value="_k2hwMqHBEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKQ6HCEe-Mishx4UyKwQ" value="SAS_MARQUE.LIB_MARQ"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_oFfKUqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_oFfKU6HCEe-Mishx4UyKwQ" value="_MybTcKHAEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_oFfKVKHCEe-Mishx4UyKwQ" value="Article_20240801"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKVaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKVqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=PRX_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKV6HCEe-Mishx4UyKwQ" value="_Myb6iaHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKWKHCEe-Mishx4UyKwQ" value="Article_20240801.PRX_VEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKWaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKWqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGRJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_TAI?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKW6HCEe-Mishx4UyKwQ" value="_Myb6hqHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKXKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_TAI"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKXaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKXqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGXZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_CAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKX6HCEe-Mishx4UyKwQ" value="_Myb6jKHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKYKHCEe-Mishx4UyKwQ" value="Article_20240801.COD_CAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKYaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKYqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGOJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_ART?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKY6HCEe-Mishx4UyKwQ" value="_Myb6g6HAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKZKHCEe-Mishx4UyKwQ" value="Article_20240801.COD_ART"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKZaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKZqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGSJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=FAM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKZ6HCEe-Mishx4UyKwQ" value="_Myb6h6HAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKaKHCEe-Mishx4UyKwQ" value="Article_20240801.FAM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKaaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKaqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGTJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=SS_FAM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKa6HCEe-Mishx4UyKwQ" value="_Myb6iKHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKbKHCEe-Mishx4UyKwQ" value="Article_20240801.SS_FAM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKbaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKbqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGWZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKb6HCEe-Mishx4UyKwQ" value="_Myb6i6HAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKcKHCEe-Mishx4UyKwQ" value="Article_20240801.CIB_TRN_AGE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKcaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKcqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGVZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_GEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKc6HCEe-Mishx4UyKwQ" value="_Myb6iqHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKdKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_GEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKdaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKdqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGMJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_MRQ?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKd6HCEe-Mishx4UyKwQ" value="_Myb6gaHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKeKHCEe-Mishx4UyKwQ" value="Article_20240801.COD_MRQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKeaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKeqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGPJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_PRD?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKe6HCEe-Mishx4UyKwQ" value="_Myb6hKHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKfKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_PRD"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKfaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKfqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGNJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_MRQ?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKf6HCEe-Mishx4UyKwQ" value="_Myb6gqHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKgKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_MRQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKgaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKgqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGYZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_CAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKg6HCEe-Mishx4UyKwQ" value="_Myb6jaHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKhKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_CAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKhaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKhqHCEe-Mishx4UyKwQ" ref="resource.md#_Z6ggUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=Article_20240801?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKh6HCEe-Mishx4UyKwQ" value="_Myb6gKHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKiKHCEe-Mishx4UyKwQ" value="Article_20240801.Article_20240801"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_oFfKiaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_oFfKiqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGQJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_COL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_oFfKi6HCEe-Mishx4UyKwQ" value="_Myb6haHAEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_oFfKjKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_COL"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_oFfKRKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_oFfKRaHCEe-Mishx4UyKwQ" ref="resource.md#_iWZVwKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MARQUE?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_oFfKjaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_oFfKjqHCEe-Mishx4UyKwQ" ref="resource.md#_Z6ggUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=Article_20240801?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore" id="_oFfKnqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.sourceRef" id="_oFfKn6HCEe-Mishx4UyKwQ" ref="resource.md#_oFfKm6HCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.targetRef" id="_oFfKoKHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKOaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_oFfKp6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_oFfKqKHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKpKHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_oFfKqaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKdaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_oFfKraHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_oFfKrqHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKqqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_oFfKr6HCEe-Mishx4UyKwQ" ref="resource.md#_oFfKfaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_oFfKsKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_oFfKsaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKpKHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_oFfKsqHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKPKHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_oFfKs6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_oFfKtKHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKqqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_oFfKtaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKQKHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_oFfKRqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_oFfKR6HCEe-Mishx4UyKwQ" ref="resource.md#_oFfKOaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_oFfKSKHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKRKHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_oFfKj6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_oFfKkKHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKUqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_oFfKkaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKjaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_oFfKTKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_oFfKTaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKSaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_oFfKTqHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKRKHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_oFfKT6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_oFfKUKHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKNqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_oFfKUaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKOaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_oFfKlaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_oFfKlqHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKkqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_oFfKl6HCEe-Mishx4UyKwQ" ref="resource.md#_oFfKjaHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_oFfKmKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_oFfKmaHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKNqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_oFfKmqHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKUqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_oFfKoaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_oFfKoqHCEe-Mishx4UyKwQ" ref="resource.md#_oFfKNqHCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_oFfKo6HCEe-Mishx4UyKwQ" ref="resource.md#_oFfKm6HCEe-Mishx4UyKwQ?fileId=_GnjFkKHAEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
</md:node>