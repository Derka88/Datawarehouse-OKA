<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_fd_z4KW0Ee-Qv6cAKrauhg-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_X10K0bJHEe-7gLO1_RM3Dg">
    <attribute defType="com.stambia.flow.altId.origin" id="_X10K0rJHEe-7gLO1_RM3Dg" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_X10K07JHEe-7gLO1_RM3Dg" value="_fd_z4KW0Ee-Qv6cAKrauhg"/>
  </node>
  <node defType="com.stambia.flow.step" id="780c8351-be0b-3a1b-9357-ab8ad08e69c4" name="I1_MARQUE">
    <attribute defType="com.stambia.flow.step.number" id="_X12AAbJHEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_X12AArJHEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_X12AA7JHEe-7gLO1_RM3Dg" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_X12ABLJHEe-7gLO1_RM3Dg" name="SAS_MARQUE">
      <attribute defType="com.stambia.flow.source.target" id="_X12ABbJHEe-7gLO1_RM3Dg" value="$MD_5"/>
    </node>
    <node defType="com.stambia.flow.field" id="_X12ABrJHEe-7gLO1_RM3Dg" name="COD_MRQ">
      <attribute defType="com.stambia.flow.field.aggregate" id="_X12AB7JHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_X12ACLJHEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_X12ACbJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_X12ACrJHEe-7gLO1_RM3Dg">
        <values>SAS_MARQUE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_X12AC7JHEe-7gLO1_RM3Dg">
        <values>$MD_7</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_X12ADLJHEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_X12ADbJHEe-7gLO1_RM3Dg" ref="resource.md#_Am4joKHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_X12ADrJHEe-7gLO1_RM3Dg" value="'SAS_MARQUE.%{MD_7}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_X12AD7JHEe-7gLO1_RM3Dg" value="COD_MRQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_X12AELJHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_X12AEbJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_X12AErJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_X12AE7JHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_X12AFLJHEe-7gLO1_RM3Dg">
        <values>SAS_MARQUE.%{MD_7}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_X12AFbJHEe-7gLO1_RM3Dg" name="LIB_MARQ">
      <attribute defType="com.stambia.flow.field.aggregate" id="_X12AFrJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_X12AF7JHEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_X12AGLJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_X12AGbJHEe-7gLO1_RM3Dg">
        <values>SAS_MARQUE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_X12AGrJHEe-7gLO1_RM3Dg">
        <values>$MD_6</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_X12AG7JHEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_X12AHLJHEe-7gLO1_RM3Dg" ref="resource.md#_Am4jpqHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MARQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_X12AHbJHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MARQUE.%{MD_6}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_X12AHrJHEe-7gLO1_RM3Dg" value="LIB_MARQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_X12AH7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_X12AILJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_X12AIbJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_X12AIrJHEe-7gLO1_RM3Dg">
        <values>SAS_MARQUE.%{MD_6}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_X12AI7JHEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_X12AJLJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_X12AJbJHEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_X12AJrJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.target" id="_X12AJ7JHEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_X12AKLJHEe-7gLO1_RM3Dg" ref="resource.md#_OshIMLJAEe-BObk_rBUyXw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_X12AKbJHEe-7gLO1_RM3Dg" value="'TO_CHAR(SYSDATE, ''YYYYMMDDHH24MISS'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_X12AKrJHEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
      <attribute defType="com.stambia.flow.field.version" id="_X12AK7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_X12ALLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_X12ALbJHEe-7gLO1_RM3Dg" value="true"/>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="f75e48a6-03c8-34f5-aa54-f0ecc12f0c0c" name="R1_MARQUE">
    <attribute defType="com.stambia.flow.step.number" id="_X12AL7JHEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_X12AMLJHEe-7gLO1_RM3Dg">
      <values>I1_MARQUE</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_X12AMbJHEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_X12AMrJHEe-7gLO1_RM3Dg" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_X12AM7JHEe-7gLO1_RM3Dg" name="PK_MARQUE">
      <attribute defType="com.stambia.flow.constraint.type" id="_X12ANLJHEe-7gLO1_RM3Dg" value="pk"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_X12ANbJHEe-7gLO1_RM3Dg" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_X12ANrJHEe-7gLO1_RM3Dg" name="NN_COD_MRQ">
      <attribute defType="com.stambia.flow.constraint.type" id="_X12AN7JHEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_X12AOLJHEe-7gLO1_RM3Dg" value="$MD_2"/>
    </node>
  </node>
  <metaDataLink name="MD_5" target="resource.md#_iWZVwKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MARQUE?"/>
  <metaDataLink name="MD_1" target="resource.md#_Os-bMLJAEe-BObk_rBUyXw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PK_MARQUE?"/>
  <metaDataLink name="MD_4" target="resource.md#_OshIMLJAEe-BObk_rBUyXw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
  <metaDataLink name="MD_6" target="resource.md#_iZtIdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MARQ?"/>
  <metaDataLink name="MD_0" target="resource.md#_Ahvk8KHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MARQUE?"/>
  <metaDataLink name="MD_3" target="resource.md#_Am4jpqHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MARQ?"/>
  <metaDataLink name="MD_2" target="resource.md#_Am4joKHAEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_7" target="resource.md#_iZtIcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
</md:node>