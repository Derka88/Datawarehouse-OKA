<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_GnjFkKHAEe-Mishx4UyKwQ-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_XeKhMbAVEe-mg8uIL6AcVA">
    <attribute defType="com.stambia.flow.altId.origin" id="_XeKhMrAVEe-mg8uIL6AcVA" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_XeKhM7AVEe-mg8uIL6AcVA" value="_GnjFkKHAEe-Mishx4UyKwQ"/>
  </node>
  <node defType="com.stambia.flow.step" id="2f55c12a-687e-349b-afb3-2edb8da892e0" name="I1_SAS_MARQUE">
    <attribute defType="com.stambia.flow.step.number" id="_XeLvULAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_XeLvUbAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_XeLvUrAVEe-mg8uIL6AcVA" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_XeLvU7AVEe-mg8uIL6AcVA" name="ARTICLES">
      <attribute defType="com.stambia.flow.source.target" id="_XeLvVLAVEe-mg8uIL6AcVA" value="$MD_5"/>
    </node>
    <node defType="com.stambia.flow.field" id="_XeLvVbAVEe-mg8uIL6AcVA" name="COD_MRQ">
      <attribute defType="com.stambia.flow.field.aggregate" id="_XeLvVrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_XeLvV7AVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_XeLvWLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_XeLvWbAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_XeLvWrAVEe-mg8uIL6AcVA">
        <values>$MD_6</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_XeLvW7AVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_XeLvXLAVEe-mg8uIL6AcVA" ref="resource.md#_iZtIcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_XeLvXbAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_6}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_XeLvXrAVEe-mg8uIL6AcVA" value="COD_MRQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_XeLvX7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_XeLvYLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_XeLvYbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_XeLvYrAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_6}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_XeLvY7AVEe-mg8uIL6AcVA" name="LIB_MARQ">
      <attribute defType="com.stambia.flow.field.aggregate" id="_XeLvZLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_XeLvZbAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_XeLvZrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_XeLvZ7AVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_XeLvaLAVEe-mg8uIL6AcVA">
        <values>$MD_7</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_XeLvabAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_XeLvarAVEe-mg8uIL6AcVA" ref="resource.md#_iZtIdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MARQ?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_XeLva7AVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_7}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_XeLvbLAVEe-mg8uIL6AcVA" value="LIB_MARQ"/>
      <attribute defType="com.stambia.flow.field.version" id="_XeLvbbAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_XeLvbrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_XeLvb7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_XeLvcLAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_7}%</values>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="c0338aa6-ab3c-3570-bc37-52444b631350" name="R1_SAS_MARQUE">
    <attribute defType="com.stambia.flow.step.number" id="_XeLvcrAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_XeLvc7AVEe-mg8uIL6AcVA">
      <values>I1_SAS_MARQUE</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_XeLvdLAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_XeLvdbAVEe-mg8uIL6AcVA" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_XeLvdrAVEe-mg8uIL6AcVA" name="COD_MRQ_CONDITION">
      <attribute defType="com.stambia.flow.constraint.type" id="_XeLvd7AVEe-mg8uIL6AcVA" value="ck"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_XeLveLAVEe-mg8uIL6AcVA" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_XeLvebAVEe-mg8uIL6AcVA" name="LIB_NULL">
      <attribute defType="com.stambia.flow.constraint.type" id="_XeLverAVEe-mg8uIL6AcVA" value="ck"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_XeLve7AVEe-mg8uIL6AcVA" value="$MD_2"/>
    </node>
  </node>
  <metaDataLink name="MD_5" target="resource.md#_gry1sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ARTICLES?"/>
  <metaDataLink name="MD_0" target="resource.md#_iWZVwKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MARQUE?"/>
  <metaDataLink name="MD_7" target="resource.md#_hGX44KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MRQ?"/>
  <metaDataLink name="MD_1" target="resource.md#_6sc-saWzEe-Qv6cAKrauhg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_CONDITION?"/>
  <metaDataLink name="MD_3" target="resource.md#_iZtIcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_2" target="resource.md#_hud6AacaEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_NULL?"/>
  <metaDataLink name="MD_6" target="resource.md#_hGWDsKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ?"/>
  <metaDataLink name="MD_4" target="resource.md#_iZtIdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MARQ?"/>
</md:node>