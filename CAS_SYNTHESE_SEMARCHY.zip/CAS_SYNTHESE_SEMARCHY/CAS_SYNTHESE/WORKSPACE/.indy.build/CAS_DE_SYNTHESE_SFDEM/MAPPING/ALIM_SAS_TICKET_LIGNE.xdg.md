<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.semarchy.xdi.harvest.model" id="_AwMLcKHSEe-Mishx4UyKwQ-xdg" md:ref="resource.tech#UUID_TECH_XDI_HARVESTED?fileId=UUID_TECH_XDI_HARVESTED?" internalVersion="v2.0.0">
  <node defType="com.semarchy.xdi.harvest.mapping" id="__Sud66HTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelId" id="__Sud7KHTEe-Yu95zZEQSuw" value="_AwMLcKHSEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelName" id="__Sud7aHTEe-Yu95zZEQSuw" value="ALIM_SAS_TICKET_LIGNE"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="__SvE5aHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="__SvE5qHTEe-Yu95zZEQSuw" value="_1I9ZsKG9Ee-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="__SvE56HTEe-Yu95zZEQSuw" value="BDD"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="__SvEoKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="__SvEoaHTEe-Yu95zZEQSuw" value="_OMrx0JbGEe-yJMimzYo_ug"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="__SvEoqHTEe-Yu95zZEQSuw" value="TICKET"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceset" id="__SvE7qHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelName" id="__SvE76HTEe-Yu95zZEQSuw" value="Source SAS_LIGNETICKET"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelId" id="__SvE8KHTEe-Yu95zZEQSuw" value="ss-_Dyh7EKHSEe-Mishx4UyKwQ"/>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvE96HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvE-KHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.COD_ENS"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvE-aHTEe-Yu95zZEQSuw" value="ssf-_DQdIwKHSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvE_aHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvE_qHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.NUM_TIC"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvE_6HTEe-Yu95zZEQSuw" value="ssf-_DQdIxaHSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFA6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFBKHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.MNT_TTC"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFBaHTEe-Yu95zZEQSuw" value="ssf-_DQdIy6HSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFCaHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFCqHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.MNT_BRU"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFC6HTEe-Yu95zZEQSuw" value="ssf-_DQdIyqHSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFD6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFEKHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.QTE"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFEaHTEe-Yu95zZEQSuw" value="ssf-_DQdIyaHSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFFaHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFFqHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.COD_ART"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFF6HTEe-Yu95zZEQSuw" value="ssf-_DQdIw6HSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFG6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFHKHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.DAT_HEU_TIC"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFHaHTEe-Yu95zZEQSuw" value="ssf-_DQdIxKHSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFIaHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFIqHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.NUM_TIC_LIG"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFI6HTEe-Yu95zZEQSuw" value="ssf-_DQdIxqHSEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="__SvFJ6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="__SvFKKHTEe-Yu95zZEQSuw" value="Source Ticket_20240801.COD_CAI"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="__SvFKaHTEe-Yu95zZEQSuw" value="ssf-_DQdIx6HSEe-Mishx4UyKwQ"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="__SvEEKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="__SvEEaHTEe-Yu95zZEQSuw" value="_DQbTkKHSEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="__SvEEqHTEe-Yu95zZEQSuw" value="Ticket_20240801"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEE6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEFKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGAJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_HEU_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEFaHTEe-Yu95zZEQSuw" value="_DQdIxKHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEFqHTEe-Yu95zZEQSuw" value="Ticket_20240801.DAT_HEU_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEF6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEGKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGCJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=NUM_TIC_LIG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEGaHTEe-Yu95zZEQSuw" value="_DQdIxqHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEGqHTEe-Yu95zZEQSuw" value="Ticket_20240801.NUM_TIC_LIG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEG6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEHKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGXZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TEL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEHaHTEe-Yu95zZEQSuw" value="_DQdI2qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEHqHTEe-Yu95zZEQSuw" value="Ticket_20240801.TEL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEH6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEIKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGGJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=MNT_BRU?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEIaHTEe-Yu95zZEQSuw" value="_DQdIyqHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEIqHTEe-Yu95zZEQSuw" value="Ticket_20240801.MNT_BRU"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEI6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEJKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZF_JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_ART?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEJaHTEe-Yu95zZEQSuw" value="_DQdIw6HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEJqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_ART"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEJ6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEKKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGIpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEKaHTEe-Yu95zZEQSuw" value="_DQdIzKHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEKqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEK6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvELKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGNJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TX_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvELaHTEe-Yu95zZEQSuw" value="_DQdI0KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvELqHTEe-Yu95zZEQSuw" value="Ticket_20240801.TX_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEL6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEMKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGPZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEMaHTEe-Yu95zZEQSuw" value="_DQdI0qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEMqHTEe-Yu95zZEQSuw" value="Ticket_20240801.LIB_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEM6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvENKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGQZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR1?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvENaHTEe-Yu95zZEQSuw" value="_DQdI06HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvENqHTEe-Yu95zZEQSuw" value="Ticket_20240801.ADR1"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEN6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEOKHTEe-Yu95zZEQSuw" ref="resource.md#_OOP4EJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=Ticket_20240801?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEOaHTEe-Yu95zZEQSuw" value="_DQchsaHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEOqHTEe-Yu95zZEQSuw" value="Ticket_20240801.Ticket_20240801"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEO6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEPKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZF8JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEPaHTEe-Yu95zZEQSuw" value="_DQdIwKHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEPqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEP6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEQKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGapbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEQaHTEe-Yu95zZEQSuw" value="_DQdI3aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEQqHTEe-Yu95zZEQSuw" value="Ticket_20240801.LAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEQ6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvERKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGUZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_POS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvERaHTEe-Yu95zZEQSuw" value="_DQdI16HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvERqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_POS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvER6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvESKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGBJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=NUM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvESaHTEe-Yu95zZEQSuw" value="_DQdIxaHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvESqHTEe-Yu95zZEQSuw" value="Ticket_20240801.NUM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvES6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvETKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGZZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LNG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvETaHTEe-Yu95zZEQSuw" value="_DQdI3KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvETqHTEe-Yu95zZEQSuw" value="Ticket_20240801.LNG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvET6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEUKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGSZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR3?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEUaHTEe-Yu95zZEQSuw" value="_DQdI1aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEUqHTEe-Yu95zZEQSuw" value="Ticket_20240801.ADR3"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEU6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEVKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGVZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DEP_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEVaHTEe-Yu95zZEQSuw" value="_DQdI2KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEVqHTEe-Yu95zZEQSuw" value="Ticket_20240801.DEP_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEV6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEWKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGb5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_OUV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEWaHTEe-Yu95zZEQSuw" value="_DQdI3qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEWqHTEe-Yu95zZEQSuw" value="Ticket_20240801.DAT_OUV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEW6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEXKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGFJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=QTE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEXaHTEe-Yu95zZEQSuw" value="_DQdIyaHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEXqHTEe-Yu95zZEQSuw" value="Ticket_20240801.QTE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEX6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEYKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGKpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REM_LIN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEYaHTEe-Yu95zZEQSuw" value="_DQdIzqHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEYqHTEe-Yu95zZEQSuw" value="Ticket_20240801.REM_LIN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEY6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEZKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGOZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEZaHTEe-Yu95zZEQSuw" value="_DQdI0aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEZqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEZ6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEaKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZF9JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEaaHTEe-Yu95zZEQSuw" value="_DQdIwaHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEaqHTEe-Yu95zZEQSuw" value="Ticket_20240801.LIB_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEa6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEbKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGJpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TX_TVA?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEbaHTEe-Yu95zZEQSuw" value="_DQdIzaHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEbqHTEe-Yu95zZEQSuw" value="Ticket_20240801.TX_TVA"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEb6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEcKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGWZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REG_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEcaHTEe-Yu95zZEQSuw" value="_DQdI2aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEcqHTEe-Yu95zZEQSuw" value="Ticket_20240801.REG_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEc6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEdKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGc5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_FRM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEdaHTEe-Yu95zZEQSuw" value="_DQdI36HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEdqHTEe-Yu95zZEQSuw" value="Ticket_20240801.DAT_FRM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEd6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEeKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGd5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=SCHEDULE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEeaHTEe-Yu95zZEQSuw" value="_DQdI4KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEeqHTEe-Yu95zZEQSuw" value="Ticket_20240801.SCHEDULE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEe6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEfKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZF-JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEfaHTEe-Yu95zZEQSuw" value="_DQdIwqHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEfqHTEe-Yu95zZEQSuw" value="Ticket_20240801.LIB_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEf6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEgKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGHZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=MNT_TTC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEgaHTEe-Yu95zZEQSuw" value="_DQdIy6HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEgqHTEe-Yu95zZEQSuw" value="Ticket_20240801.MNT_TTC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEg6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEhKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGRZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR2?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEhaHTEe-Yu95zZEQSuw" value="_DQdI1KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEhqHTEe-Yu95zZEQSuw" value="Ticket_20240801.ADR2"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEh6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEiKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGTZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=VIL_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEiaHTEe-Yu95zZEQSuw" value="_DQdI1qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEiqHTEe-Yu95zZEQSuw" value="Ticket_20240801.VIL_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEi6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEjKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGDJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_CAI?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEjaHTEe-Yu95zZEQSuw" value="_DQdIx6HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEjqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_CAI"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEj6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEkKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGEJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEkaHTEe-Yu95zZEQSuw" value="_DQdIyKHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEkqHTEe-Yu95zZEQSuw" value="Ticket_20240801.COD_VEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEk6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvElKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGL5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvElaHTEe-Yu95zZEQSuw" value="_DQdIz6HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvElqHTEe-Yu95zZEQSuw" value="Ticket_20240801.REM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEl6HTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEmKHTEe-Yu95zZEQSuw" ref="resource.md#_ZbZGYZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=EMAIL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEmaHTEe-Yu95zZEQSuw" value="_DQdI26HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEmqHTEe-Yu95zZEQSuw" value="Ticket_20240801.EMAIL"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="__SvEqaHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="__SvEqqHTEe-Yu95zZEQSuw" value="_Dyh7EKHSEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="__SvEq6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvErKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEraHTEe-Yu95zZEQSuw" ref="resource.md#_h_2qwKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS_FK?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvErqHTEe-Yu95zZEQSuw" value="_DypP2qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEr6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.COD_ENS_FK"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEsKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEsaHTEe-Yu95zZEQSuw" ref="resource.md#_h_2qxqHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_FK?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEsqHTEe-Yu95zZEQSuw" value="_DypP26HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEs6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.NUM_TIC_FK"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEtKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEtaHTEe-Yu95zZEQSuw" ref="resource.md#_h_1csqHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC_EUR?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEtqHTEe-Yu95zZEQSuw" value="_DypP1aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEt6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.MNT_TTC_EUR"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEuKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEuaHTEe-Yu95zZEQSuw" ref="resource.md#_h_2DsKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_FK?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEuqHTEe-Yu95zZEQSuw" value="_DypP1qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEu6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.COD_MAG_FK"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEvKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEvaHTEe-Yu95zZEQSuw" ref="resource.md#_h_1cpqHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEvqHTEe-Yu95zZEQSuw" value="_DypP06HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEv6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.MNT_TTC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEwKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEwaHTEe-Yu95zZEQSuw" ref="resource.md#_h_1coKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEwqHTEe-Yu95zZEQSuw" value="_DypP0qHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEw6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.MNT_BRU"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvExKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvExaHTEe-Yu95zZEQSuw" ref="resource.md#_h_01nKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvExqHTEe-Yu95zZEQSuw" value="_DypP0aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEx6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.QTE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEyKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEyaHTEe-Yu95zZEQSuw" ref="resource.md#_h_2DtqHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_FK?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEyqHTEe-Yu95zZEQSuw" value="_DypP16HSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEy6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.COD_ART_FK"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvEzKHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvEzaHTEe-Yu95zZEQSuw" ref="resource.md#_h_2DvKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_FK?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvEzqHTEe-Yu95zZEQSuw" value="_DypP2KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvEz6HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.COD_MRQ_FK"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvE0KHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvE0aHTEe-Yu95zZEQSuw" ref="resource.md#_h_1crKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU_EUR?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvE0qHTEe-Yu95zZEQSuw" value="_DypP1KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvE06HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.MNT_BRU_EUR"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvE1KHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvE1aHTEe-Yu95zZEQSuw" ref="resource.md#_h_01lqHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_HEURE_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvE1qHTEe-Yu95zZEQSuw" value="_DypP0KHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvE16HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.DATE_HEURE_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvE2KHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvE2aHTEe-Yu95zZEQSuw" ref="resource.md#_h_2DwqHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL_FK?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvE2qHTEe-Yu95zZEQSuw" value="_DypP2aHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvE26HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.COD_CAL_FK"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="__SvE3KHTEe-Yu95zZEQSuw">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="__SvE3aHTEe-Yu95zZEQSuw" ref="resource.md#_h_01kKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_NUM_CAISSE_NUM_TIC_NUL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="__SvE3qHTEe-Yu95zZEQSuw" value="_DyoowaHSEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="__SvE36HTEe-Yu95zZEQSuw" value="SAS_LIGNETICKET.COD_MAG_NUM_CAISSE_NUM_TIC_NUL"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="__SvEm6HTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="__SvEnKHTEe-Yu95zZEQSuw" ref="resource.md#_OOP4EJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=Ticket_20240801?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="__SvE4KHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="__SvE4aHTEe-Yu95zZEQSuw" ref="resource.md#_h8RLQKHREe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_LIGNETICKET?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore" id="__SvE8aHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.sourceRef" id="__SvE8qHTEe-Yu95zZEQSuw" ref="resource.md#__SvE7qHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.targetRef" id="__SvE86HTEe-Yu95zZEQSuw" ref="resource.md#__SvEqaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvE-qHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvE-6HTEe-Yu95zZEQSuw" ref="resource.md#__SvE96HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvE_KHTEe-Yu95zZEQSuw" ref="resource.md#__SvEO6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFAKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFAaHTEe-Yu95zZEQSuw" ref="resource.md#__SvE_aHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFAqHTEe-Yu95zZEQSuw" ref="resource.md#__SvER6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFBqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFB6HTEe-Yu95zZEQSuw" ref="resource.md#__SvFA6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFCKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEf6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFDKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFDaHTEe-Yu95zZEQSuw" ref="resource.md#__SvFCaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFDqHTEe-Yu95zZEQSuw" ref="resource.md#__SvEH6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFEqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFE6HTEe-Yu95zZEQSuw" ref="resource.md#__SvFD6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFFKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEW6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFGKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFGaHTEe-Yu95zZEQSuw" ref="resource.md#__SvFFaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFGqHTEe-Yu95zZEQSuw" ref="resource.md#__SvEI6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFHqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFH6HTEe-Yu95zZEQSuw" ref="resource.md#__SvFG6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFIKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEE6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFJKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFJaHTEe-Yu95zZEQSuw" ref="resource.md#__SvFIaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFJqHTEe-Yu95zZEQSuw" ref="resource.md#__SvEF6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="__SvFKqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="__SvFK6HTEe-Yu95zZEQSuw" ref="resource.md#__SvFJ6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="__SvFLKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEi6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFLaHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFLqHTEe-Yu95zZEQSuw" ref="resource.md#__SvFIaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFL6HTEe-Yu95zZEQSuw" ref="resource.md#__SvE3KHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFMKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFMaHTEe-Yu95zZEQSuw" ref="resource.md#__SvFA6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFMqHTEe-Yu95zZEQSuw" ref="resource.md#__SvEvKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFM6HTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFNKHTEe-Yu95zZEQSuw" ref="resource.md#__SvFCaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFNaHTEe-Yu95zZEQSuw" ref="resource.md#__SvEwKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFNqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFN6HTEe-Yu95zZEQSuw" ref="resource.md#__SvFG6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFOKHTEe-Yu95zZEQSuw" ref="resource.md#__SvE1KHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFOaHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFOqHTEe-Yu95zZEQSuw" ref="resource.md#__SvFD6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFO6HTEe-Yu95zZEQSuw" ref="resource.md#__SvExKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFPKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFPaHTEe-Yu95zZEQSuw" ref="resource.md#__SvFFaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFPqHTEe-Yu95zZEQSuw" ref="resource.md#__SvEyKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFP6HTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFQKHTEe-Yu95zZEQSuw" ref="resource.md#__SvE96HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFQaHTEe-Yu95zZEQSuw" ref="resource.md#__SvErKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFQqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFQ6HTEe-Yu95zZEQSuw" ref="resource.md#__SvE_aHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFRKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEsKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFRaHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFRqHTEe-Yu95zZEQSuw" ref="resource.md#__SvE_aHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFR6HTEe-Yu95zZEQSuw" ref="resource.md#__SvE3KHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="__SvFSKHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="__SvFSaHTEe-Yu95zZEQSuw" ref="resource.md#__SvFJ6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="__SvFSqHTEe-Yu95zZEQSuw" ref="resource.md#__SvE3KHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="__SvEnaHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="__SvEnqHTEe-Yu95zZEQSuw" ref="resource.md#__SvEEKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="__SvEn6HTEe-Yu95zZEQSuw" ref="resource.md#__SvEm6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="__SvE4qHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="__SvE46HTEe-Yu95zZEQSuw" ref="resource.md#__SvEqaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="__SvE5KHTEe-Yu95zZEQSuw" ref="resource.md#__SvE4KHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="__SvEo6HTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="__SvEpKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEoKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="__SvEpaHTEe-Yu95zZEQSuw" ref="resource.md#__SvEm6HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="__SvEpqHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="__SvEp6HTEe-Yu95zZEQSuw" ref="resource.md#__Sud66HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="__SvEqKHTEe-Yu95zZEQSuw" ref="resource.md#__SvEEKHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="__SvE6KHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="__SvE6aHTEe-Yu95zZEQSuw" ref="resource.md#__SvE5aHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="__SvE6qHTEe-Yu95zZEQSuw" ref="resource.md#__SvE4KHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="__SvE66HTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="__SvE7KHTEe-Yu95zZEQSuw" ref="resource.md#__Sud66HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="__SvE7aHTEe-Yu95zZEQSuw" ref="resource.md#__SvEqaHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="__SvE9KHTEe-Yu95zZEQSuw">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="__SvE9aHTEe-Yu95zZEQSuw" ref="resource.md#__Sud66HTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="__SvE9qHTEe-Yu95zZEQSuw" ref="resource.md#__SvE7qHTEe-Yu95zZEQSuw?fileId=_AwMLcKHSEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
</md:node>