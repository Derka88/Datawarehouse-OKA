<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_-1nhQKcYEe-ti-Zc6dspJw-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_upcTobJHEe-7gLO1_RM3Dg">
    <attribute defType="com.stambia.flow.altId.origin" id="_upcTorJHEe-7gLO1_RM3Dg" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_upcTo7JHEe-7gLO1_RM3Dg" value="_-1nhQKcYEe-ti-Zc6dspJw"/>
  </node>
  <node defType="com.stambia.flow.step" id="44973b6b-fc14-3da7-a0ae-8906c6946edf" name="I1_ARTICLE">
    <attribute defType="com.stambia.flow.step.number" id="_upglEbJHEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_upglErJHEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_upglE7JHEe-7gLO1_RM3Dg" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_upglFLJHEe-7gLO1_RM3Dg" name="SAS_ARTICLE">
      <attribute defType="com.stambia.flow.source.target" id="_upglFbJHEe-7gLO1_RM3Dg" value="$MD_13"/>
    </node>
    <node defType="com.stambia.flow.field" id="_upglFrJHEe-7gLO1_RM3Dg" name="COD_ART">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglF7JHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglGLJHEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglGbJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglGrJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglG7JHEe-7gLO1_RM3Dg">
        <values>$MD_21</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglHLJHEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglHbJHEe-7gLO1_RM3Dg" ref="resource.md#__4cwUKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglHrJHEe-7gLO1_RM3Dg" value="'SAS_ARTICLE.%{MD_21}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglH7JHEe-7gLO1_RM3Dg" value="COD_ART"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglILJHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglIbJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglIrJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_upglI7JHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglJLJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_21}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglJbJHEe-7gLO1_RM3Dg" name="LIB_PRD">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglJrJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglJ7JHEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglKLJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglKbJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglKrJHEe-7gLO1_RM3Dg">
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglK7JHEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglLLJHEe-7gLO1_RM3Dg" ref="resource.md#__4cwVqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglLbJHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_22}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglLrJHEe-7gLO1_RM3Dg" value="LIB_PRD"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglL7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglMLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglMbJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglMrJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglM7JHEe-7gLO1_RM3Dg" name="LIB_COL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglNLJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglNbJHEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglNrJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglN7JHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglOLJHEe-7gLO1_RM3Dg">
        <values>$MD_15</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglObJHEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglOrJHEe-7gLO1_RM3Dg" ref="resource.md#__4dXYKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglO7JHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_15}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglPLJHEe-7gLO1_RM3Dg" value="LIB_COL"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglPbJHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglPrJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglP7JHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglQLJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_15}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglQbJHEe-7gLO1_RM3Dg" name="LIB_TAI">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglQrJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglQ7JHEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglRLJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglRbJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglRrJHEe-7gLO1_RM3Dg">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglR7JHEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglSLJHEe-7gLO1_RM3Dg" ref="resource.md#__4dXZqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglSbJHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_23}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglSrJHEe-7gLO1_RM3Dg" value="LIB_TAI"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglS7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglTLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglTbJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglTrJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_23}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglT7JHEe-7gLO1_RM3Dg" name="FAM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglULJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglUbJHEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglUrJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglU7JHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglVLJHEe-7gLO1_RM3Dg">
        <values>$MD_20</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglVbJHEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglVrJHEe-7gLO1_RM3Dg" ref="resource.md#__4dXbKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglV7JHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_20}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglWLJHEe-7gLO1_RM3Dg" value="FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglWbJHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglWrJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglW7JHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglXLJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_20}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglXbJHEe-7gLO1_RM3Dg" name="SS_FAM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglXrJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglX7JHEe-7gLO1_RM3Dg" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglYLJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglYbJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglYrJHEe-7gLO1_RM3Dg">
        <values>$MD_19</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglY7JHEe-7gLO1_RM3Dg" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglZLJHEe-7gLO1_RM3Dg" ref="resource.md#__4dXcqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglZbJHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_19}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglZrJHEe-7gLO1_RM3Dg" value="SS_FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglZ7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglaLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglabJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglarJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_19}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upgla7JHEe-7gLO1_RM3Dg" name="PRX_VEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglbLJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglbbJHEe-7gLO1_RM3Dg" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglbrJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglb7JHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglcLJHEe-7gLO1_RM3Dg">
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglcbJHEe-7gLO1_RM3Dg" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglcrJHEe-7gLO1_RM3Dg" ref="resource.md#__4d-cKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglc7JHEe-7gLO1_RM3Dg" value="'SAS_ARTICLE.%{MD_16}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upgldLJHEe-7gLO1_RM3Dg" value="PRX_VEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_upgldbJHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upgldrJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upgld7JHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upgleLJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_16}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglebJHEe-7gLO1_RM3Dg" name="LIB_GEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglerJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upgle7JHEe-7gLO1_RM3Dg" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglfLJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglfbJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglfrJHEe-7gLO1_RM3Dg">
        <values>$MD_17</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglf7JHEe-7gLO1_RM3Dg" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglgLJHEe-7gLO1_RM3Dg" ref="resource.md#__4d-dqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglgbJHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_17}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglgrJHEe-7gLO1_RM3Dg" value="LIB_GEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglg7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglhLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglhbJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglhrJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_17}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglh7JHEe-7gLO1_RM3Dg" name="CIB_TRN_AGE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upgliLJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglibJHEe-7gLO1_RM3Dg" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglirJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upgli7JHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upgljLJHEe-7gLO1_RM3Dg">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upgljbJHEe-7gLO1_RM3Dg" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upgljrJHEe-7gLO1_RM3Dg" ref="resource.md#__4d-fKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglj7JHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_18}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglkLJHEe-7gLO1_RM3Dg" value="CIB_TRN_AGE"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglkbJHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglkrJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglk7JHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upgllLJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_18}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upgllbJHEe-7gLO1_RM3Dg" name="LIB_CAT">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upgllrJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upgll7JHEe-7gLO1_RM3Dg" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglmLJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_upglmbJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_upglmrJHEe-7gLO1_RM3Dg">
        <values>$MD_14</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_upglm7JHEe-7gLO1_RM3Dg" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglnLJHEe-7gLO1_RM3Dg" ref="resource.md#__4d-gqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglnbJHEe-7gLO1_RM3Dg" value="'INITCAP(SAS_ARTICLE.%{MD_14}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglnrJHEe-7gLO1_RM3Dg" value="LIB_CAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_upgln7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upgloLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglobJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_upglorJHEe-7gLO1_RM3Dg">
        <values>SAS_ARTICLE.%{MD_14}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_upglo7JHEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_upglpLJHEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_upglpbJHEe-7gLO1_RM3Dg" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_upglprJHEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.target" id="_upglp7JHEe-7gLO1_RM3Dg" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_upglqLJHEe-7gLO1_RM3Dg" ref="resource.md#_-RNo0LI-Ee-BObk_rBUyXw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_upglqbJHEe-7gLO1_RM3Dg" value="'TO_CHAR(SYSDATE, ''YYYYMMDDHH24MISS'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_upglqrJHEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
      <attribute defType="com.stambia.flow.field.version" id="_upglq7JHEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_upglrLJHEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_upglrbJHEe-7gLO1_RM3Dg" value="true"/>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="67fe0e82-a6f5-3b8e-b9b9-09f9eb19fc12" name="R1_ARTICLE">
    <attribute defType="com.stambia.flow.step.number" id="_upglr7JHEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_upglsLJHEe-7gLO1_RM3Dg">
      <values>I1_ARTICLE</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_upglsbJHEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_upglsrJHEe-7gLO1_RM3Dg" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_upgls7JHEe-7gLO1_RM3Dg" name="PK_ARTICLE">
      <attribute defType="com.stambia.flow.constraint.type" id="_upgltLJHEe-7gLO1_RM3Dg" value="pk"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_upgltbJHEe-7gLO1_RM3Dg" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_upgltrJHEe-7gLO1_RM3Dg" name="NN_COD_ART">
      <attribute defType="com.stambia.flow.constraint.type" id="_upglt7JHEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_upgluLJHEe-7gLO1_RM3Dg" value="$MD_2"/>
    </node>
  </node>
  <metaDataLink name="MD_23" target="resource.md#_iPn_cqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
  <metaDataLink name="MD_8" target="resource.md#__4d-cKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
  <metaDataLink name="MD_3" target="resource.md#__4cwVqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
  <metaDataLink name="MD_5" target="resource.md#__4dXZqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
  <metaDataLink name="MD_20" target="resource.md#_iPn_eKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
  <metaDataLink name="MD_9" target="resource.md#__4d-dqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
  <metaDataLink name="MD_10" target="resource.md#__4d-fKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
  <metaDataLink name="MD_0" target="resource.md#__yvw8KG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ARTICLE?"/>
  <metaDataLink name="MD_6" target="resource.md#__4dXbKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
  <metaDataLink name="MD_19" target="resource.md#_iPn_fqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
  <metaDataLink name="MD_21" target="resource.md#_iPn_YKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_11" target="resource.md#__4d-gqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
  <metaDataLink name="MD_22" target="resource.md#_iPn_ZqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
  <metaDataLink name="MD_4" target="resource.md#__4dXYKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
  <metaDataLink name="MD_12" target="resource.md#_-RNo0LI-Ee-BObk_rBUyXw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
  <metaDataLink name="MD_18" target="resource.md#_iPomfKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
  <metaDataLink name="MD_2" target="resource.md#__4cwUKG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_14" target="resource.md#_iPomgqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
  <metaDataLink name="MD_13" target="resource.md#_iMSXgKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_ARTICLE?"/>
  <metaDataLink name="MD_7" target="resource.md#__4dXcqG_Ee-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
  <metaDataLink name="MD_1" target="resource.md#_j75FcLI_Ee-BObk_rBUyXw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PK_ARTICLE?"/>
  <metaDataLink name="MD_15" target="resource.md#_iPn_bKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
  <metaDataLink name="MD_16" target="resource.md#_iPomcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
  <metaDataLink name="MD_17" target="resource.md#_iPomdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
</md:node>