<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.semarchy.xdi.harvest.model" id="_zqgscKHCEe-Mishx4UyKwQ-xdg" md:ref="resource.tech#UUID_TECH_XDI_HARVESTED?fileId=UUID_TECH_XDI_HARVESTED?" internalVersion="v2.0.0">
  <node defType="com.semarchy.xdi.harvest.mapping" id="_9qYP6KHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelId" id="_9qY18KHCEe-Mishx4UyKwQ" value="_zqgscKHCEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelName" id="_9qY18aHCEe-Mishx4UyKwQ" value="ALIM_SAS_ARTICLE"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_9qY2a6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_9qY2bKHCEe-Mishx4UyKwQ" value="_1I9ZsKG9Ee-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_9qY2baHCEe-Mishx4UyKwQ" value="BDD"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_9qY2MqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_9qY2M6HCEe-Mishx4UyKwQ" value="_oP4f4JbEEe-yJMimzYo_ug"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_9qY2NKHCEe-Mishx4UyKwQ" value="ARTICLE"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceset" id="_9qY2dKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelName" id="_9qY2daHCEe-Mishx4UyKwQ" value="Source SAS_ARTICLE"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelId" id="_9qY2dqHCEe-Mishx4UyKwQ" value="ss-_5zeOwKHCEe-Mishx4UyKwQ"/>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2faHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2fqHCEe-Mishx4UyKwQ" value="Source Article_20240801.LIB_PRD"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2f6HCEe-Mishx4UyKwQ" value="ssf-_5_TrVaHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2g6HCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2hKHCEe-Mishx4UyKwQ" value="Source Article_20240801.COD_ART"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2haHCEe-Mishx4UyKwQ" value="ssf-_5_TrVKHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2iaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2iqHCEe-Mishx4UyKwQ" value="Source Article_20240801.LIB_COL"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2i6HCEe-Mishx4UyKwQ" value="ssf-_5_USYKHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2j6HCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2kKHCEe-Mishx4UyKwQ" value="Source Article_20240801.PRX_VEN"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2kaHCEe-Mishx4UyKwQ" value="ssf-_5_USZKHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2laHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2lqHCEe-Mishx4UyKwQ" value="Source Article_20240801.FAM"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2l6HCEe-Mishx4UyKwQ" value="ssf-_5_USYqHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2m6HCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2nKHCEe-Mishx4UyKwQ" value="Source Article_20240801.LIB_TAI"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2naHCEe-Mishx4UyKwQ" value="ssf-_5_USYaHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2oaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2oqHCEe-Mishx4UyKwQ" value="Source Article_20240801.LIB_GEN"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2o6HCEe-Mishx4UyKwQ" value="ssf-_5_USZaHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2p6HCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2qKHCEe-Mishx4UyKwQ" value="Source Article_20240801.CIB_TRN_AGE"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2qaHCEe-Mishx4UyKwQ" value="ssf-_5_USZqHCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2raHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2rqHCEe-Mishx4UyKwQ" value="Source Article_20240801.SS_FAM"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2r6HCEe-Mishx4UyKwQ" value="ssf-_5_USY6HCEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_9qY2s6HCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_9qY2tKHCEe-Mishx4UyKwQ" value="Source Article_20240801.LIB_CAT"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_9qY2taHCEe-Mishx4UyKwQ" value="ssf-_5_USaKHCEe-Mishx4UyKwQ"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_9qY18qHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_9qY186HCEe-Mishx4UyKwQ" value="_5_TEQKHCEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_9qY19KHCEe-Mishx4UyKwQ" value="Article_20240801"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY19aHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY19qHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGTJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=SS_FAM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY196HCEe-Mishx4UyKwQ" value="_5_USY6HCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY1-KHCEe-Mishx4UyKwQ" value="Article_20240801.SS_FAM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY1-aHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY1-qHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGQJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_COL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY1-6HCEe-Mishx4UyKwQ" value="_5_USYKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY1_KHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_COL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY1_aHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY1_qHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGMJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_MRQ?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY1_6HCEe-Mishx4UyKwQ" value="_5_TrUqHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2AKHCEe-Mishx4UyKwQ" value="Article_20240801.COD_MRQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2AaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2AqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGPJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_PRD?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2A6HCEe-Mishx4UyKwQ" value="_5_TrVaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2BKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_PRD"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2BaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2BqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGNJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_MRQ?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2B6HCEe-Mishx4UyKwQ" value="_5_TrU6HCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2CKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_MRQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2CaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2CqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGSJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=FAM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2C6HCEe-Mishx4UyKwQ" value="_5_USYqHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2DKHCEe-Mishx4UyKwQ" value="Article_20240801.FAM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2DaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2DqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGXZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_CAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2D6HCEe-Mishx4UyKwQ" value="_5_USZ6HCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2EKHCEe-Mishx4UyKwQ" value="Article_20240801.COD_CAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2EaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2EqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGVZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_GEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2E6HCEe-Mishx4UyKwQ" value="_5_USZaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2FKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_GEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2FaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2FqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGRJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_TAI?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2F6HCEe-Mishx4UyKwQ" value="_5_USYaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2GKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_TAI"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2GaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2GqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGWZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2G6HCEe-Mishx4UyKwQ" value="_5_USZqHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2HKHCEe-Mishx4UyKwQ" value="Article_20240801.CIB_TRN_AGE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2HaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2HqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGOJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=COD_ART?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2H6HCEe-Mishx4UyKwQ" value="_5_TrVKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2IKHCEe-Mishx4UyKwQ" value="Article_20240801.COD_ART"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2IaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2IqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=PRX_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2I6HCEe-Mishx4UyKwQ" value="_5_USZKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2JKHCEe-Mishx4UyKwQ" value="Article_20240801.PRX_VEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2JaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2JqHCEe-Mishx4UyKwQ" ref="resource.md#_Z6ggUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=Article_20240801?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2J6HCEe-Mishx4UyKwQ" value="_5_TrUaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2KKHCEe-Mishx4UyKwQ" value="Article_20240801.Article_20240801"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2KaHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2KqHCEe-Mishx4UyKwQ" ref="resource.md#_lLUGYZbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=LIB_CAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2K6HCEe-Mishx4UyKwQ" value="_5_USaKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2LKHCEe-Mishx4UyKwQ" value="Article_20240801.LIB_CAT"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_9qY2O6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_9qY2PKHCEe-Mishx4UyKwQ" value="_5zeOwKHCEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_9qY2PaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2PqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2P6HCEe-Mishx4UyKwQ" ref="resource.md#_iPn_ZqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2QKHCEe-Mishx4UyKwQ" value="_5zljgqHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2QaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.LIB_PRD"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2QqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2Q6HCEe-Mishx4UyKwQ" ref="resource.md#_iPn_YKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2RKHCEe-Mishx4UyKwQ" value="_5zljgaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2RaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.COD_ART"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2RqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2R6HCEe-Mishx4UyKwQ" ref="resource.md#_iPn_bKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2SKHCEe-Mishx4UyKwQ" value="_5zmKkKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2SaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.LIB_COL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2SqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2S6HCEe-Mishx4UyKwQ" ref="resource.md#_iPomcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2TKHCEe-Mishx4UyKwQ" value="_5zmxoqHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2TaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.PRX_VEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2TqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2T6HCEe-Mishx4UyKwQ" ref="resource.md#_iPn_eKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2UKHCEe-Mishx4UyKwQ" value="_5zmxoKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2UaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.FAM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2UqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2U6HCEe-Mishx4UyKwQ" ref="resource.md#_iPn_cqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2VKHCEe-Mishx4UyKwQ" value="_5zmKkaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2VaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.LIB_TAI"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2VqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2V6HCEe-Mishx4UyKwQ" ref="resource.md#_iPomdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2WKHCEe-Mishx4UyKwQ" value="_5znYsKHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2WaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.LIB_GEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2WqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2W6HCEe-Mishx4UyKwQ" ref="resource.md#_iPomfKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2XKHCEe-Mishx4UyKwQ" value="_5znYsaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2XaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.CIB_TRN_AGE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2XqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2X6HCEe-Mishx4UyKwQ" ref="resource.md#_iPn_fqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2YKHCEe-Mishx4UyKwQ" value="_5zmxoaHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2YaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.SS_FAM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_9qY2YqHCEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_9qY2Y6HCEe-Mishx4UyKwQ" ref="resource.md#_iPomgqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_9qY2ZKHCEe-Mishx4UyKwQ" value="_5znYsqHCEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_9qY2ZaHCEe-Mishx4UyKwQ" value="SAS_ARTICLE.LIB_CAT"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_9qY2LaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_9qY2LqHCEe-Mishx4UyKwQ" ref="resource.md#_Z6ggUJbFEe-yJMimzYo_ug?fileId=_oP4f4JbEEe-yJMimzYo_ug$type=md$name=Article_20240801?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_9qY2ZqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_9qY2Z6HCEe-Mishx4UyKwQ" ref="resource.md#_iMSXgKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_ARTICLE?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore" id="_9qY2d6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.sourceRef" id="_9qY2eKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2dKHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.targetRef" id="_9qY2eaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2O6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2gKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2gaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2faHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2gqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2AaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2hqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2h6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2g6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2iKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2HaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2jKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2jaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2iaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2jqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY1-aHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2kqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2k6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2j6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2lKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2IaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2mKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2maHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2laHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2mqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2CaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2nqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2n6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2m6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2oKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2FaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2pKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2paHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2oaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2pqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2EaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2qqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2q6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2p6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2rKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2GaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2sKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2saHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2raHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2sqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY19aHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_9qY2tqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_9qY2t6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2s6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_9qY2uKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2KaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2uaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2uqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2s6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2u6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2YqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2vKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2vaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2m6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2vqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2UqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2v6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2wKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2iaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2waHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2RqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2wqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2w6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2raHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2xKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2XqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2xaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2xqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2oaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2x6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2VqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2yKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2yaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2p6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2yqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2WqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2y6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2zKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2j6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY2zaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2SqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY2zqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY2z6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2g6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY20KHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2QqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY20aHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY20qHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2faHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY206HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2PqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_9qY21KHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_9qY21aHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2laHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_9qY21qHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2TqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_9qY2L6HCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_9qY2MKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY18qHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_9qY2MaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2LaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_9qY2aKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_9qY2aaHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2O6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_9qY2aqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2ZqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_9qY2NaHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_9qY2NqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2MqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_9qY2N6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2LaHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_9qY2OKHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_9qY2OaHCEe-Mishx4UyKwQ" ref="resource.md#_9qYP6KHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_9qY2OqHCEe-Mishx4UyKwQ" ref="resource.md#_9qY18qHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_9qY2bqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_9qY2b6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2a6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_9qY2cKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2ZqHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_9qY2caHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_9qY2cqHCEe-Mishx4UyKwQ" ref="resource.md#_9qYP6KHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_9qY2c6HCEe-Mishx4UyKwQ" ref="resource.md#_9qY2O6HCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_9qY2eqHCEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_9qY2e6HCEe-Mishx4UyKwQ" ref="resource.md#_9qYP6KHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_9qY2fKHCEe-Mishx4UyKwQ" ref="resource.md#_9qY2dKHCEe-Mishx4UyKwQ?fileId=_zqgscKHCEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
</md:node>