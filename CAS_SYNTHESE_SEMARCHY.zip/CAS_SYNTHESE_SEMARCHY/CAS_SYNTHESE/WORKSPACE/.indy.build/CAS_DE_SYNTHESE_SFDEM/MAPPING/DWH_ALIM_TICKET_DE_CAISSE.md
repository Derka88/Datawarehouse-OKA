<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_4xhugKcxEe-hX4kfFNbs-Q-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_hIDBI7JGEe-7gLO1_RM3Dg">
    <attribute defType="com.stambia.flow.altId.origin" id="_hIDBJLJGEe-7gLO1_RM3Dg" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_hIDBJbJGEe-7gLO1_RM3Dg" value="_4xhugKcxEe-hX4kfFNbs-Q"/>
  </node>
  <node defType="com.stambia.flow.step" id="a506238a-6ff0-3c51-b5d4-cfa35634b4d6" name="I1_TICKETDECAISSE">
    <attribute defType="com.stambia.flow.step.number" id="_hIMKkrJGEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_hIMKk7JGEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_hIMKlLJGEe-7gLO1_RM3Dg" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_hIMKlbJGEe-7gLO1_RM3Dg" name="SAS_TICKETDECAISSE">
      <attribute defType="com.stambia.flow.source.target" id="_hIMKlrJGEe-7gLO1_RM3Dg" value="$MD_7"/>
    </node>
    <node defType="com.stambia.flow.field" id="_hIMKl7JGEe-7gLO1_RM3Dg" name="CODMAGNUMCAINUMTIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hIMKmLJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hIMKmbJGEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_hIMKmrJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hIMKm7JGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hIMKnLJGEe-7gLO1_RM3Dg">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hIMKnbJGEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hIMKnrJGEe-7gLO1_RM3Dg" ref="resource.md#_2gAu8K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hIMKn7JGEe-7gLO1_RM3Dg" value="'SAS_TICKETDECAISSE.%{MD_9}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hIMKoLJGEe-7gLO1_RM3Dg" value="CODMAGNUMCAINUMTIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_hIMKobJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hIMKorJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hIMKo7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_hIMKpLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hIMKpbJGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hIMKprJGEe-7gLO1_RM3Dg" name="COD_DEV">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hIMKp7JGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hIMKqLJGEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_hIMKqbJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hIMKqrJGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hIMKq7JGEe-7gLO1_RM3Dg">
        <values>$MD_8</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hIMKrLJGEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hIMKrbJGEe-7gLO1_RM3Dg" ref="resource.md#_2gCkIK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hIMKrrJGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_TICKETDECAISSE.%{MD_8}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hIMKr7JGEe-7gLO1_RM3Dg" value="COD_DEV"/>
      <attribute defType="com.stambia.flow.field.version" id="_hIMKsLJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hIMKsbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hIMKsrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hIMKs7JGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE.%{MD_8}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hIMKtLJGEe-7gLO1_RM3Dg" name="COD_VEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hIMKtbJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hIMKtrJGEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_hIMKt7JGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hIMKuLJGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hIMKubJGEe-7gLO1_RM3Dg">
        <values>$MD_10</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hIMKurJGEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hIMKu7JGEe-7gLO1_RM3Dg" ref="resource.md#_2gDLMK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hIMKvLJGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_TICKETDECAISSE.%{MD_10}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hIMKvbJGEe-7gLO1_RM3Dg" value="COD_VEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_hIMKvrJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hIMKv7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hIMKwLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hIMKwbJGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE.%{MD_10}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hIMKwrJGEe-7gLO1_RM3Dg" name="DATE_HEURE_TIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hIMKw7JGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hIMKxLJGEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_hIMKxbJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_hIMKxrJGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_hIMKx7JGEe-7gLO1_RM3Dg">
        <values>$MD_11</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_hIMKyLJGEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hIMKybJGEe-7gLO1_RM3Dg" ref="resource.md#_2gEZUK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_HEURE_TIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hIMKyrJGEe-7gLO1_RM3Dg" value="'SAS_TICKETDECAISSE.%{MD_11}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hIMKy7JGEe-7gLO1_RM3Dg" value="DATE_HEURE_TIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_hIMKzLJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hIMKzbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hIMKzrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_hIMKz7JGEe-7gLO1_RM3Dg">
        <values>SAS_TICKETDECAISSE.%{MD_11}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_hIMK0LJGEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_hIMK0bJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_hIMK0rJGEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_hIMK07JGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.target" id="_hIMK1LJGEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_hIMK1bJGEe-7gLO1_RM3Dg" ref="resource.md#_4eYKsLJCEe-7gLO1_RM3Dg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_hIMK1rJGEe-7gLO1_RM3Dg" value="'TO_CHAR(SYSDATE, ''YYYYMMDDHH24MISS'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_hIMK17JGEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
      <attribute defType="com.stambia.flow.field.version" id="_hIMK2LJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_hIMK2bJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_hIMK2rJGEe-7gLO1_RM3Dg" value="true"/>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="62ea5037-aeb9-3b3c-9af1-4d05d3d3642f" name="R1_TICKETDECAISSE">
    <attribute defType="com.stambia.flow.step.number" id="_hIMK3LJGEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_hIMK3bJGEe-7gLO1_RM3Dg">
      <values>I1_TICKETDECAISSE</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_hIMK3rJGEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_hIMK37JGEe-7gLO1_RM3Dg" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_hIMK4LJGEe-7gLO1_RM3Dg" name="PK_TICKETDECAISSE">
      <attribute defType="com.stambia.flow.constraint.type" id="_hIMK4bJGEe-7gLO1_RM3Dg" value="pk"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_hIMK4rJGEe-7gLO1_RM3Dg" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_hIMK47JGEe-7gLO1_RM3Dg" name="NN_COD_VEN">
      <attribute defType="com.stambia.flow.constraint.type" id="_hIMK5LJGEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_hIMK5bJGEe-7gLO1_RM3Dg" value="$MD_2"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_hIMK5rJGEe-7gLO1_RM3Dg" name="NN_CODMAGNUMCAINUMTIC">
      <attribute defType="com.stambia.flow.constraint.type" id="_hIMK57JGEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_hIMK6LJGEe-7gLO1_RM3Dg" value="$MD_3"/>
    </node>
  </node>
  <metaDataLink name="MD_2" target="resource.md#_2gDLMK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
  <metaDataLink name="MD_5" target="resource.md#_2gEZUK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_HEURE_TIC?"/>
  <metaDataLink name="MD_3" target="resource.md#_2gAu8K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
  <metaDataLink name="MD_7" target="resource.md#_20HWsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_TICKETDECAISSE?"/>
  <metaDataLink name="MD_9" target="resource.md#_3CdUsK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAINUMTIC?"/>
  <metaDataLink name="MD_1" target="resource.md#_2z4tMK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PK_TICKETDECAISSE?"/>
  <metaDataLink name="MD_11" target="resource.md#_3CgYAK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_HEURE_TIC?"/>
  <metaDataLink name="MD_8" target="resource.md#_3CfJ4K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
  <metaDataLink name="MD_0" target="resource.md#_1CfoEK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TICKETDECAISSE?"/>
  <metaDataLink name="MD_10" target="resource.md#_3Cfw8K5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
  <metaDataLink name="MD_6" target="resource.md#_4eYKsLJCEe-7gLO1_RM3Dg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
  <metaDataLink name="MD_4" target="resource.md#_2gCkIK5wEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
</md:node>