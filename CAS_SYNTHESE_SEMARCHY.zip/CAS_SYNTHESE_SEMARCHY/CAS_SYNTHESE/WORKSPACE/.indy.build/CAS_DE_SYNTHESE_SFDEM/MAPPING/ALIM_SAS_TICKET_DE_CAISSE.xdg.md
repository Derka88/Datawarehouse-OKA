<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.semarchy.xdi.harvest.model" id="_yxluIKHHEe-Mishx4UyKwQ-xdg" md:ref="resource.tech#UUID_TECH_XDI_HARVESTED?fileId=UUID_TECH_XDI_HARVESTED?" internalVersion="v2.0.0">
  <node defType="com.semarchy.xdi.harvest.mapping" id="_eIz3KaHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelId" id="_eIz3KqHIEe-Mishx4UyKwQ" value="_yxluIKHHEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelName" id="_eIz3K6HIEe-Mishx4UyKwQ" value="ALIM_SAS_TICKET_DE_CAISSE"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_eIz33aHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_eIz33qHIEe-Mishx4UyKwQ" value="_1I9ZsKG9Ee-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_eIz336HIEe-Mishx4UyKwQ" value="BDD"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_eIz3vKHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_eIz3vaHIEe-Mishx4UyKwQ" value="_OMrx0JbGEe-yJMimzYo_ug"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_eIz3vqHIEe-Mishx4UyKwQ" value="TICKET"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceset" id="_eIz35qHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelName" id="_eIz356HIEe-Mishx4UyKwQ" value="Source SAS_TICKET"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelId" id="_eIz36KHIEe-Mishx4UyKwQ" value="ss-_WLGZYKHIEe-Mishx4UyKwQ"/>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_eIz376HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_eIz38KHIEe-Mishx4UyKwQ" value="Source Ticket_20240801.COD_DEV"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_eIz38aHIEe-Mishx4UyKwQ" value="ssf-_5APoz6HHEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_eIz39aHIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_eIz39qHIEe-Mishx4UyKwQ" value="Source Ticket_20240801.REM_TIC"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_eIz396HIEe-Mishx4UyKwQ" value="ssf-_5APo0qHHEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_eIz3-6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_eIz3_KHIEe-Mishx4UyKwQ" value="Source Ticket_20240801.COD_VEN"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_eIz3_aHIEe-Mishx4UyKwQ" value="ssf-_5APoy6HHEe-Mishx4UyKwQ"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_eIz3LKHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_eIz3LaHIEe-Mishx4UyKwQ" value="_5APowKHHEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_eIz3LqHIEe-Mishx4UyKwQ" value="Ticket_20240801"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3L6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3MKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGZZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LNG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3MaHIEe-Mishx4UyKwQ" value="_5AQP0KHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3MqHIEe-Mishx4UyKwQ" value="Ticket_20240801.LNG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3M6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3NKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGb5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_OUV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3NaHIEe-Mishx4UyKwQ" value="_5AQP0qHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3NqHIEe-Mishx4UyKwQ" value="Ticket_20240801.DAT_OUV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3N6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3OKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGL5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3OaHIEe-Mishx4UyKwQ" value="_5APo0qHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3OqHIEe-Mishx4UyKwQ" value="Ticket_20240801.REM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3O6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3PKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGOZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3PaHIEe-Mishx4UyKwQ" value="_5APo1KHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3PqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3P6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3QKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGWZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REG_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3QaHIEe-Mishx4UyKwQ" value="_5APo3KHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3QqHIEe-Mishx4UyKwQ" value="Ticket_20240801.REG_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3Q6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3RKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGKpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REM_LIN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3RaHIEe-Mishx4UyKwQ" value="_5APo0aHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3RqHIEe-Mishx4UyKwQ" value="Ticket_20240801.REM_LIN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3R6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3SKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGXZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TEL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3SaHIEe-Mishx4UyKwQ" value="_5APo3aHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3SqHIEe-Mishx4UyKwQ" value="Ticket_20240801.TEL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3S6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3TKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGVZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DEP_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3TaHIEe-Mishx4UyKwQ" value="_5APo26HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3TqHIEe-Mishx4UyKwQ" value="Ticket_20240801.DEP_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3T6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3UKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGDJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_CAI?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3UaHIEe-Mishx4UyKwQ" value="_5APoyqHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3UqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_CAI"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3U6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3VKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGYZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=EMAIL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3VaHIEe-Mishx4UyKwQ" value="_5APo3qHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3VqHIEe-Mishx4UyKwQ" value="Ticket_20240801.EMAIL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3V6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3WKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGPZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3WaHIEe-Mishx4UyKwQ" value="_5APo1aHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3WqHIEe-Mishx4UyKwQ" value="Ticket_20240801.LIB_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3W6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3XKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGQZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR1?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3XaHIEe-Mishx4UyKwQ" value="_5APo1qHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3XqHIEe-Mishx4UyKwQ" value="Ticket_20240801.ADR1"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3X6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3YKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGTZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=VIL_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3YaHIEe-Mishx4UyKwQ" value="_5APo2aHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3YqHIEe-Mishx4UyKwQ" value="Ticket_20240801.VIL_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3Y6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3ZKHIEe-Mishx4UyKwQ" ref="resource.md#_OOP4EJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=Ticket_20240801?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3ZaHIEe-Mishx4UyKwQ" value="_5APowqHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3ZqHIEe-Mishx4UyKwQ" value="Ticket_20240801.Ticket_20240801"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3Z6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3aKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZF-JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3aaHIEe-Mishx4UyKwQ" value="_5APoxaHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3aqHIEe-Mishx4UyKwQ" value="Ticket_20240801.LIB_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3a6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3bKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGCJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=NUM_TIC_LIG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3baHIEe-Mishx4UyKwQ" value="_5APoyaHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3bqHIEe-Mishx4UyKwQ" value="Ticket_20240801.NUM_TIC_LIG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3b6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3cKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZF_JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_ART?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3caHIEe-Mishx4UyKwQ" value="_5APoxqHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3cqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_ART"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3c6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3dKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGGJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=MNT_BRU?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3daHIEe-Mishx4UyKwQ" value="_5APozaHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3dqHIEe-Mishx4UyKwQ" value="Ticket_20240801.MNT_BRU"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3d6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3eKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGapbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3eaHIEe-Mishx4UyKwQ" value="_5AQP0aHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3eqHIEe-Mishx4UyKwQ" value="Ticket_20240801.LAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3e6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3fKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGHZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=MNT_TTC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3faHIEe-Mishx4UyKwQ" value="_5APozqHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3fqHIEe-Mishx4UyKwQ" value="Ticket_20240801.MNT_TTC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3f6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3gKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGSZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR3?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3gaHIEe-Mishx4UyKwQ" value="_5APo2KHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3gqHIEe-Mishx4UyKwQ" value="Ticket_20240801.ADR3"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3g6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3hKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGNJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TX_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3haHIEe-Mishx4UyKwQ" value="_5APo06HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3hqHIEe-Mishx4UyKwQ" value="Ticket_20240801.TX_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3h6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3iKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZF9JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3iaHIEe-Mishx4UyKwQ" value="_5APoxKHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3iqHIEe-Mishx4UyKwQ" value="Ticket_20240801.LIB_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3i6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3jKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGUZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_POS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3jaHIEe-Mishx4UyKwQ" value="_5APo2qHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3jqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_POS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3j6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3kKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGFJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=QTE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3kaHIEe-Mishx4UyKwQ" value="_5APozKHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3kqHIEe-Mishx4UyKwQ" value="Ticket_20240801.QTE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3k6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3lKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGBJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=NUM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3laHIEe-Mishx4UyKwQ" value="_5APoyKHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3lqHIEe-Mishx4UyKwQ" value="Ticket_20240801.NUM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3l6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3mKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGIpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3maHIEe-Mishx4UyKwQ" value="_5APoz6HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3mqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3m6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3nKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZF8JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3naHIEe-Mishx4UyKwQ" value="_5APow6HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3nqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3n6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3oKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGd5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=SCHEDULE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3oaHIEe-Mishx4UyKwQ" value="_5AQP1KHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3oqHIEe-Mishx4UyKwQ" value="Ticket_20240801.SCHEDULE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3o6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3pKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGRZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR2?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3paHIEe-Mishx4UyKwQ" value="_5APo16HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3pqHIEe-Mishx4UyKwQ" value="Ticket_20240801.ADR2"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3p6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3qKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGc5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_FRM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3qaHIEe-Mishx4UyKwQ" value="_5AQP06HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3qqHIEe-Mishx4UyKwQ" value="Ticket_20240801.DAT_FRM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3q6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3rKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGJpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TX_TVA?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3raHIEe-Mishx4UyKwQ" value="_5APo0KHHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3rqHIEe-Mishx4UyKwQ" value="Ticket_20240801.TX_TVA"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3r6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3sKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGAJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_HEU_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3saHIEe-Mishx4UyKwQ" value="_5APox6HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3sqHIEe-Mishx4UyKwQ" value="Ticket_20240801.DAT_HEU_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3s6HIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3tKHIEe-Mishx4UyKwQ" ref="resource.md#_ZbZGEJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3taHIEe-Mishx4UyKwQ" value="_5APoy6HHEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3tqHIEe-Mishx4UyKwQ" value="Ticket_20240801.COD_VEN"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_eIz3xaHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_eIz3xqHIEe-Mishx4UyKwQ" value="_WLGZYKHIEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_eIz3x6HIEe-Mishx4UyKwQ" value="SAS_TICKET"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3yKHIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3yaHIEe-Mishx4UyKwQ" ref="resource.md#_iWSoEKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_NUM_CAISSE_NUM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3yqHIEe-Mishx4UyKwQ" value="_WLI1oaHIEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3y6HIEe-Mishx4UyKwQ" value="SAS_TICKET.COD_MAG_NUM_CAISSE_NUM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz3zKHIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz3zaHIEe-Mishx4UyKwQ" ref="resource.md#_iWSoFqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz3zqHIEe-Mishx4UyKwQ" value="_WLI1oqHIEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz3z6HIEe-Mishx4UyKwQ" value="SAS_TICKET.COD_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz30KHIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz30aHIEe-Mishx4UyKwQ" ref="resource.md#_iWSoHKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz30qHIEe-Mishx4UyKwQ" value="_WLI1o6HIEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz306HIEe-Mishx4UyKwQ" value="SAS_TICKET.REM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_eIz31KHIEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_eIz31aHIEe-Mishx4UyKwQ" ref="resource.md#_iWSoIqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_eIz31qHIEe-Mishx4UyKwQ" value="_WLI1pKHIEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_eIz316HIEe-Mishx4UyKwQ" value="SAS_TICKET.COD_VEN"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_eIz3t6HIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_eIz3uKHIEe-Mishx4UyKwQ" ref="resource.md#_OOP4EJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=Ticket_20240801?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_eIz32KHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_eIz32aHIEe-Mishx4UyKwQ" ref="resource.md#_iTGxMKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_TICKET?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore" id="_eIz36aHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.sourceRef" id="_eIz36qHIEe-Mishx4UyKwQ" ref="resource.md#_eIz35qHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.targetRef" id="_eIz366HIEe-Mishx4UyKwQ" ref="resource.md#_eIz3xaHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_eIz38qHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_eIz386HIEe-Mishx4UyKwQ" ref="resource.md#_eIz376HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_eIz39KHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3l6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_eIz3-KHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_eIz3-aHIEe-Mishx4UyKwQ" ref="resource.md#_eIz39aHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_eIz3-qHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3N6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_eIz3_qHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_eIz3_6HIEe-Mishx4UyKwQ" ref="resource.md#_eIz3-6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_eIz4AKHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3s6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_eIz4AaHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_eIz4AqHIEe-Mishx4UyKwQ" ref="resource.md#_eIz376HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_eIz4A6HIEe-Mishx4UyKwQ" ref="resource.md#_eIz3zKHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_eIz4BKHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_eIz4BaHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3-6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_eIz4BqHIEe-Mishx4UyKwQ" ref="resource.md#_eIz31KHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_eIz4B6HIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_eIz4CKHIEe-Mishx4UyKwQ" ref="resource.md#_eIz39aHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_eIz4CaHIEe-Mishx4UyKwQ" ref="resource.md#_eIz30KHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_eIz3uaHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_eIz3uqHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3LKHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_eIz3u6HIEe-Mishx4UyKwQ" ref="resource.md#_eIz3t6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_eIz32qHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_eIz326HIEe-Mishx4UyKwQ" ref="resource.md#_eIz3xaHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_eIz33KHIEe-Mishx4UyKwQ" ref="resource.md#_eIz32KHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_eIz3v6HIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_eIz3wKHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3vKHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_eIz3waHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3t6HIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_eIz3wqHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_eIz3w6HIEe-Mishx4UyKwQ" ref="resource.md#_eIz3KaHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_eIz3xKHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3LKHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_eIz34KHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_eIz34aHIEe-Mishx4UyKwQ" ref="resource.md#_eIz33aHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_eIz34qHIEe-Mishx4UyKwQ" ref="resource.md#_eIz32KHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_eIz346HIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_eIz35KHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3KaHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_eIz35aHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3xaHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_eIz37KHIEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_eIz37aHIEe-Mishx4UyKwQ" ref="resource.md#_eIz3KaHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_eIz37qHIEe-Mishx4UyKwQ" ref="resource.md#_eIz35qHIEe-Mishx4UyKwQ?fileId=_yxluIKHHEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
</md:node>