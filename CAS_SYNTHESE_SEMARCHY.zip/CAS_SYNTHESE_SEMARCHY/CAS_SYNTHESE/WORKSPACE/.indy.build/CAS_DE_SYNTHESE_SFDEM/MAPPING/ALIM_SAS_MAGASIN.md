<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_C3YfQKHDEe-Mishx4UyKwQ-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_TuntUbAVEe-mg8uIL6AcVA">
    <attribute defType="com.stambia.flow.altId.origin" id="_TuntUrAVEe-mg8uIL6AcVA" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_TuntU7AVEe-mg8uIL6AcVA" value="_C3YfQKHDEe-Mishx4UyKwQ"/>
  </node>
  <node defType="com.stambia.flow.step" id="a3112341-320c-3dd3-a7bb-752577a4216d" name="I1_SAS_MAGASIN">
    <attribute defType="com.stambia.flow.step.number" id="_TupigbAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_TupigrAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_Tupig7AVEe-mg8uIL6AcVA" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_TupihLAVEe-mg8uIL6AcVA" name="TICKETS">
      <attribute defType="com.stambia.flow.source.target" id="_TupihbAVEe-mg8uIL6AcVA" value="$MD_17"/>
    </node>
    <node defType="com.stambia.flow.field" id="_TupihrAVEe-mg8uIL6AcVA" name="LIB_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_Tupih7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupiiLAVEe-mg8uIL6AcVA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupiibAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupiirAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_Tupii7AVEe-mg8uIL6AcVA">
        <values>$MD_19</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupijLAVEe-mg8uIL6AcVA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupijbAVEe-mg8uIL6AcVA" ref="resource.md#_RUwYQKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupijrAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_19}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Tupij7AVEe-mg8uIL6AcVA" value="LIB_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupikLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupikbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupikrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_Tupik7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupilLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_19}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupilbAVEe-mg8uIL6AcVA" name="ADR1">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupilrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_Tupil7AVEe-mg8uIL6AcVA" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupimLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupimbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupimrAVEe-mg8uIL6AcVA">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_Tupim7AVEe-mg8uIL6AcVA" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupinLAVEe-mg8uIL6AcVA" ref="resource.md#_RUwYRqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupinbAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_26}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupinrAVEe-mg8uIL6AcVA" value="ADR1"/>
      <attribute defType="com.stambia.flow.field.version" id="_Tupin7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupioLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupiobAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupiorAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_26}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_Tupio7AVEe-mg8uIL6AcVA" name="ADR2">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupipLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupipbAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupiprAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Tupip7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupiqLAVEe-mg8uIL6AcVA">
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupiqbAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupiqrAVEe-mg8uIL6AcVA" ref="resource.md#_RUw_UKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_Tupiq7AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_31}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupirLAVEe-mg8uIL6AcVA" value="ADR2"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupirbAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupirrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Tupir7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupisLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_31}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupisbAVEe-mg8uIL6AcVA" name="ADR3">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupisrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_Tupis7AVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupitLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupitbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupitrAVEe-mg8uIL6AcVA">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_Tupit7AVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupiuLAVEe-mg8uIL6AcVA" ref="resource.md#_RUw_VqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupiubAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_27}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupiurAVEe-mg8uIL6AcVA" value="ADR3"/>
      <attribute defType="com.stambia.flow.field.version" id="_Tupiu7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupivLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupivbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupivrAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_27}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_Tupiv7AVEe-mg8uIL6AcVA" name="VIL_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupiwLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupiwbAVEe-mg8uIL6AcVA" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupiwrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Tupiw7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupixLAVEe-mg8uIL6AcVA">
        <values>$MD_21</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupixbAVEe-mg8uIL6AcVA" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupixrAVEe-mg8uIL6AcVA" ref="resource.md#_RUxmYKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_Tupix7AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_21}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupiyLAVEe-mg8uIL6AcVA" value="VIL_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupiybAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupiyrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Tupiy7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupizLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_21}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupizbAVEe-mg8uIL6AcVA" name="DEP_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupizrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_Tupiz7AVEe-mg8uIL6AcVA" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_Tupi0LAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Tupi0bAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_Tupi0rAVEe-mg8uIL6AcVA">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_Tupi07AVEe-mg8uIL6AcVA" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_Tupi1LAVEe-mg8uIL6AcVA" ref="resource.md#_RUyNcKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_Tupi1bAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_18}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Tupi1rAVEe-mg8uIL6AcVA" value="DEP_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_Tupi17AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Tupi2LAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Tupi2bAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Tupi2rAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_18}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_Tupi27AVEe-mg8uIL6AcVA" name="REG_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_Tupi3LAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_Tupi3bAVEe-mg8uIL6AcVA" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_Tupi3rAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Tupi37AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_Tupi4LAVEe-mg8uIL6AcVA">
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_Tupi4bAVEe-mg8uIL6AcVA" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_Tupi4rAVEe-mg8uIL6AcVA" ref="resource.md#_RUy0gKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_Tupi47AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_22}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Tupi5LAVEe-mg8uIL6AcVA" value="REG_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_Tupi5bAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Tupi5rAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Tupi57AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Tupi6LAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_Tupi6bAVEe-mg8uIL6AcVA" name="LIB_PAY">
      <attribute defType="com.stambia.flow.field.aggregate" id="_Tupi6rAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_Tupi67AVEe-mg8uIL6AcVA" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_Tupi7LAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Tupi7bAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_Tupi7rAVEe-mg8uIL6AcVA">
        <values>$MD_32</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_Tupi77AVEe-mg8uIL6AcVA" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_Tupi8LAVEe-mg8uIL6AcVA" ref="resource.md#_RUy0hqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_Tupi8bAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_32}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Tupi8rAVEe-mg8uIL6AcVA" value="LIB_PAY"/>
      <attribute defType="com.stambia.flow.field.version" id="_Tupi87AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Tupi9LAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Tupi9bAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Tupi9rAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_32}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_Tupi97AVEe-mg8uIL6AcVA" name="LNG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_Tupi-LAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_Tupi-bAVEe-mg8uIL6AcVA" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_Tupi-rAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Tupi-7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_Tupi_LAVEe-mg8uIL6AcVA">
        <values>$MD_25</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_Tupi_bAVEe-mg8uIL6AcVA" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_Tupi_rAVEe-mg8uIL6AcVA" ref="resource.md#_RU0CoKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_Tupi_7AVEe-mg8uIL6AcVA" value="'nullif(TICKETS.%{MD_25}%,0)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjALAVEe-mg8uIL6AcVA" value="LNG"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjAbAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjArAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjA7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjBLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_25}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjBbAVEe-mg8uIL6AcVA" name="LAT">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjBrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjB7AVEe-mg8uIL6AcVA" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjCLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjCbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjCrAVEe-mg8uIL6AcVA">
        <values>$MD_20</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjC7AVEe-mg8uIL6AcVA" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjDLAVEe-mg8uIL6AcVA" ref="resource.md#_RU0psKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjDbAVEe-mg8uIL6AcVA" value="'nullif(TICKETS.%{MD_20}%,0)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjDrAVEe-mg8uIL6AcVA" value="LAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjD7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjELAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjEbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjErAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_20}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjE7AVEe-mg8uIL6AcVA" name="TEL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjFLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjFbAVEe-mg8uIL6AcVA" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjFrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjF7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjGLAVEe-mg8uIL6AcVA">
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjGbAVEe-mg8uIL6AcVA" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjGrAVEe-mg8uIL6AcVA" ref="resource.md#_RU130KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjG7AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_33}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjHLAVEe-mg8uIL6AcVA" value="TEL"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjHbAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjHrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjH7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjILAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_33}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjIbAVEe-mg8uIL6AcVA" name="EMAIL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjIrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjI7AVEe-mg8uIL6AcVA" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjJLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjJbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjJrAVEe-mg8uIL6AcVA">
        <values>$MD_29</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjJ7AVEe-mg8uIL6AcVA" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjKLAVEe-mg8uIL6AcVA" ref="resource.md#_RU131qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjKbAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_29}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjKrAVEe-mg8uIL6AcVA" value="EMAIL"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjK7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjLLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjLbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjLrAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_29}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjL7AVEe-mg8uIL6AcVA" name="DAT_OUV">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjMLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjMbAVEe-mg8uIL6AcVA" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjMrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjM7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjNLAVEe-mg8uIL6AcVA">
        <values>$MD_28</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjNbAVEe-mg8uIL6AcVA" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjNrAVEe-mg8uIL6AcVA" ref="resource.md#_RU2e4KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjN7AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_28}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjOLAVEe-mg8uIL6AcVA" value="DAT_OUV"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjObAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjOrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjO7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjPLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_28}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjPbAVEe-mg8uIL6AcVA" name="DAT_FRM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjPrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjP7AVEe-mg8uIL6AcVA" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjQLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjQbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjQrAVEe-mg8uIL6AcVA">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjQ7AVEe-mg8uIL6AcVA" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjRLAVEe-mg8uIL6AcVA" ref="resource.md#_RU2e5qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_FRM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjRbAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_23}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjRrAVEe-mg8uIL6AcVA" value="DAT_FRM"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjR7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjSLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjSbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjSrAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_23}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjS7AVEe-mg8uIL6AcVA" name="SCHEDULE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjTLAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjTbAVEe-mg8uIL6AcVA" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjTrAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjT7AVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjULAVEe-mg8uIL6AcVA">
        <values>$MD_30</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjUbAVEe-mg8uIL6AcVA" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjUrAVEe-mg8uIL6AcVA" ref="resource.md#_RU3F8KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjU7AVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_30}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjVLAVEe-mg8uIL6AcVA" value="SCHEDULE"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjVbAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjVrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjV7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjWLAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_30}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_TupjWbAVEe-mg8uIL6AcVA" name="LIB_ENS">
      <attribute defType="com.stambia.flow.field.aggregate" id="_TupjWrAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_TupjW7AVEe-mg8uIL6AcVA" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.location" id="_TupjXLAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_TupjXbAVEe-mg8uIL6AcVA">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_TupjXrAVEe-mg8uIL6AcVA">
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_TupjX7AVEe-mg8uIL6AcVA" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_TupjYLAVEe-mg8uIL6AcVA" ref="resource.md#_RU3F9qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_TupjYbAVEe-mg8uIL6AcVA" value="'TICKETS.%{MD_24}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_TupjYrAVEe-mg8uIL6AcVA" value="LIB_ENS"/>
      <attribute defType="com.stambia.flow.field.version" id="_TupjY7AVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_TupjZLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_TupjZbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_TupjZrAVEe-mg8uIL6AcVA">
        <values>TICKETS.%{MD_24}%</values>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="331f25ee-6b1e-3445-adbb-adbb14fac008" name="R1_SAS_MAGASIN">
    <attribute defType="com.stambia.flow.step.number" id="_TupjaLAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_TupjabAVEe-mg8uIL6AcVA">
      <values>I1_SAS_MAGASIN</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_TupjarAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_Tupja7AVEe-mg8uIL6AcVA" value="Check"/>
  </node>
  <metaDataLink name="MD_7" target="resource.md#_RUy0gKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
  <metaDataLink name="MD_24" target="resource.md#_Cj54QKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
  <metaDataLink name="MD_26" target="resource.md#_Cj_X1qcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
  <metaDataLink name="MD_18" target="resource.md#_CkB0EKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
  <metaDataLink name="MD_27" target="resource.md#_CkAl8KcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
  <metaDataLink name="MD_33" target="resource.md#_CkCbIKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
  <metaDataLink name="MD_4" target="resource.md#_RUw_VqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
  <metaDataLink name="MD_17" target="resource.md#_B-yZAKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TICKETS?"/>
  <metaDataLink name="MD_5" target="resource.md#_RUxmYKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
  <metaDataLink name="MD_1" target="resource.md#_RUwYQKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_23" target="resource.md#_CkEQVKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_FRM?"/>
  <metaDataLink name="MD_15" target="resource.md#_RU3F8KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
  <metaDataLink name="MD_10" target="resource.md#_RU0psKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
  <metaDataLink name="MD_13" target="resource.md#_RU2e4KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
  <metaDataLink name="MD_20" target="resource.md#_CkDpQKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
  <metaDataLink name="MD_12" target="resource.md#_RU131qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
  <metaDataLink name="MD_31" target="resource.md#_Cj_-4KcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
  <metaDataLink name="MD_19" target="resource.md#_Cj6fUKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_11" target="resource.md#_RU130KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
  <metaDataLink name="MD_30" target="resource.md#_CkE3YKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
  <metaDataLink name="MD_16" target="resource.md#_RU3F9qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
  <metaDataLink name="MD_9" target="resource.md#_RU0CoKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
  <metaDataLink name="MD_25" target="resource.md#_CkDCNqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
  <metaDataLink name="MD_0" target="resource.md#_RLOBwKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MAGASIN?"/>
  <metaDataLink name="MD_6" target="resource.md#_RUyNcKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
  <metaDataLink name="MD_8" target="resource.md#_RUy0hqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
  <metaDataLink name="MD_3" target="resource.md#_RUw_UKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
  <metaDataLink name="MD_22" target="resource.md#_CkB0FqcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
  <metaDataLink name="MD_29" target="resource.md#_CkDCMKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
  <metaDataLink name="MD_14" target="resource.md#_RU2e5qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_FRM?"/>
  <metaDataLink name="MD_28" target="resource.md#_CkDpR6cWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
  <metaDataLink name="MD_21" target="resource.md#_CkAl9qcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
  <metaDataLink name="MD_32" target="resource.md#_Cj_X0KcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
  <metaDataLink name="MD_2" target="resource.md#_RUwYRqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
</md:node>