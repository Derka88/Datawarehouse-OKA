<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_zqgscKHCEe-Mishx4UyKwQ-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_eh5psbAVEe-mg8uIL6AcVA">
    <attribute defType="com.stambia.flow.altId.origin" id="_eh5psrAVEe-mg8uIL6AcVA" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_eh5ps7AVEe-mg8uIL6AcVA" value="_zqgscKHCEe-Mishx4UyKwQ"/>
  </node>
  <node defType="com.stambia.flow.step" id="1f35a363-6d2c-33ed-8dd7-3cb95be9673f" name="I1_SAS_ARTICLE">
    <attribute defType="com.stambia.flow.step.number" id="_eh630bAVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_eh630rAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_eh6307AVEe-mg8uIL6AcVA" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_eh631LAVEe-mg8uIL6AcVA" name="ARTICLES">
      <attribute defType="com.stambia.flow.source.target" id="_eh631bAVEe-mg8uIL6AcVA" value="$MD_13"/>
    </node>
    <node defType="com.stambia.flow.field" id="_eh631rAVEe-mg8uIL6AcVA" name="COD_ART">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh6317AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh632LAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh632bAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh632rAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh6327AVEe-mg8uIL6AcVA">
        <values>$MD_21</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh633LAVEe-mg8uIL6AcVA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh633bAVEe-mg8uIL6AcVA" ref="resource.md#_iPn_YKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh633rAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_21}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh6337AVEe-mg8uIL6AcVA" value="COD_ART"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh634LAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh634bAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh634rAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh6347AVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_21}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh635LAVEe-mg8uIL6AcVA" name="LIB_PRD">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh635bAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh635rAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh6357AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh636LAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh636bAVEe-mg8uIL6AcVA">
        <values>$MD_19</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh636rAVEe-mg8uIL6AcVA" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh6367AVEe-mg8uIL6AcVA" ref="resource.md#_iPn_ZqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh637LAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_19}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh637bAVEe-mg8uIL6AcVA" value="LIB_PRD"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh637rAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh6377AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh638LAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh638bAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_19}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh638rAVEe-mg8uIL6AcVA" name="LIB_COL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh6387AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh639LAVEe-mg8uIL6AcVA" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh639bAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh639rAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh6397AVEe-mg8uIL6AcVA">
        <values>$MD_14</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh63-LAVEe-mg8uIL6AcVA" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh63-bAVEe-mg8uIL6AcVA" ref="resource.md#_iPn_bKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh63-rAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_14}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh63-7AVEe-mg8uIL6AcVA" value="LIB_COL"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh63_LAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh63_bAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh63_rAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh63_7AVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_14}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64ALAVEe-mg8uIL6AcVA" name="LIB_TAI">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64AbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64ArAVEe-mg8uIL6AcVA" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64A7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64BLAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64BbAVEe-mg8uIL6AcVA">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64BrAVEe-mg8uIL6AcVA" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64B7AVEe-mg8uIL6AcVA" ref="resource.md#_iPn_cqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64CLAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_23}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64CbAVEe-mg8uIL6AcVA" value="LIB_TAI"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64CrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64C7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64DLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64DbAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_23}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64DrAVEe-mg8uIL6AcVA" name="FAM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64D7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64ELAVEe-mg8uIL6AcVA" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64EbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64ErAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64E7AVEe-mg8uIL6AcVA">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64FLAVEe-mg8uIL6AcVA" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64FbAVEe-mg8uIL6AcVA" ref="resource.md#_iPn_eKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64FrAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_18}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64F7AVEe-mg8uIL6AcVA" value="FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64GLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64GbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64GrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64G7AVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_18}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64HLAVEe-mg8uIL6AcVA" name="SS_FAM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64HbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64HrAVEe-mg8uIL6AcVA" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64H7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64ILAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64IbAVEe-mg8uIL6AcVA">
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64IrAVEe-mg8uIL6AcVA" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64I7AVEe-mg8uIL6AcVA" ref="resource.md#_iPn_fqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64JLAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_22}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64JbAVEe-mg8uIL6AcVA" value="SS_FAM"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64JrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64J7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64KLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64KbAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64KrAVEe-mg8uIL6AcVA" name="PRX_VEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64K7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64LLAVEe-mg8uIL6AcVA" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64LbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64LrAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64L7AVEe-mg8uIL6AcVA">
        <values>$MD_17</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64MLAVEe-mg8uIL6AcVA" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64MbAVEe-mg8uIL6AcVA" ref="resource.md#_iPomcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64MrAVEe-mg8uIL6AcVA" value="'nvl(ARTICLES.%{MD_17}%,0)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64M7AVEe-mg8uIL6AcVA" value="PRX_VEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64NLAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64NbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64NrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64N7AVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_17}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64OLAVEe-mg8uIL6AcVA" name="LIB_GEN">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64ObAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64OrAVEe-mg8uIL6AcVA" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64O7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64PLAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64PbAVEe-mg8uIL6AcVA">
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64PrAVEe-mg8uIL6AcVA" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64P7AVEe-mg8uIL6AcVA" ref="resource.md#_iPomdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64QLAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_16}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64QbAVEe-mg8uIL6AcVA" value="LIB_GEN"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64QrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64Q7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64RLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64RbAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_16}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64RrAVEe-mg8uIL6AcVA" name="CIB_TRN_AGE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64R7AVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64SLAVEe-mg8uIL6AcVA" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64SbAVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64SrAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64S7AVEe-mg8uIL6AcVA">
        <values>$MD_20</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64TLAVEe-mg8uIL6AcVA" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64TbAVEe-mg8uIL6AcVA" ref="resource.md#_iPomfKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64TrAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_20}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64T7AVEe-mg8uIL6AcVA" value="CIB_TRN_AGE"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64ULAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64UbAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64UrAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64U7AVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_20}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_eh64VLAVEe-mg8uIL6AcVA" name="LIB_CAT">
      <attribute defType="com.stambia.flow.field.aggregate" id="_eh64VbAVEe-mg8uIL6AcVA" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_eh64VrAVEe-mg8uIL6AcVA" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_eh64V7AVEe-mg8uIL6AcVA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_eh64WLAVEe-mg8uIL6AcVA">
        <values>ARTICLES</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_eh64WbAVEe-mg8uIL6AcVA">
        <values>$MD_15</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_eh64WrAVEe-mg8uIL6AcVA" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_eh64W7AVEe-mg8uIL6AcVA" ref="resource.md#_iPomgqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_eh64XLAVEe-mg8uIL6AcVA" value="'ARTICLES.%{MD_15}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_eh64XbAVEe-mg8uIL6AcVA" value="LIB_CAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_eh64XrAVEe-mg8uIL6AcVA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_eh64X7AVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_eh64YLAVEe-mg8uIL6AcVA" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_eh64YbAVEe-mg8uIL6AcVA">
        <values>ARTICLES.%{MD_15}%</values>
      </attribute>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="107789aa-a798-38b5-96f7-4b11b7c043ad" name="R1_SAS_ARTICLE">
    <attribute defType="com.stambia.flow.step.number" id="_eh64Y7AVEe-mg8uIL6AcVA" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_eh64ZLAVEe-mg8uIL6AcVA">
      <values>I1_SAS_ARTICLE</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_eh64ZbAVEe-mg8uIL6AcVA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_eh64ZrAVEe-mg8uIL6AcVA" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_eh64Z7AVEe-mg8uIL6AcVA" name="PRX_VEN_CHIFFRE">
      <attribute defType="com.stambia.flow.constraint.type" id="_eh64aLAVEe-mg8uIL6AcVA" value="ck"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_eh64abAVEe-mg8uIL6AcVA" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_eh64arAVEe-mg8uIL6AcVA" name="COD_ART_CHIFFRE">
      <attribute defType="com.stambia.flow.constraint.type" id="_eh64a7AVEe-mg8uIL6AcVA" value="ck"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_eh64bLAVEe-mg8uIL6AcVA" value="$MD_2"/>
    </node>
  </node>
  <metaDataLink name="MD_19" target="resource.md#_hGZuEKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
  <metaDataLink name="MD_4" target="resource.md#_iPn_ZqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PRD?"/>
  <metaDataLink name="MD_9" target="resource.md#_iPomcKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
  <metaDataLink name="MD_13" target="resource.md#_gry1sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ARTICLES?"/>
  <metaDataLink name="MD_21" target="resource.md#_hGYf8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_3" target="resource.md#_iPn_YKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART?"/>
  <metaDataLink name="MD_6" target="resource.md#_iPn_cqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
  <metaDataLink name="MD_5" target="resource.md#_iPn_bKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
  <metaDataLink name="MD_23" target="resource.md#_hGbjQKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_TAI?"/>
  <metaDataLink name="MD_8" target="resource.md#_iPn_fqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
  <metaDataLink name="MD_17" target="resource.md#_hGfNoKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN?"/>
  <metaDataLink name="MD_0" target="resource.md#_iMSXgKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_ARTICLE?"/>
  <metaDataLink name="MD_11" target="resource.md#_iPomfKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
  <metaDataLink name="MD_10" target="resource.md#_iPomdqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
  <metaDataLink name="MD_7" target="resource.md#_iPn_eKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
  <metaDataLink name="MD_14" target="resource.md#_hGa8MKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_COL?"/>
  <metaDataLink name="MD_18" target="resource.md#_hGcxYKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=FAM?"/>
  <metaDataLink name="MD_22" target="resource.md#_hGd_gKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SS_FAM?"/>
  <metaDataLink name="MD_2" target="resource.md#_TchNcacREe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_CHIFFRE?"/>
  <metaDataLink name="MD_1" target="resource.md#_zUTaMacYEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PRX_VEN_CHIFFRE?"/>
  <metaDataLink name="MD_20" target="resource.md#_hGgbwKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CIB_TRN_AGE?"/>
  <metaDataLink name="MD_12" target="resource.md#_iPomgqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
  <metaDataLink name="MD_16" target="resource.md#_hGf0sKcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_GEN?"/>
  <metaDataLink name="MD_15" target="resource.md#_hGiQ8KcSEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_CAT?"/>
</md:node>