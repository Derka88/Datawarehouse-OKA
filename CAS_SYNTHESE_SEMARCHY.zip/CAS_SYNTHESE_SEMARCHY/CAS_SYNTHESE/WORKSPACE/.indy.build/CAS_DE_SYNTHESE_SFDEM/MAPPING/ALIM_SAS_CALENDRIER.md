<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_pGKxwKN0Ee-J7t2XLcBYpg-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_6vCLsafvEe-gyuxKNABDpQ">
    <attribute defType="com.stambia.flow.altId.origin" id="_6vCywKfvEe-gyuxKNABDpQ" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_6vF2EKfvEe-gyuxKNABDpQ" value="_pGKxwKN0Ee-J7t2XLcBYpg"/>
  </node>
  <node defType="com.stambia.flow.step" id="9b1d9259-e1b5-314f-9e23-de09b456a27c" name="I1_SAS_CALENDRIER">
    <attribute defType="com.stambia.flow.step.number" id="_6v0O0afvEe-gyuxKNABDpQ" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_6v0O0qfvEe-gyuxKNABDpQ" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_6v0O06fvEe-gyuxKNABDpQ" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_6v0O1KfvEe-gyuxKNABDpQ" name="TICKETS">
      <attribute defType="com.stambia.flow.source.target" id="_6v0O1afvEe-gyuxKNABDpQ" value="$MD_8"/>
    </node>
    <node defType="com.stambia.flow.field" id="_6v014KfvEe-gyuxKNABDpQ" name="COD_CAL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v014afvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v014qfvEe-gyuxKNABDpQ" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v0146fvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1c8KfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1c8afvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1c8qfvEe-gyuxKNABDpQ" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1c86fvEe-gyuxKNABDpQ" ref="resource.md#_iTBRoKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1c9KfvEe-gyuxKNABDpQ" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''YYYYMMDD'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1c9afvEe-gyuxKNABDpQ" value="COD_CAL"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1c9qfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1c96fvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1c-KfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1c-afvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_6v1c-qfvEe-gyuxKNABDpQ" name="ANNEE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v1c-6fvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v1c_KfvEe-gyuxKNABDpQ" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v1c_afvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1c_qfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1c_6fvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1dAKfvEe-gyuxKNABDpQ" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1dAafvEe-gyuxKNABDpQ" ref="resource.md#_iTB4sKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ANNEE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1dAqfvEe-gyuxKNABDpQ" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''YYYY'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1dA6fvEe-gyuxKNABDpQ" value="ANNEE"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1dBKfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1dBafvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1dBqfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1dB6fvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_6v1dCKfvEe-gyuxKNABDpQ" name="MOIS">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v1dCafvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v1dCqfvEe-gyuxKNABDpQ" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v1dC6fvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1dDKfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1dDafvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1dDqfvEe-gyuxKNABDpQ" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1dD6fvEe-gyuxKNABDpQ" ref="resource.md#_iTB4tqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MOIS?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1dEKfvEe-gyuxKNABDpQ" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''MM'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1dEafvEe-gyuxKNABDpQ" value="MOIS"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1dEqfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1dE6fvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1dFKfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1dFafvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_6v1dFqfvEe-gyuxKNABDpQ" name="NUM_JOUR">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v1dF6fvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v1dGKfvEe-gyuxKNABDpQ" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v1dGafvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1dGqfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1dG6fvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1dHKfvEe-gyuxKNABDpQ" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1dHafvEe-gyuxKNABDpQ" ref="resource.md#_iTB4vKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_JOUR?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1dHqfvEe-gyuxKNABDpQ" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''DD'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1dH6fvEe-gyuxKNABDpQ" value="NUM_JOUR"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1dIKfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1dIafvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1dIqfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1dI6fvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_6v1dJKfvEe-gyuxKNABDpQ" name="NOM_JOUR">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v1dJafvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v1dJqfvEe-gyuxKNABDpQ" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v1dJ6fvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1dKKfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1dKafvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1dKqfvEe-gyuxKNABDpQ" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1dK6fvEe-gyuxKNABDpQ" ref="resource.md#_iTB4wqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NOM_JOUR?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1dLKfvEe-gyuxKNABDpQ" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''DAY'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1dLafvEe-gyuxKNABDpQ" value="NOM_JOUR"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1dLqfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1dL6fvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1dMKfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1dMafvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_6v1dMqfvEe-gyuxKNABDpQ" name="TRIM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v1dM6fvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v1dNKfvEe-gyuxKNABDpQ" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v1dNafvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1dNqfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1dN6fvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1dOKfvEe-gyuxKNABDpQ" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1dOafvEe-gyuxKNABDpQ" ref="resource.md#_iTB4yKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TRIM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1dOqfvEe-gyuxKNABDpQ" value="'TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''Q'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1dO6fvEe-gyuxKNABDpQ" value="TRIM"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1dPKfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1dPafvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1dPqfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1dP6fvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_6v1dQKfvEe-gyuxKNABDpQ" name="SEMESTRE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_6v1dQafvEe-gyuxKNABDpQ" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_6v1dQqfvEe-gyuxKNABDpQ" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_6v1dQ6fvEe-gyuxKNABDpQ" value="WRK"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_6v1dRKfvEe-gyuxKNABDpQ">
        <values>TICKETS</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_6v1dRafvEe-gyuxKNABDpQ">
        <values>$MD_9</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_6v1dRqfvEe-gyuxKNABDpQ" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_6v1dR6fvEe-gyuxKNABDpQ" ref="resource.md#_iTCfwKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SEMESTRE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_6v1dSKfvEe-gyuxKNABDpQ" value="'CEIL(TO_NUMBER(TO_CHAR(TO_DATE(TICKETS.%{MD_9}%, ''DD-MM-YYYY HH24:MI:SS''), ''Q'')) / 2) AS semestre&#xA;'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_6v1dSafvEe-gyuxKNABDpQ" value="SEMESTRE"/>
      <attribute defType="com.stambia.flow.field.version" id="_6v1dSqfvEe-gyuxKNABDpQ" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_6v1dS6fvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_6v1dTKfvEe-gyuxKNABDpQ" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_6v1dTafvEe-gyuxKNABDpQ">
        <values>TICKETS.%{MD_9}%</values>
      </attribute>
    </node>
  </node>
  <metaDataLink name="MD_9" target="resource.md#_Cj7tcKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_HEU_TIC?"/>
  <metaDataLink name="MD_0" target="resource.md#_iPuGAKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_CALENDRIER?"/>
  <metaDataLink name="MD_1" target="resource.md#_iTBRoKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL?"/>
  <metaDataLink name="MD_4" target="resource.md#_iTB4vKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_JOUR?"/>
  <metaDataLink name="MD_5" target="resource.md#_iTB4wqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NOM_JOUR?"/>
  <metaDataLink name="MD_8" target="resource.md#_B-yZAKcWEe-NbvGIo9uaQg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TICKETS?"/>
  <metaDataLink name="MD_3" target="resource.md#_iTB4tqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MOIS?"/>
  <metaDataLink name="MD_6" target="resource.md#_iTB4yKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TRIM?"/>
  <metaDataLink name="MD_2" target="resource.md#_iTB4sKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ANNEE?"/>
  <metaDataLink name="MD_7" target="resource.md#_iTCfwKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SEMESTRE?"/>
</md:node>