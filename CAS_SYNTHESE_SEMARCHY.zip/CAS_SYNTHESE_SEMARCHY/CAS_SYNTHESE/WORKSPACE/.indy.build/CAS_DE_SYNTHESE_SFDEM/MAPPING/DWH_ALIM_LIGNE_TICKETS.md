<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_0SKmQKc8Ee-MsNEJBkvyXQ-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_K0XMEbJaEe-7gLO1_RM3Dg">
    <attribute defType="com.stambia.flow.altId.origin" id="_K0XMErJaEe-7gLO1_RM3Dg" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_K0XME7JaEe-7gLO1_RM3Dg" value="_0SKmQKc8Ee-MsNEJBkvyXQ"/>
  </node>
  <node defType="com.stambia.flow.step" id="9e35fdea-d0d3-3c96-acf9-169b8732a8d4" name="I1_LIGNETICKET">
    <attribute defType="com.stambia.flow.step.number" id="_K0crobJaEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_K0crorJaEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_K0cro7JaEe-7gLO1_RM3Dg" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_K0crpLJaEe-7gLO1_RM3Dg" name="SAS_LIGNETICKET">
      <attribute defType="com.stambia.flow.source.target" id="_K0crpbJaEe-7gLO1_RM3Dg" value="$MD_21"/>
    </node>
    <node defType="com.stambia.flow.field" id="_K0crprJaEe-7gLO1_RM3Dg" name="CODMAGNUMCAISSENUMTICNUMTICLIG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0crp7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0crqLJaEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0crqbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0crqrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0crq7JaEe-7gLO1_RM3Dg">
        <values>$MD_23</values>
        <values>$MD_25</values>
        <values>$MD_24</values>
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0crrLJaEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0crrbJaEe-7gLO1_RM3Dg" ref="resource.md#_BrqSkK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAISSENUMTICNUMTICLIG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0crrrJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_23}%||''_''||SAS_LIGNETICKET.%{MD_25}%||''_''||SAS_LIGNETICKET.%{MD_24}%||''_''||SAS_LIGNETICKET.%{MD_22}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0crr7JaEe-7gLO1_RM3Dg" value="CODMAGNUMCAISSENUMTICNUMTICLIG"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0crsLJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0crsbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0crsrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0crs7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_23}%</values>
        <values>SAS_LIGNETICKET.%{MD_25}%</values>
        <values>SAS_LIGNETICKET.%{MD_24}%</values>
        <values>SAS_LIGNETICKET.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0crtLJaEe-7gLO1_RM3Dg" name="CODMAGNUMCAISSENUMTIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0crtbJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0crtrJaEe-7gLO1_RM3Dg" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0crt7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0cruLJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0crubJaEe-7gLO1_RM3Dg">
        <values>$MD_23</values>
        <values>$MD_25</values>
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0crurJaEe-7gLO1_RM3Dg" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0cru7JaEe-7gLO1_RM3Dg" ref="resource.md#_BrqSlq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAISSENUMTIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0crvLJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_23}%||''_''||SAS_LIGNETICKET.%{MD_25}%||''_''||SAS_LIGNETICKET.%{MD_24}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0crvbJaEe-7gLO1_RM3Dg" value="CODMAGNUMCAISSENUMTIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0crvrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0crv7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0crwLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0crwbJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_23}%</values>
        <values>SAS_LIGNETICKET.%{MD_25}%</values>
        <values>SAS_LIGNETICKET.%{MD_24}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0crwrJaEe-7gLO1_RM3Dg" name="COD_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0crw7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0crxLJaEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0crxbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0crxrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0crx7JaEe-7gLO1_RM3Dg">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0cryLJaEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0crybJaEe-7gLO1_RM3Dg" ref="resource.md#_Brq5oK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0cryrJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_23}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0cry7JaEe-7gLO1_RM3Dg" value="COD_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0crzLJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0crzbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0crzrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_K0crz7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0cr0LJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_23}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0cr0bJaEe-7gLO1_RM3Dg" name="NUM_CAISSE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0cr0rJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0cr07JaEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0cr1LJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0cr1bJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0cr1rJaEe-7gLO1_RM3Dg">
        <values>$MD_25</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0cr17JaEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0cr2LJaEe-7gLO1_RM3Dg" ref="resource.md#_Brq5pq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_CAISSE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0cr2bJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_25}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0cr2rJaEe-7gLO1_RM3Dg" value="NUM_CAISSE"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0cr27JaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dSsLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dSsbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_K0dSsrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dSs7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_25}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dStLJaEe-7gLO1_RM3Dg" name="NUM_TIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dStbJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dStrJaEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dSt7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dSuLJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dSubJaEe-7gLO1_RM3Dg">
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dSurJaEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dSu7JaEe-7gLO1_RM3Dg" ref="resource.md#_Brq5rK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dSvLJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_24}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dSvbJaEe-7gLO1_RM3Dg" value="NUM_TIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dSvrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dSv7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dSwLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_K0dSwbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dSwrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_24}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dSw7JaEe-7gLO1_RM3Dg" name="NUM_TIC_LIG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dSxLJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dSxbJaEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dSxrJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dSx7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dSyLJaEe-7gLO1_RM3Dg">
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dSybJaEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dSyrJaEe-7gLO1_RM3Dg" ref="resource.md#_BrrgsK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dSy7JaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_22}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dSzLJaEe-7gLO1_RM3Dg" value="NUM_TIC_LIG"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dSzbJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dSzrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dSz7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_K0dS0LJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dS0bJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dS0rJaEe-7gLO1_RM3Dg" name="QTE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dS07JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dS1LJaEe-7gLO1_RM3Dg" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dS1bJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dS1rJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dS17JaEe-7gLO1_RM3Dg">
        <values>$MD_36</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dS2LJaEe-7gLO1_RM3Dg" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dS2bJaEe-7gLO1_RM3Dg" ref="resource.md#_Brrgta5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dS2rJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_36}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dS27JaEe-7gLO1_RM3Dg" value="QTE"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dS3LJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dS3bJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dS3rJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dS37JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_36}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dS4LJaEe-7gLO1_RM3Dg" name="MNT_BRU">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dS4bJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dS4rJaEe-7gLO1_RM3Dg" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dS47JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dS5LJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dS5bJaEe-7gLO1_RM3Dg">
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dS5rJaEe-7gLO1_RM3Dg" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dS57JaEe-7gLO1_RM3Dg" ref="resource.md#_Brrgu65yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dS6LJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_33}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dS6bJaEe-7gLO1_RM3Dg" value="MNT_BRU"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dS6rJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dS67JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dS7LJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dS7bJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_33}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dS7rJaEe-7gLO1_RM3Dg" name="MNT_TTC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dS77JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dS8LJaEe-7gLO1_RM3Dg" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dS8bJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dS8rJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dS87JaEe-7gLO1_RM3Dg">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dS9LJaEe-7gLO1_RM3Dg" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dS9bJaEe-7gLO1_RM3Dg" ref="resource.md#_BrsHwK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dS9rJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_27}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dS97JaEe-7gLO1_RM3Dg" value="MNT_TTC"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dS-LJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dS-bJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dS-rJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dS-7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_27}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dS_LJaEe-7gLO1_RM3Dg" name="MNT_BRU_EUR">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dS_bJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dS_rJaEe-7gLO1_RM3Dg" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dS_7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTALJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTAbJaEe-7gLO1_RM3Dg">
        <values>$MD_29</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTArJaEe-7gLO1_RM3Dg" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTA7JaEe-7gLO1_RM3Dg" ref="resource.md#_BrsHxq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU_EUR?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTBLJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_29}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTBbJaEe-7gLO1_RM3Dg" value="MNT_BRU_EUR"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTBrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTB7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTCLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTCbJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_29}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTCrJaEe-7gLO1_RM3Dg" name="MNT_TTC_EUR">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTC7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTDLJaEe-7gLO1_RM3Dg" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTDbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTDrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTD7JaEe-7gLO1_RM3Dg">
        <values>$MD_30</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTELJaEe-7gLO1_RM3Dg" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTEbJaEe-7gLO1_RM3Dg" ref="resource.md#_BrsHzK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC_EUR?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTErJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_30}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTE7JaEe-7gLO1_RM3Dg" value="MNT_TTC_EUR"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTFLJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTFbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTFrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTF7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_30}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTGLJaEe-7gLO1_RM3Dg" name="REM_TIC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTGbJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTGrJaEe-7gLO1_RM3Dg" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTG7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTHLJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTHbJaEe-7gLO1_RM3Dg">
        <values>$MD_32</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTHrJaEe-7gLO1_RM3Dg" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTH7JaEe-7gLO1_RM3Dg" ref="resource.md#_BrsH0q5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTILJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_32}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTIbJaEe-7gLO1_RM3Dg" value="REM_TIC"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTIrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTI7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTJLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTJbJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_32}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTJrJaEe-7gLO1_RM3Dg" name="COD_MAG_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTJ7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTKLJaEe-7gLO1_RM3Dg" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTKbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTKrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTK7JaEe-7gLO1_RM3Dg">
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTLLJaEe-7gLO1_RM3Dg" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTLbJaEe-7gLO1_RM3Dg" ref="resource.md#_Brsu0K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTLrJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_31}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTL7JaEe-7gLO1_RM3Dg" value="COD_MAG_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTMLJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTMbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTMrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTM7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_31}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTNLJaEe-7gLO1_RM3Dg" name="COD_ART_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTNbJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTNrJaEe-7gLO1_RM3Dg" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTN7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTOLJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTObJaEe-7gLO1_RM3Dg">
        <values>$MD_34</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTOrJaEe-7gLO1_RM3Dg" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTO7JaEe-7gLO1_RM3Dg" ref="resource.md#_Brsu1q5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTPLJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_34}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTPbJaEe-7gLO1_RM3Dg" value="COD_ART_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTPrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTP7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTQLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTQbJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_34}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTQrJaEe-7gLO1_RM3Dg" name="COD_MRQ_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTQ7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTRLJaEe-7gLO1_RM3Dg" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTRbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTRrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTR7JaEe-7gLO1_RM3Dg">
        <values>$MD_35</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTSLJaEe-7gLO1_RM3Dg" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTSbJaEe-7gLO1_RM3Dg" ref="resource.md#_BrtV4K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTSrJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_35}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTS7JaEe-7gLO1_RM3Dg" value="COD_MRQ_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTTLJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTTbJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTTrJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTT7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_35}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTULJaEe-7gLO1_RM3Dg" name="COD_CAL_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTUbJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTUrJaEe-7gLO1_RM3Dg" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTU7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTVLJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTVbJaEe-7gLO1_RM3Dg">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTVrJaEe-7gLO1_RM3Dg" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTV7JaEe-7gLO1_RM3Dg" ref="resource.md#_BrtV5q5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTWLJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_26}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTWbJaEe-7gLO1_RM3Dg" value="COD_CAL_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTWrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTW7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTXLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTXbJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_26}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTXrJaEe-7gLO1_RM3Dg" name="COD_ENS_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTX7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTYLJaEe-7gLO1_RM3Dg" value="$MD_18"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTYbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTYrJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTY7JaEe-7gLO1_RM3Dg">
        <values>$MD_28</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTZLJaEe-7gLO1_RM3Dg" value="$MD_18"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTZbJaEe-7gLO1_RM3Dg" ref="resource.md#_Brt89K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTZrJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_28}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTZ7JaEe-7gLO1_RM3Dg" value="COD_ENS_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTaLJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTabJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTarJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTa7JaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_28}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTbLJaEe-7gLO1_RM3Dg" name="NUM_TIC_FK">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTbbJaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTbrJaEe-7gLO1_RM3Dg" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTb7JaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_K0dTcLJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_K0dTcbJaEe-7gLO1_RM3Dg">
        <values>$MD_37</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTcrJaEe-7gLO1_RM3Dg" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTc7JaEe-7gLO1_RM3Dg" ref="resource.md#_BrukAK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_FK?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTdLJaEe-7gLO1_RM3Dg" value="'SAS_LIGNETICKET.%{MD_37}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTdbJaEe-7gLO1_RM3Dg" value="NUM_TIC_FK"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTdrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTd7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dTeLJaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_K0dTebJaEe-7gLO1_RM3Dg">
        <values>SAS_LIGNETICKET.%{MD_37}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_K0dTerJaEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_K0dTe7JaEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_K0dTfLJaEe-7gLO1_RM3Dg" value="$MD_20"/>
      <attribute defType="com.stambia.flow.field.location" id="_K0dTfbJaEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.target" id="_K0dTfrJaEe-7gLO1_RM3Dg" value="$MD_20"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_K0dTf7JaEe-7gLO1_RM3Dg" ref="resource.md#_UixpkLJDEe-7gLO1_RM3Dg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_K0dTgLJaEe-7gLO1_RM3Dg" value="'TO_CHAR(SYSDATE, ''YYYYMMDDHH24MISS'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_K0dTgbJaEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
      <attribute defType="com.stambia.flow.field.version" id="_K0dTgrJaEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_K0dTg7JaEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_K0dThLJaEe-7gLO1_RM3Dg" value="true"/>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="50a4f53e-56ce-30f0-91eb-9e93fe1396cf" name="R1_LIGNETICKET">
    <attribute defType="com.stambia.flow.step.number" id="_K0d5wbJaEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_K0d5wrJaEe-7gLO1_RM3Dg">
      <values>I1_LIGNETICKET</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_K0d5w7JaEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_K0d5xLJaEe-7gLO1_RM3Dg" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_K0d5xbJaEe-7gLO1_RM3Dg" name="PK_LIGNETICKET">
      <attribute defType="com.stambia.flow.constraint.type" id="_K0d5xrJaEe-7gLO1_RM3Dg" value="pk"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_K0d5x7JaEe-7gLO1_RM3Dg" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_K0d5yLJaEe-7gLO1_RM3Dg" name="NN_NUM_TIC_LIG">
      <attribute defType="com.stambia.flow.constraint.type" id="_K0d5ybJaEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_K0d5yrJaEe-7gLO1_RM3Dg" value="$MD_2"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_K0d5y7JaEe-7gLO1_RM3Dg" name="NN_COD_MAG">
      <attribute defType="com.stambia.flow.constraint.type" id="_K0d5zLJaEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_K0d5zbJaEe-7gLO1_RM3Dg" value="$MD_3"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_K0d5zrJaEe-7gLO1_RM3Dg" name="NN_NUM_CAISSE">
      <attribute defType="com.stambia.flow.constraint.type" id="_K0d5z7JaEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_K0d50LJaEe-7gLO1_RM3Dg" value="$MD_4"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_K0d50bJaEe-7gLO1_RM3Dg" name="NN_NUM_TIC">
      <attribute defType="com.stambia.flow.constraint.type" id="_K0d50rJaEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_K0d507JaEe-7gLO1_RM3Dg" value="$MD_5"/>
    </node>
  </node>
  <metaDataLink name="MD_29" target="resource.md#_BdbpXK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU_EUR?"/>
  <metaDataLink name="MD_11" target="resource.md#_BrsHxq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU_EUR?"/>
  <metaDataLink name="MD_4" target="resource.md#_Brq5pq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_CAISSE?"/>
  <metaDataLink name="MD_23" target="resource.md#_BdZ0IK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
  <metaDataLink name="MD_31" target="resource.md#_Bdc3cK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_FK?"/>
  <metaDataLink name="MD_10" target="resource.md#_BrsHwK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
  <metaDataLink name="MD_14" target="resource.md#_Brsu0K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG_FK?"/>
  <metaDataLink name="MD_24" target="resource.md#_BdabNq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
  <metaDataLink name="MD_12" target="resource.md#_BrsHzK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC_EUR?"/>
  <metaDataLink name="MD_1" target="resource.md#_Br3t8K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PK_LIGNETICKET?"/>
  <metaDataLink name="MD_17" target="resource.md#_BrtV5q5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL_FK?"/>
  <metaDataLink name="MD_19" target="resource.md#_BrukAK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_FK?"/>
  <metaDataLink name="MD_3" target="resource.md#_Brq5oK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
  <metaDataLink name="MD_21" target="resource.md#_BExRsK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_LIGNETICKET?"/>
  <metaDataLink name="MD_15" target="resource.md#_Brsu1q5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_FK?"/>
  <metaDataLink name="MD_9" target="resource.md#_Brrgu65yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
  <metaDataLink name="MD_26" target="resource.md#_Bddehq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_CAL_FK?"/>
  <metaDataLink name="MD_33" target="resource.md#_BdbpUK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_BRU?"/>
  <metaDataLink name="MD_18" target="resource.md#_Brt89K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS_FK?"/>
  <metaDataLink name="MD_20" target="resource.md#_UixpkLJDEe-7gLO1_RM3Dg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
  <metaDataLink name="MD_27" target="resource.md#_BdbpVq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC?"/>
  <metaDataLink name="MD_8" target="resource.md#_Brrgta5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
  <metaDataLink name="MD_32" target="resource.md#_BdcQZq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
  <metaDataLink name="MD_0" target="resource.md#_BdukQK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIGNETICKET?"/>
  <metaDataLink name="MD_22" target="resource.md#_BdbCQK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
  <metaDataLink name="MD_25" target="resource.md#_BdabMK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_CAISSE?"/>
  <metaDataLink name="MD_36" target="resource.md#_BdbCRa5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=QTE?"/>
  <metaDataLink name="MD_6" target="resource.md#_BrqSkK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAISSENUMTICNUMTICLIG?"/>
  <metaDataLink name="MD_30" target="resource.md#_BdcQYK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MNT_TTC_EUR?"/>
  <metaDataLink name="MD_13" target="resource.md#_BrsH0q5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REM_TIC?"/>
  <metaDataLink name="MD_28" target="resource.md#_BdesoK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ENS_FK?"/>
  <metaDataLink name="MD_37" target="resource.md#_Bdespq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_FK?"/>
  <metaDataLink name="MD_7" target="resource.md#_BrqSlq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=CODMAGNUMCAISSENUMTIC?"/>
  <metaDataLink name="MD_34" target="resource.md#_Bdc3dq5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_ART_FK?"/>
  <metaDataLink name="MD_2" target="resource.md#_BrrgsK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC_LIG?"/>
  <metaDataLink name="MD_5" target="resource.md#_Brq5rK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=NUM_TIC?"/>
  <metaDataLink name="MD_35" target="resource.md#_BddegK5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_FK?"/>
  <metaDataLink name="MD_16" target="resource.md#_BrtV4K5yEe-mg8uIL6AcVA?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MRQ_FK?"/>
</md:node>