<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_-L55EKccEe-ti-Zc6dspJw-flow" md:ref="resource.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?" internalVersion="v2.0.0">
  <node defType="com.stambia.flow.altId" id="_zc3b0bJGEe-7gLO1_RM3Dg">
    <attribute defType="com.stambia.flow.altId.origin" id="_zc3b0rJGEe-7gLO1_RM3Dg" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_zc3b07JGEe-7gLO1_RM3Dg" value="_-L55EKccEe-ti-Zc6dspJw"/>
  </node>
  <node defType="com.stambia.flow.step" id="e9b51495-9d71-3fe9-b6ec-a1ad8b681b04" name="I1_MAGASIN">
    <attribute defType="com.stambia.flow.step.number" id="_zc7GMbJGEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.target" id="_zc7GMrJGEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_zc7GM7JGEe-7gLO1_RM3Dg" value="Integration"/>
    <node defType="com.stambia.flow.source" id="_zc7GNLJGEe-7gLO1_RM3Dg" name="SAS_MAGASIN">
      <attribute defType="com.stambia.flow.source.target" id="_zc7GNbJGEe-7gLO1_RM3Dg" value="$MD_20"/>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7GNrJGEe-7gLO1_RM3Dg" name="COD_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7GN7JGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7GOLJGEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7GObJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7GOrJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7GO7JGEe-7gLO1_RM3Dg">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7GPLJGEe-7gLO1_RM3Dg" value="$MD_2"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7GPbJGEe-7gLO1_RM3Dg" ref="resource.md#_q4aZsKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7GPrJGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_23}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7GP7JGEe-7gLO1_RM3Dg" value="COD_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7GQLJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7GQbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7GQrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_zc7GQ7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tQLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_23}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tQbJGEe-7gLO1_RM3Dg" name="LIB_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tQrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tQ7JGEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tRLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tRbJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tRrJGEe-7gLO1_RM3Dg">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tR7JGEe-7gLO1_RM3Dg" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tSLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4bAwKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tSbJGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_26}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tSrJGEe-7gLO1_RM3Dg" value="LIB_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tS7JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7tTLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tTbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tTrJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_26}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tT7JGEe-7gLO1_RM3Dg" name="ADR1">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tULJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tUbJGEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tUrJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tU7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tVLJGEe-7gLO1_RM3Dg">
        <values>$MD_28</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tVbJGEe-7gLO1_RM3Dg" value="$MD_4"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tVrJGEe-7gLO1_RM3Dg" ref="resource.md#_q4bn0KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tV7JGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_28}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tWLJGEe-7gLO1_RM3Dg" value="ADR1"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tWbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7tWrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tW7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tXLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_28}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tXbJGEe-7gLO1_RM3Dg" name="ADR2">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tXrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tX7JGEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tYLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tYbJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tYrJGEe-7gLO1_RM3Dg">
        <values>$MD_25</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tY7JGEe-7gLO1_RM3Dg" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tZLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4c18KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tZbJGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_25}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tZrJGEe-7gLO1_RM3Dg" value="ADR2"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tZ7JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7taLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tabJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tarJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_25}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7ta7JGEe-7gLO1_RM3Dg" name="ADR3">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tbLJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tbbJGEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tbrJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tb7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tcLJGEe-7gLO1_RM3Dg">
        <values>$MD_32</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tcbJGEe-7gLO1_RM3Dg" value="$MD_6"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tcrJGEe-7gLO1_RM3Dg" ref="resource.md#_q4ddAKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tc7JGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_32}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tdLJGEe-7gLO1_RM3Dg" value="ADR3"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tdbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7tdrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7td7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7teLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_32}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tebJGEe-7gLO1_RM3Dg" name="VIL_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7terJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7te7JGEe-7gLO1_RM3Dg" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tfLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tfbJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tfrJGEe-7gLO1_RM3Dg">
        <values>$MD_37</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tf7JGEe-7gLO1_RM3Dg" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tgLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4eEEKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tgbJGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_37}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tgrJGEe-7gLO1_RM3Dg" value="VIL_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tg7JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7thLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7thbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7thrJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_37}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7th7JGEe-7gLO1_RM3Dg" name="DEP_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tiLJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tibJGEe-7gLO1_RM3Dg" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tirJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7ti7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tjLJGEe-7gLO1_RM3Dg">
        <values>$MD_21</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tjbJGEe-7gLO1_RM3Dg" value="$MD_8"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tjrJGEe-7gLO1_RM3Dg" ref="resource.md#_q4erIKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tj7JGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_21}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tkLJGEe-7gLO1_RM3Dg" value="DEP_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tkbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7tkrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tk7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tlLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_21}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tlbJGEe-7gLO1_RM3Dg" name="REG_MAG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tlrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tl7JGEe-7gLO1_RM3Dg" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tmLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tmbJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tmrJGEe-7gLO1_RM3Dg">
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tm7JGEe-7gLO1_RM3Dg" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tnLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4f5QKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tnbJGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_24}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tnrJGEe-7gLO1_RM3Dg" value="REG_MAG"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tn7JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7toLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tobJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7torJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_24}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7to7JGEe-7gLO1_RM3Dg" name="LIB_PAY">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tpLJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tpbJGEe-7gLO1_RM3Dg" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7tprJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tp7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7tqLJGEe-7gLO1_RM3Dg">
        <values>$MD_22</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tqbJGEe-7gLO1_RM3Dg" value="$MD_10"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tqrJGEe-7gLO1_RM3Dg" ref="resource.md#_q4ggUKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tq7JGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_22}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7trLJGEe-7gLO1_RM3Dg" value="LIB_PAY"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7trbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7trrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tr7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tsLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_22}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tsbJGEe-7gLO1_RM3Dg" name="LNG">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tsrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7ts7JGEe-7gLO1_RM3Dg" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7ttLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7ttbJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7ttrJGEe-7gLO1_RM3Dg">
        <values>$MD_36</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7tt7JGEe-7gLO1_RM3Dg" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7tuLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4hHYKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tubJGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_36}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7turJGEe-7gLO1_RM3Dg" value="LNG"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tu7JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7tvLJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7tvbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tvrJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_36}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tv7JGEe-7gLO1_RM3Dg" name="LAT">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7twLJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7twbJGEe-7gLO1_RM3Dg" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7twrJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7tw7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7txLJGEe-7gLO1_RM3Dg">
        <values>$MD_29</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7txbJGEe-7gLO1_RM3Dg" value="$MD_12"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7txrJGEe-7gLO1_RM3Dg" ref="resource.md#_q4hucKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7tx7JGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_29}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7tyLJGEe-7gLO1_RM3Dg" value="LAT"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7tybJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7tyrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7ty7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7tzLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_29}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7tzbJGEe-7gLO1_RM3Dg" name="TEL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7tzrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7tz7JGEe-7gLO1_RM3Dg" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7t0LJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7t0bJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7t0rJGEe-7gLO1_RM3Dg">
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7t07JGEe-7gLO1_RM3Dg" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7t1LJGEe-7gLO1_RM3Dg" ref="resource.md#_q4iVgKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7t1bJGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_33}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7t1rJGEe-7gLO1_RM3Dg" value="TEL"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7t17JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7t2LJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7t2bJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7t2rJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_33}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7t27JGEe-7gLO1_RM3Dg" name="EMAIL">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7t3LJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7t3bJGEe-7gLO1_RM3Dg" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7t3rJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7t37JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7t4LJGEe-7gLO1_RM3Dg">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7t4bJGEe-7gLO1_RM3Dg" value="$MD_14"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7t4rJGEe-7gLO1_RM3Dg" ref="resource.md#_q4i8kKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7t47JGEe-7gLO1_RM3Dg" value="'lower(SAS_MAGASIN.%{MD_27}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7t5LJGEe-7gLO1_RM3Dg" value="EMAIL"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7t5bJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7t5rJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7t57JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7t6LJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_27}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7t6bJGEe-7gLO1_RM3Dg" name="DAT_OUV">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7t6rJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7t67JGEe-7gLO1_RM3Dg" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7t7LJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7t7bJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7t7rJGEe-7gLO1_RM3Dg">
        <values>$MD_35</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7t77JGEe-7gLO1_RM3Dg" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7t8LJGEe-7gLO1_RM3Dg" ref="resource.md#_q4jjoKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7t8bJGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_35}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7t8rJGEe-7gLO1_RM3Dg" value="DAT_OUV"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7t87JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7t9LJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7t9bJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7t9rJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_35}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7t97JGEe-7gLO1_RM3Dg" name="DATE_FRM">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7t-LJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7t-bJGEe-7gLO1_RM3Dg" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7t-rJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7t-7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7t_LJGEe-7gLO1_RM3Dg">
        <values>$MD_30</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7t_bJGEe-7gLO1_RM3Dg" value="$MD_16"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7t_rJGEe-7gLO1_RM3Dg" ref="resource.md#_q4kKsKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_FRM?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7t_7JGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_30}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7uALJGEe-7gLO1_RM3Dg" value="DATE_FRM"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7uAbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7uArJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7uA7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7uBLJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_30}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7uBbJGEe-7gLO1_RM3Dg" name="SCHEDULE">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7uBrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7uB7JGEe-7gLO1_RM3Dg" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7uCLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7uCbJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7uCrJGEe-7gLO1_RM3Dg">
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7uC7JGEe-7gLO1_RM3Dg" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7uDLJGEe-7gLO1_RM3Dg" ref="resource.md#_q4kKtqcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7uDbJGEe-7gLO1_RM3Dg" value="'SAS_MAGASIN.%{MD_31}%'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7uDrJGEe-7gLO1_RM3Dg" value="SCHEDULE"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7uD7JGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7uELJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7uEbJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7uErJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_31}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7uE7JGEe-7gLO1_RM3Dg" name="LIB_ENS">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7uFLJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7uFbJGEe-7gLO1_RM3Dg" value="$MD_18"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7uFrJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_zc7uF7JGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.source" id="_zc7uGLJGEe-7gLO1_RM3Dg">
        <values>$MD_34</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.target" id="_zc7uGbJGEe-7gLO1_RM3Dg" value="$MD_18"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7uGrJGEe-7gLO1_RM3Dg" ref="resource.md#_q4l_4KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7uG7JGEe-7gLO1_RM3Dg" value="'INITCAP(SAS_MAGASIN.%{MD_34}%)'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7uHLJGEe-7gLO1_RM3Dg" value="LIB_ENS"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7uHbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7uHrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7uH7JGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_zc7uILJGEe-7gLO1_RM3Dg">
        <values>SAS_MAGASIN.%{MD_34}%</values>
      </attribute>
    </node>
    <node defType="com.stambia.flow.field" id="_zc7uIbJGEe-7gLO1_RM3Dg" name="DATE_DERN_EXEC">
      <attribute defType="com.stambia.flow.field.aggregate" id="_zc7uIrJGEe-7gLO1_RM3Dg" value="false"/>
      <attribute defType="com.stambia.flow.field.base" id="_zc7uI7JGEe-7gLO1_RM3Dg" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.location" id="_zc7uJLJGEe-7gLO1_RM3Dg" value="SRC"/>
      <attribute defType="com.stambia.flow.field.target" id="_zc7uJbJGEe-7gLO1_RM3Dg" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.mdFieldRef" id="_zc7uJrJGEe-7gLO1_RM3Dg" ref="resource.md#_P9rjSLJCEe-7gLO1_RM3Dg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
      <attribute defType="com.stambia.flow.field.expr" id="_zc7uJ7JGEe-7gLO1_RM3Dg" value="'TO_CHAR(SYSDATE, ''YYYYMMDDHH24MISS'')'"/>
      <attribute defType="com.stambia.flow.field.workname" id="_zc7uKLJGEe-7gLO1_RM3Dg" value="DATE_DERN_EXEC"/>
      <attribute defType="com.stambia.flow.field.version" id="_zc7uKbJGEe-7gLO1_RM3Dg" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_zc7uKrJGEe-7gLO1_RM3Dg" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_zc7uK7JGEe-7gLO1_RM3Dg" value="true"/>
    </node>
  </node>
  <node defType="com.stambia.flow.step" id="994c04fe-1ad0-3953-926b-89de39d90cfc" name="R1_MAGASIN">
    <attribute defType="com.stambia.flow.step.number" id="_zc8UUbJGEe-7gLO1_RM3Dg" value="1"/>
    <attribute defType="com.stambia.flow.step.integrationStepName" id="_zc8UUrJGEe-7gLO1_RM3Dg">
      <values>I1_MAGASIN</values>
    </attribute>
    <attribute defType="com.stambia.flow.step.target" id="_zc8UU7JGEe-7gLO1_RM3Dg" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.type" id="_zc8UVLJGEe-7gLO1_RM3Dg" value="Check"/>
    <node defType="com.stambia.flow.constraint" id="_zc8UVbJGEe-7gLO1_RM3Dg" name="PK_MAG">
      <attribute defType="com.stambia.flow.constraint.type" id="_zc8UVrJGEe-7gLO1_RM3Dg" value="pk"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_zc8UV7JGEe-7gLO1_RM3Dg" value="$MD_1"/>
    </node>
    <node defType="com.stambia.flow.constraint" id="_zc8UWLJGEe-7gLO1_RM3Dg" name="NN_COD_MAG">
      <attribute defType="com.stambia.flow.constraint.type" id="_zc8UWbJGEe-7gLO1_RM3Dg" value="NN"/>
      <attribute defType="com.stambia.flow.constraint.target" id="_zc8UWrJGEe-7gLO1_RM3Dg" value="$MD_2"/>
    </node>
  </node>
  <metaDataLink name="MD_22" target="resource.md#_RUy0hqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
  <metaDataLink name="MD_26" target="resource.md#_RUwYQKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_2" target="resource.md#_q4aZsKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
  <metaDataLink name="MD_0" target="resource.md#_qXNxIKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=MAGASIN?"/>
  <metaDataLink name="MD_30" target="resource.md#_RU2e5qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_FRM?"/>
  <metaDataLink name="MD_12" target="resource.md#_q4hucKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
  <metaDataLink name="MD_15" target="resource.md#_q4jjoKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
  <metaDataLink name="MD_16" target="resource.md#_q4kKsKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_FRM?"/>
  <metaDataLink name="MD_9" target="resource.md#_q4f5QKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
  <metaDataLink name="MD_28" target="resource.md#_RUwYRqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
  <metaDataLink name="MD_7" target="resource.md#_q4eEEKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
  <metaDataLink name="MD_24" target="resource.md#_RUy0gKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
  <metaDataLink name="MD_32" target="resource.md#_RUw_VqS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
  <metaDataLink name="MD_18" target="resource.md#_q4l_4KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
  <metaDataLink name="MD_19" target="resource.md#_P9rjSLJCEe-7gLO1_RM3Dg?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_DERN_EXEC?"/>
  <metaDataLink name="MD_37" target="resource.md#_RUxmYKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
  <metaDataLink name="MD_8" target="resource.md#_q4erIKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
  <metaDataLink name="MD_23" target="resource.md#_RUvxMKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
  <metaDataLink name="MD_4" target="resource.md#_q4bn0KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
  <metaDataLink name="MD_14" target="resource.md#_q4i8kKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
  <metaDataLink name="MD_21" target="resource.md#_RUyNcKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
  <metaDataLink name="MD_27" target="resource.md#_RU131qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
  <metaDataLink name="MD_34" target="resource.md#_RU3F9qS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
  <metaDataLink name="MD_25" target="resource.md#_RUw_UKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
  <metaDataLink name="MD_6" target="resource.md#_q4ddAKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
  <metaDataLink name="MD_17" target="resource.md#_q4kKtqcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
  <metaDataLink name="MD_31" target="resource.md#_RU3F8KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
  <metaDataLink name="MD_11" target="resource.md#_q4hHYKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
  <metaDataLink name="MD_13" target="resource.md#_q4iVgKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
  <metaDataLink name="MD_10" target="resource.md#_q4ggUKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
  <metaDataLink name="MD_29" target="resource.md#_RU0psKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
  <metaDataLink name="MD_36" target="resource.md#_RU0CoKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
  <metaDataLink name="MD_5" target="resource.md#_q4c18KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
  <metaDataLink name="MD_35" target="resource.md#_RU2e4KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
  <metaDataLink name="MD_20" target="resource.md#_RLOBwKS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MAGASIN?"/>
  <metaDataLink name="MD_1" target="resource.md#_q4vJ0KcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=PK_MAG?"/>
  <metaDataLink name="MD_3" target="resource.md#_q4bAwKcdEe-ti-Zc6dspJw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
  <metaDataLink name="MD_33" target="resource.md#_RU130KS3Ee-RkIWF5HwjUw?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
</md:node>