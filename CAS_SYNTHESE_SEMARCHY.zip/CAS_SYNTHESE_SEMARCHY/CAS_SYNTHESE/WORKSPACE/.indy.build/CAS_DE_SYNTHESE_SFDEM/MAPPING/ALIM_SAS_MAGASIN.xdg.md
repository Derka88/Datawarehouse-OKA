<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.semarchy.xdi.harvest.model" id="_C3YfQKHDEe-Mishx4UyKwQ-xdg" md:ref="resource.tech#UUID_TECH_XDI_HARVESTED?fileId=UUID_TECH_XDI_HARVESTED?" internalVersion="v2.0.0">
  <node defType="com.semarchy.xdi.harvest.mapping" id="_evTtLqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelId" id="_evTtL6HHEe-Mishx4UyKwQ" value="_C3YfQKHDEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.mapping.modelName" id="_evTtMKHHEe-Mishx4UyKwQ" value="ALIM_SAS_MAGASIN"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_evUTgqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_evUTg6HHEe-Mishx4UyKwQ" value="_1I9ZsKG9Ee-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_evUThKHHEe-Mishx4UyKwQ" value="BDD"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.metadata" id="_evUTLaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelId" id="_evUTLqHHEe-Mishx4UyKwQ" value="_OMrx0JbGEe-yJMimzYo_ug"/>
    <attribute defType="com.semarchy.xdi.harvest.metadata.modelName" id="_evUTL6HHEe-Mishx4UyKwQ" value="TICKET"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceset" id="_evUTi6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelName" id="_evUTjKHHEe-Mishx4UyKwQ" value="Source SAS_MAGASIN"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceset.modelId" id="_evUTjaHHEe-Mishx4UyKwQ" value="ss-_MIYJgKHDEe-Mishx4UyKwQ"/>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTlKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTlaHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.TEL"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTlqHHEe-Mishx4UyKwQ" value="ssf-_FXK7iaHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTmqHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTm6HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.LIB_MAG"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTnKHHEe-Mishx4UyKwQ" value="ssf-_FXK7caHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUToKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUToaHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.DAT_FRM"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUToqHHEe-Mishx4UyKwQ" value="ssf-_FXK7jqHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTpqHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTp6HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.SCHEDULE"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTqKHHEe-Mishx4UyKwQ" value="ssf-_FXK7j6HDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTrKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTraHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.DEP_MAG"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTrqHHEe-Mishx4UyKwQ" value="ssf-_FXK7h6HDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTsqHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTs6HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.REG_MAG"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTtKHHEe-Mishx4UyKwQ" value="ssf-_FXK7iKHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTuKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTuaHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.ADR1"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTuqHHEe-Mishx4UyKwQ" value="ssf-_FXK7gqHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTvqHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTv6HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.ADR2"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTwKHHEe-Mishx4UyKwQ" value="ssf-_FXK7g6HDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTxKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTxaHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.LIB_PAY"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTxqHHEe-Mishx4UyKwQ" value="ssf-_FXK7gaHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUTyqHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUTy6HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.EMAIL"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUTzKHHEe-Mishx4UyKwQ" value="ssf-_FXK7iqHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUT0KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUT0aHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.DAT_OUV"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUT0qHHEe-Mishx4UyKwQ" value="ssf-_FXK7jaHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUT1qHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUT16HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.ADR3"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUT2KHHEe-Mishx4UyKwQ" value="ssf-_FXK7hKHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUT3KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUT3aHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.LIB_ENS"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUT3qHHEe-Mishx4UyKwQ" value="ssf-_FXK7cKHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUT4qHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUT46HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.VIL_MAG"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUT5KHHEe-Mishx4UyKwQ" value="ssf-_FXK7haHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUT6KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUT6aHHEe-Mishx4UyKwQ" value="Source Ticket_20240801.LAT"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUT6qHHEe-Mishx4UyKwQ" value="ssf-_FXK7jKHDEe-Mishx4UyKwQ"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.sourcesetfield" id="_evUT7qHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelName" id="_evUT76HHEe-Mishx4UyKwQ" value="Source Ticket_20240801.LNG"/>
      <attribute defType="com.semarchy.xdi.harvest.sourcesetfield.modelId" id="_evUT8KHHEe-Mishx4UyKwQ" value="ssf-_FXK7i6HDEe-Mishx4UyKwQ"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_evTtMaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_evTtMqHHEe-Mishx4UyKwQ" value="_FXKUYKHDEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_evTtM6HHEe-Mishx4UyKwQ" value="Ticket_20240801"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSoKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSoaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGUZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_POS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSoqHHEe-Mishx4UyKwQ" value="_FXK7hqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSo6HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_POS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSpKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSpaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGc5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_FRM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSpqHHEe-Mishx4UyKwQ" value="_FXK7jqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSp6HHEe-Mishx4UyKwQ" value="Ticket_20240801.DAT_FRM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSqKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSqaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGIpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSqqHHEe-Mishx4UyKwQ" value="_FXK7e6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSq6HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSrKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSraHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZF8JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSrqHHEe-Mishx4UyKwQ" value="_FXKUY6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSr6HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSsKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSsaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGEJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_VEN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSsqHHEe-Mishx4UyKwQ" value="_FXK7d6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSs6HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_VEN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUStKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUStaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZF-JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUStqHHEe-Mishx4UyKwQ" value="_FXK7caHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSt6HHEe-Mishx4UyKwQ" value="Ticket_20240801.LIB_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSuKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSuaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGBJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=NUM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSuqHHEe-Mishx4UyKwQ" value="_FXK7dKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSu6HHEe-Mishx4UyKwQ" value="Ticket_20240801.NUM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSvKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSvaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGXZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TEL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSvqHHEe-Mishx4UyKwQ" value="_FXK7iaHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSv6HHEe-Mishx4UyKwQ" value="Ticket_20240801.TEL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSwKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSwaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGRZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR2?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSwqHHEe-Mishx4UyKwQ" value="_FXK7g6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSw6HHEe-Mishx4UyKwQ" value="Ticket_20240801.ADR2"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSxKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSxaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGSZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR3?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSxqHHEe-Mishx4UyKwQ" value="_FXK7hKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSx6HHEe-Mishx4UyKwQ" value="Ticket_20240801.ADR3"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSyKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSyaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGapbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSyqHHEe-Mishx4UyKwQ" value="_FXK7jKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSy6HHEe-Mishx4UyKwQ" value="Ticket_20240801.LAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUSzKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUSzaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGKpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REM_LIN?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUSzqHHEe-Mishx4UyKwQ" value="_FXK7faHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUSz6HHEe-Mishx4UyKwQ" value="Ticket_20240801.REM_LIN"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS0KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS0aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGOZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS0qHHEe-Mishx4UyKwQ" value="_FXK7gKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS06HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS1KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS1aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZF9JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS1qHHEe-Mishx4UyKwQ" value="_FXK7cKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS16HHEe-Mishx4UyKwQ" value="Ticket_20240801.LIB_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS2KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS2aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGWZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REG_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS2qHHEe-Mishx4UyKwQ" value="_FXK7iKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS26HHEe-Mishx4UyKwQ" value="Ticket_20240801.REG_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS3KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS3aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGFJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=QTE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS3qHHEe-Mishx4UyKwQ" value="_FXK7eKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS36HHEe-Mishx4UyKwQ" value="Ticket_20240801.QTE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS4KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS4aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGZZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LNG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS4qHHEe-Mishx4UyKwQ" value="_FXK7i6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS46HHEe-Mishx4UyKwQ" value="Ticket_20240801.LNG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS5KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS5aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGGJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=MNT_BRU?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS5qHHEe-Mishx4UyKwQ" value="_FXK7eaHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS56HHEe-Mishx4UyKwQ" value="Ticket_20240801.MNT_BRU"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS6KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS6aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGL5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=REM_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS6qHHEe-Mishx4UyKwQ" value="_FXK7fqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS66HHEe-Mishx4UyKwQ" value="Ticket_20240801.REM_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS7KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS7aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZF_JbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_ART?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS7qHHEe-Mishx4UyKwQ" value="_FXK7cqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS76HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_ART"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS8KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS8aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGTZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=VIL_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS8qHHEe-Mishx4UyKwQ" value="_FXK7haHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS86HHEe-Mishx4UyKwQ" value="Ticket_20240801.VIL_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS9KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS9aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGNJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TX_DEV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS9qHHEe-Mishx4UyKwQ" value="_FXK7f6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS96HHEe-Mishx4UyKwQ" value="Ticket_20240801.TX_DEV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS-KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS-aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGd5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=SCHEDULE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS-qHHEe-Mishx4UyKwQ" value="_FXK7j6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS-6HHEe-Mishx4UyKwQ" value="Ticket_20240801.SCHEDULE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUS_KHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUS_aHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGAJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_HEU_TIC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUS_qHHEe-Mishx4UyKwQ" value="_FXK7c6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUS_6HHEe-Mishx4UyKwQ" value="Ticket_20240801.DAT_HEU_TIC"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTAKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTAaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGDJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=COD_CAI?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTAqHHEe-Mishx4UyKwQ" value="_FXK7dqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTA6HHEe-Mishx4UyKwQ" value="Ticket_20240801.COD_CAI"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTBKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTBaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGQZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=ADR1?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTBqHHEe-Mishx4UyKwQ" value="_FXK7gqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTB6HHEe-Mishx4UyKwQ" value="Ticket_20240801.ADR1"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTCKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTCaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGVZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DEP_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTCqHHEe-Mishx4UyKwQ" value="_FXK7h6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTC6HHEe-Mishx4UyKwQ" value="Ticket_20240801.DEP_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTDKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTDaHHEe-Mishx4UyKwQ" ref="resource.md#_OOP4EJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=Ticket_20240801?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTDqHHEe-Mishx4UyKwQ" value="_FXKUYqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTD6HHEe-Mishx4UyKwQ" value="Ticket_20240801.Ticket_20240801"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTEKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTEaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGPZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=LIB_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTEqHHEe-Mishx4UyKwQ" value="_FXK7gaHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTE6HHEe-Mishx4UyKwQ" value="Ticket_20240801.LIB_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTFKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTFaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGYZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=EMAIL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTFqHHEe-Mishx4UyKwQ" value="_FXK7iqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTF6HHEe-Mishx4UyKwQ" value="Ticket_20240801.EMAIL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTGKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTGaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGb5bGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=DAT_OUV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTGqHHEe-Mishx4UyKwQ" value="_FXK7jaHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTG6HHEe-Mishx4UyKwQ" value="Ticket_20240801.DAT_OUV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTHKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTHaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGCJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=NUM_TIC_LIG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTHqHHEe-Mishx4UyKwQ" value="_FXK7daHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTH6HHEe-Mishx4UyKwQ" value="Ticket_20240801.NUM_TIC_LIG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTIKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTIaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGJpbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=TX_TVA?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTIqHHEe-Mishx4UyKwQ" value="_FXK7fKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTI6HHEe-Mishx4UyKwQ" value="Ticket_20240801.TX_TVA"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTJKHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTJaHHEe-Mishx4UyKwQ" ref="resource.md#_ZbZGHZbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=MNT_TTC?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTJqHHEe-Mishx4UyKwQ" value="_FXK7eqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTJ6HHEe-Mishx4UyKwQ" value="Ticket_20240801.MNT_TTC"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.datastore" id="_evUTNqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelId" id="_evUTN6HHEe-Mishx4UyKwQ" value="_MIYJgKHDEe-Mishx4UyKwQ"/>
    <attribute defType="com.semarchy.xdi.harvest.datastore.modelName" id="_evUTOKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN"/>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTOaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTOqHHEe-Mishx4UyKwQ" ref="resource.md#_idSBBKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=TEL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTO6HHEe-Mishx4UyKwQ" value="_MIbM16HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTPKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.TEL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTPaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTPqHHEe-Mishx4UyKwQ" ref="resource.md#_idRZ16HBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTP6HHEe-Mishx4UyKwQ" value="_MIalwqHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTQKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.LIB_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTQaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTQqHHEe-Mishx4UyKwQ" ref="resource.md#_idSn_KHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DATE_FRM?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTQ6HHEe-Mishx4UyKwQ" value="_MIbM2qHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTRKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.DATE_FRM"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTRaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTRqHHEe-Mishx4UyKwQ" ref="resource.md#_idSoAqHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SCHEDULE?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTR6HHEe-Mishx4UyKwQ" value="_MIbz4KHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTSKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.SCHEDULE"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTSaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTSqHHEe-Mishx4UyKwQ" ref="resource.md#_idSA5qHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DEP_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTS6HHEe-Mishx4UyKwQ" value="_MIbM0qHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTTKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.DEP_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTTaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTTqHHEe-Mishx4UyKwQ" ref="resource.md#_idSA7KHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=REG_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTT6HHEe-Mishx4UyKwQ" value="_MIbM06HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTUKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.REG_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTUaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTUqHHEe-Mishx4UyKwQ" ref="resource.md#_idRZ3aHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR1?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTU6HHEe-Mishx4UyKwQ" value="_MIalw6HDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTVKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.ADR1"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTVaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTVqHHEe-Mishx4UyKwQ" ref="resource.md#_idRZ46HBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR2?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTV6HHEe-Mishx4UyKwQ" value="_MIalxKHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTWKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.ADR2"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTWaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTWqHHEe-Mishx4UyKwQ" ref="resource.md#_idSA8qHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_PAY?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTW6HHEe-Mishx4UyKwQ" value="_MIbM1KHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTXKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.LIB_PAY"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTXaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTXqHHEe-Mishx4UyKwQ" ref="resource.md#_idSn8KHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=EMAIL?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTX6HHEe-Mishx4UyKwQ" value="_MIbM2KHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTYKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.EMAIL"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTYaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTYqHHEe-Mishx4UyKwQ" ref="resource.md#_idSn9qHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=DAT_OUV?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTY6HHEe-Mishx4UyKwQ" value="_MIbM2aHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTZKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.DAT_OUV"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTZaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTZqHHEe-Mishx4UyKwQ" ref="resource.md#_idRZ6aHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=ADR3?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTZ6HHEe-Mishx4UyKwQ" value="_MIbM0KHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTaKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.ADR3"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTaaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTaqHHEe-Mishx4UyKwQ" ref="resource.md#_idSoCKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LIB_ENS?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTa6HHEe-Mishx4UyKwQ" value="_MIbz4aHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTbKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.LIB_ENS"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTbaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTbqHHEe-Mishx4UyKwQ" ref="resource.md#_idSA4KHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=VIL_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTb6HHEe-Mishx4UyKwQ" value="_MIbM0aHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTcKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.VIL_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTcaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTcqHHEe-Mishx4UyKwQ" ref="resource.md#_idSA_qHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LAT?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTc6HHEe-Mishx4UyKwQ" value="_MIbM1qHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTdKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.LAT"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTdaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTdqHHEe-Mishx4UyKwQ" ref="resource.md#_idRZ0KHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=COD_MAG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTd6HHEe-Mishx4UyKwQ" value="_MIalwaHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTeKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.COD_MAG"/>
    </node>
    <node defType="com.semarchy.xdi.harvest.datastorefield" id="_evUTeaHHEe-Mishx4UyKwQ">
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.mdRef" id="_evUTeqHHEe-Mishx4UyKwQ" ref="resource.md#_idSA-KHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=LNG?"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelId" id="_evUTe6HHEe-Mishx4UyKwQ" value="_MIbM1aHDEe-Mishx4UyKwQ"/>
      <attribute defType="com.semarchy.xdi.harvest.datastorefield.modelName" id="_evUTfKHHEe-Mishx4UyKwQ" value="SAS_MAGASIN.LNG"/>
    </node>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_evUTKKHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_evUTKaHHEe-Mishx4UyKwQ" ref="resource.md#_OOP4EJbGEe-yJMimzYo_ug?fileId=_OMrx0JbGEe-yJMimzYo_ug$type=md$name=Ticket_20240801?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.store" id="_evUTfaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.store.mdRef" id="_evUTfqHHEe-Mishx4UyKwQ" ref="resource.md#_iZ0dMKHBEe-Mishx4UyKwQ?fileId=_1I9ZsKG9Ee-Mishx4UyKwQ$type=md$name=SAS_MAGASIN?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore" id="_evUTjqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.sourceRef" id="_evUTj6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTi6HHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetToTargetDatastore.targetRef" id="_evUTkKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTNqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTl6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTmKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTlKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTmaHHEe-Mishx4UyKwQ" ref="resource.md#_evUSvKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTnaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTnqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTmqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTn6HHEe-Mishx4UyKwQ" ref="resource.md#_evUStKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTo6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTpKHHEe-Mishx4UyKwQ" ref="resource.md#_evUToKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTpaHHEe-Mishx4UyKwQ" ref="resource.md#_evUSpKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTqaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTqqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTpqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTq6HHEe-Mishx4UyKwQ" ref="resource.md#_evUS-KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTr6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTsKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTrKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTsaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTCKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTtaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTtqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTsqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTt6HHEe-Mishx4UyKwQ" ref="resource.md#_evUS2KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTu6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTvKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTuKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTvaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTBKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTwaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTwqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTvqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTw6HHEe-Mishx4UyKwQ" ref="resource.md#_evUSwKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTx6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTyKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTxKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTyaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTEKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUTzaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUTzqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTyqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUTz6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTFKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUT06HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUT1KHHEe-Mishx4UyKwQ" ref="resource.md#_evUT0KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUT1aHHEe-Mishx4UyKwQ" ref="resource.md#_evUTGKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUT2aHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUT2qHHEe-Mishx4UyKwQ" ref="resource.md#_evUT1qHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUT26HHEe-Mishx4UyKwQ" ref="resource.md#_evUSxKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUT36HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUT4KHHEe-Mishx4UyKwQ" ref="resource.md#_evUT3KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUT4aHHEe-Mishx4UyKwQ" ref="resource.md#_evUS1KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUT5aHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUT5qHHEe-Mishx4UyKwQ" ref="resource.md#_evUT4qHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUT56HHEe-Mishx4UyKwQ" ref="resource.md#_evUS8KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUT66HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUT7KHHEe-Mishx4UyKwQ" ref="resource.md#_evUT6KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUT7aHHEe-Mishx4UyKwQ" ref="resource.md#_evUSyKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping" id="_evUT8aHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.sourceRef" id="_evUT8qHHEe-Mishx4UyKwQ" ref="resource.md#_evUT7qHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.sourceSetDatastoreFieldMapping.targetRef" id="_evUT86HHEe-Mishx4UyKwQ" ref="resource.md#_evUS4KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUT9KHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUT9aHHEe-Mishx4UyKwQ" ref="resource.md#_evUT3KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUT9qHHEe-Mishx4UyKwQ" ref="resource.md#_evUTaaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUT96HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUT-KHHEe-Mishx4UyKwQ" ref="resource.md#_evUTuKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUT-aHHEe-Mishx4UyKwQ" ref="resource.md#_evUTUaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUT-qHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUT-6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTlKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUT_KHHEe-Mishx4UyKwQ" ref="resource.md#_evUTOaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUT_aHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUT_qHHEe-Mishx4UyKwQ" ref="resource.md#_evUT0KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUT_6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTYaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUAKHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUAaHHEe-Mishx4UyKwQ" ref="resource.md#_evUT6KHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUAqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTcaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUA6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUBKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTyqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUBaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTXaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUBqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUB6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTxKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUCKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTWaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUCaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUCqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTvqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUC6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTVaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUDKHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUDaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTrKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUDqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTSaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUD6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUEKHHEe-Mishx4UyKwQ" ref="resource.md#_evUT4qHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUEaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTbaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUEqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUE6HHEe-Mishx4UyKwQ" ref="resource.md#_evUT7qHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUFKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTeaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUFaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUFqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTsqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUF6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTTaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUGKHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUGaHHEe-Mishx4UyKwQ" ref="resource.md#_evUToKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUGqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTQaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUG6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUHKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTpqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUHaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTRaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUHqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUH6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTmqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUIKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTPaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.fieldLineage" id="_evUUIaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.sourceRef" id="_evUUIqHHEe-Mishx4UyKwQ" ref="resource.md#_evUT1qHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.fieldLineage.targetRef" id="_evUUI6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTZaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_evUTKqHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_evUTK6HHEe-Mishx4UyKwQ" ref="resource.md#_evTtMaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_evUTLKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTKKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage" id="_evUTf6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.sourceRef" id="_evUTgKHHEe-Mishx4UyKwQ" ref="resource.md#_evUTNqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.dataStorePhysicalStorage.targetRef" id="_evUTgaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTfaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_evUTMKHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_evUTMaHHEe-Mishx4UyKwQ" ref="resource.md#_evUTLaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_evUTMqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTKKHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_evUTM6HHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_evUTNKHHEe-Mishx4UyKwQ" ref="resource.md#_evTtLqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_evUTNaHHEe-Mishx4UyKwQ" ref="resource.md#_evTtMaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_evUThaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_evUThqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTgqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_evUTh6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTfaHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_evUTiKHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_evUTiaHHEe-Mishx4UyKwQ" ref="resource.md#_evTtLqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_evUTiqHHEe-Mishx4UyKwQ" ref="resource.md#_evUTNqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
  <node defType="com.semarchy.xdi.harvest.resourceOwner" id="_evUTkaHHEe-Mishx4UyKwQ">
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.sourceRef" id="_evUTkqHHEe-Mishx4UyKwQ" ref="resource.md#_evTtLqHHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
    <attribute defType="com.semarchy.xdi.harvest.resourceOwner.targetRef" id="_evUTk6HHEe-Mishx4UyKwQ" ref="resource.md#_evUTi6HHEe-Mishx4UyKwQ?fileId=_C3YfQKHDEe-Mishx4UyKwQ-xdg$type=md?"/>
  </node>
</md:node>